---
id: param_ph
title: Độ pH
type: parameter
params: [ph]
source: general
verified: false
---
# Độ pH

## Ý nghĩa
pH đo độ axit hoặc kiềm của nước trên thang 0-14, giá trị 7 là trung tính. Nước mặt tự nhiên thường gần trung tính đến kiềm nhẹ. Quy chuẩn đặt ra một khoảng pH cho phép, nên cả pH quá thấp và quá cao đều là bất thường.

## Nguyên nhân thường gặp khi bất thường
pH thấp có thể do nước thải axit (công nghiệp, khai thác mỏ), mưa axit hoặc phân hủy mạnh chất hữu cơ tạo CO2. pH cao có thể do nước thải kiềm, hoạt động xử lý bằng vôi, hoặc tảo quang hợp mạnh vào ban ngày làm giảm CO2 trong nước.

## Khuyến nghị
Kiểm tra nguồn xả thải công nghiệp gần trạm. Xem biến thiên pH theo giờ: pH do tảo thường tăng vào buổi chiều và giảm về đêm. Khi nghi ngờ sai lệch, hiệu chuẩn điện cực pH bằng dung dịch đệm chuẩn (thường dùng pH 4.01, 7.00 và 10.01) và kiểm tra tuổi thọ điện cực.
