---
id: sys_wqi
title: Cách hệ thống tính WQI
type: system
source: wqi.yaml
verified: false
params: [do_mgL, ph, nh4n_mgL, codmn_mgL, turbidity_ntu, tds_ppm, temperature_c]
---
# Cách hệ thống tính WQI

*Tài liệu sinh tự động từ config/wqi.yaml (phiên bản illustrative-0.2).*

## Tổng quan
WQI của hệ thống là chỉ số RÚT GỌN mang tính minh họa, chưa phải chỉ số chính thức. Mỗi thông số có mặt trong mẫu đo được quy đổi về điểm 0-100 bằng nội suy tuyến tính giữa các điểm neo, sau đó lấy trung bình có trọng số trên các thông số có mặt (trọng số chuẩn hóa lại). Cần tối thiểu 2 thông số. Giá trị bị gắn cờ nghi ngờ không được dùng.

## Phân loại WQI
WQI từ 91 trở lên: Rất tốt.
WQI từ 76 trở lên: Tốt.
WQI từ 51 trở lên: Trung bình.
WQI từ 26 trở lên: Kém.
WQI dưới mức trên: Rất kém / Ô nhiễm nặng.

## Điểm của do_mgL
Trọng số 0.25. Điểm neo (giá trị→điểm): 0→0, 2→20, 3→40, 5→60, 6→80, 7.5→100.

## Điểm của ph
Trọng số 0.15. Điểm neo (giá trị→điểm): 4→0, 6→50, 6.5→85, 7→100, 8→100, 8.5→85, 9→50, 11→0.

## Điểm của nh4n_mgL
Trọng số 0.2. Điểm neo (giá trị→điểm): 0→100, 0.15→100, 0.5→80, 1→60, 1.5→40, 2→20, 4→0.

## Điểm của codmn_mgL
Trọng số 0.15. Điểm neo (giá trị→điểm): 0→100, 2→100, 4→80, 6→60, 10→40, 15→20, 30→0.

## Điểm của turbidity_ntu
Trọng số 0.15. Điểm neo (giá trị→điểm): 0→100, 50→0.

## Điểm của tds_ppm
Trọng số 0.1. Điểm neo (giá trị→điểm): 0→100, 1000→0.

## Điểm của temperature_c
Không tham gia WQI (chỉ hiển thị).
