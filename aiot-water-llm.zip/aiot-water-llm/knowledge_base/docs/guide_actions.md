---
id: guide_actions
title: Hướng dẫn xử lý theo tình huống
type: guide
params: []
source: general
verified: false
---
# Hướng dẫn xử lý theo tình huống

Đây là hướng dẫn tham khảo kỹ thuật chung, không thay thế đánh giá của chuyên gia và không phải kết luận pháp lý.

## WQI rất kém
Khi WQI ở mức rất kém, hệ thống khuyến nghị tạm ngưng sử dụng nguồn nước cho sinh hoạt cho đến khi có kết quả kiểm tra bổ sung. Cần lấy mẫu kiểm tra tại phòng thí nghiệm, xác định nguồn ô nhiễm và thông báo cho bộ phận quản lý.

## Nhiều thông số cùng xấu
Khi DO thấp đi cùng amoni hoặc chất hữu cơ cao, nguyên nhân thường là nước thải hữu cơ. Kiểm tra các nguồn xả thải gần trạm và thời điểm các thông số bắt đầu thay đổi.

## Cảm biến nghi lỗi
Dấu hiệu gồm giá trị ngoài khoảng hợp lý, giá trị đứng yên nhiều chu kỳ, hoặc nhảy đột ngột không có nguyên nhân. Hệ thống gắn cờ nghi ngờ và không dùng giá trị đó để tính WQI. Cần kiểm tra dây nối, nguồn, vệ sinh đầu đo và hiệu chuẩn lại cảm biến.

## Thiết bị mất kết nối
Thiết bị bị coi là mất kết nối khi không gửi dữ liệu trong thời gian quy định. Kiểm tra nguồn điện hoặc pin, tín hiệu WiFi và broker MQTT, rồi khởi động lại thiết bị.
