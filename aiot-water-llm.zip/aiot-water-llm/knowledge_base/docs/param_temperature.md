---
id: param_temperature
title: Nhiệt độ nước
type: parameter
params: [temperature_c]
source: general
verified: false
---
# Nhiệt độ nước

## Ý nghĩa
Nhiệt độ nước ảnh hưởng đến lượng oxy hòa tan (nước càng ấm, oxy tan càng ít) và tốc độ các phản ứng sinh học. Nhiệt độ không tham gia tính WQI của hệ thống mà được dùng để hiệu chỉnh và giải thích các thông số khác.

## Nguyên nhân thường gặp khi bất thường
Nhiệt độ tăng theo mùa và theo giờ trong ngày, hoặc do xả nước thải nóng từ nhà máy. Giá trị đột ngột bằng -127 hoặc 85 thường là lỗi giao tiếp của cảm biến DS18B20, không phải nhiệt độ thật.

## Khuyến nghị
Khi nhiệt độ cao, theo dõi sát DO vì nguy cơ thiếu oxy tăng. Kiểm tra dây và nguồn cảm biến nếu giá trị đứng yên hoặc nhảy bất thường.
