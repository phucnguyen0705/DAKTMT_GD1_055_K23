---
id: param_organic
title: Chất hữu cơ (CODMn, COD, BOD)
type: parameter
params: [codmn_mgL]
source: general
verified: false
---
# Chất hữu cơ (CODMn, COD, BOD)

## Ý nghĩa
CODMn (chỉ số pemanganat), COD và BOD5 phản ánh lượng chất hữu cơ trong nước. CODMn dùng kali pemanganat làm chất oxy hóa và thường cho giá trị thấp hơn COD dùng kali dicromat. BOD5 là lượng oxy vi sinh vật tiêu thụ để phân hủy chất hữu cơ trong 5 ngày ở 20 độ C. Các chỉ tiêu này không đổi trực tiếp cho nhau, nên cần so với đúng chỉ tiêu mà quy chuẩn quy định.

## Nguyên nhân thường gặp khi bất thường
Giá trị cao thường do nước thải sinh hoạt, công nghiệp thực phẩm, chăn nuôi, nước mưa cuốn chất hữu cơ từ bề mặt, hoặc tảo phát triển mạnh.

## Khuyến nghị
Truy vết nguồn thải ở thượng lưu. Theo dõi DO và amoni cùng lúc vì chất hữu cơ cao thường làm DO giảm. Khi dùng thiết bị đo gián tiếp, đối chiếu định kỳ với kết quả phân tích mẫu tại phòng thí nghiệm.
