---
id: sys_faq
title: Câu hỏi thường gặp về hệ thống
type: system
params: []
source: system
verified: false
---
# Câu hỏi thường gặp về hệ thống

## Cờ chất lượng dữ liệu
Mỗi giá trị đo được kiểm tra. Giá trị ngoài khoảng vật lý bị bỏ và gắn cờ không hợp lệ. Giá trị ngoài khoảng hợp lý được lưu nhưng gắn cờ nghi ngờ và không dùng để tính WQI hay đánh giá luật. Trường hợp này sinh cảnh báo lỗi cảm biến.

## Cảnh báo lặp
Cùng một luật trên cùng một trạm không gửi lại trong thời gian chờ. Khi điều kiện hết, cảnh báo được đóng tự động. Người vận hành có thể xác nhận đã xem một cảnh báo.

## Dự báo WQI
Dự báo là ước lượng thống kê từ chuỗi WQI trước đó, kèm khoảng bất định. Dự báo chỉ đáng tin khi chuỗi dữ liệu đủ dài và đều. Dữ liệu lịch sử của bộ CNEMC là dữ liệu theo tuần, nên mỗi bước dự báo tương ứng một tuần.

## Giới hạn của hệ thống
WQI trong hệ thống là chỉ số rút gọn mang tính minh họa. Mô hình ngôn ngữ nhỏ có thể diễn đạt sai, vì vậy mọi con số trong câu trả lời được kiểm tra lại với kết quả của hệ thống; nếu không khớp, hệ thống dùng câu trả lời mẫu. Hệ thống không thay thế đánh giá của chuyên gia.
