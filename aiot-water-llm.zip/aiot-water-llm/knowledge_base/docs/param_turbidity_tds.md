---
id: param_turbidity_tds
title: Độ đục và TDS
type: parameter
params: [turbidity_ntu, tds_ppm]
source: general
verified: false
---
# Độ đục và TDS

## Ý nghĩa
Độ đục (NTU) cho biết mức độ nước bị vẩn đục do chất rắn lơ lửng như phù sa, chất hữu cơ và tảo. TDS (ppm, xấp xỉ mg/L) là tổng chất rắn hòa tan, thường được cảm biến suy ra gián tiếp từ độ dẫn điện nên chịu ảnh hưởng của nhiệt độ. Quy chuẩn QCVN 08:2023/BTNMT không có thông số độ đục; ngưỡng độ đục của hệ thống là ngưỡng vận hành nội bộ.

## Nguyên nhân thường gặp khi bất thường
Độ đục tăng thường do mưa lớn cuốn phù sa, xả thải, nạo vét hoặc thi công gần trạm, tảo nở hoa. TDS tăng có thể do xả thải chứa muối, xâm nhập mặn, hoặc nước chảy qua vùng đất nhiễm phèn hoặc khoáng.

## Khuyến nghị
Đối chiếu với lượng mưa và thời điểm xả thải. Vệ sinh đầu đo độ đục nếu bị bám bẩn hoặc rêu. Kiểm tra bù nhiệt độ của cảm biến TDS và hiệu chuẩn bằng dung dịch chuẩn khi nghi ngờ sai lệch.
