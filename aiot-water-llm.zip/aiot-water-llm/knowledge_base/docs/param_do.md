---
id: param_do
title: Oxy hòa tan (DO)
type: parameter
params: [do_mgL]
source: general
verified: false
---
# Oxy hòa tan (DO)

## Ý nghĩa
DO (oxy hòa tan) là lượng oxy tan trong nước, đơn vị mg/L. Sinh vật thủy sinh cần oxy hòa tan để hô hấp, và DO giảm thường là dấu hiệu ô nhiễm chất hữu cơ. Giá trị DO được so với quy chuẩn bằng điều kiện "lớn hơn hoặc bằng": DO càng cao càng tốt.

## Nguyên nhân thường gặp khi bất thường
DO thấp thường do nước thải chứa nhiều chất hữu cơ (sinh hoạt, chăn nuôi, chế biến thực phẩm) khiến vi sinh vật tiêu thụ oxy khi phân hủy; nhiệt độ nước cao làm oxy tan được ít hơn; nước ít lưu thông hoặc tù đọng; tảo chết hàng loạt rồi phân hủy; ban đêm tảo và thực vật thủy sinh hô hấp nên DO thường thấp nhất gần sáng. DO cao bất thường có thể do tảo quang hợp mạnh vào ban ngày hoặc do sai số của đầu đo.

## Khuyến nghị
Kiểm tra nguồn xả thải gần trạm và thời điểm DO bắt đầu giảm. Đối chiếu thêm NH4N, CODMn hoặc COD và nhiệt độ để xác định nguyên nhân. Nếu là ao hồ nuôi trồng, tăng sục khí hoặc tăng lưu thông và giảm lượng chất hữu cơ đầu vào. Nếu DO giảm đột ngột hoặc dao động bất thường, kiểm tra và hiệu chuẩn đầu đo DO (màng, điện cực, bù nhiệt độ).
