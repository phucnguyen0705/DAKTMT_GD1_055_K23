---
id: param_nh4n
title: Amoni (NH4-N)
type: parameter
params: [nh4n_mgL]
source: general
verified: false
---
# Amoni (NH4-N)

## Ý nghĩa
NH4-N là amoni tính theo nitơ, đơn vị mg/L. Đây là chỉ thị ô nhiễm từ nước thải sinh hoạt, chăn nuôi và phân bón. Độc tính với cá phụ thuộc vào phần amoniac tự do (NH3), phần này tăng khi pH và nhiệt độ nước cao.

## Nguyên nhân thường gặp khi bất thường
Amoni cao thường do xả thải sinh hoạt hoặc chăn nuôi chưa xử lý, nước chảy tràn từ đất bón phân, phân hủy xác sinh vật, hoặc đáy hồ thiếu oxy giải phóng amoni.

## Khuyến nghị
Truy vết nguồn thải ở thượng lưu. Kiểm tra DO đồng thời, vì quá trình nitrat hóa amoni tiêu thụ oxy nên amoni cao thường đi kèm DO giảm. Kiểm soát lượng phân bón và nước thải chăn nuôi. Với nuôi trồng thủy sản, theo dõi amoni cùng pH và nhiệt độ.
