---
id: std_qcvn08_2023
title: QCVN 08:2023/BTNMT - Quy chuẩn kỹ thuật quốc gia về chất lượng nước mặt
type: standard
source: qcvn08_2023
verified: false
params: [ph, do_mgL, bod5_mgL, cod_mgL, toc_mgL, tss_mgL, tp_mgL, tn_mgL]
---
# QCVN 08:2023/BTNMT - Quy chuẩn kỹ thuật quốc gia về chất lượng nước mặt

*Tài liệu sinh tự động từ config/standards.yaml. Phạm vi: Bảng 2: sông, suối, kênh, mương, khe, rạch.*

## Trạng thái kiểm chứng
Trạng thái: CHƯA đối chiếu văn bản gốc. Trích bằng công cụ đọc web từ bản PDF đăng trên sonnmt.langson.gov.vn (2026-10-11); cần đối chiếu bản gốc.
Nguồn tham khảo: https://sonnmt.langson.gov.vn/upload/105376/20250319/01-btnmt-qc08_1c394.pdf

## Phân loại và mục đích sử dụng
Các mức/lớp theo thứ tự từ tốt đến kém: A, B, C, D.
Mức/lớp A: Cấp nước sinh hoạt, bơi lội, vui chơi dưới nước, sau khi xử lý phù hợp.
Mức/lớp B: Sản xuất công nghiệp, nông nghiệp, sau khi xử lý phù hợp.
Mức/lớp C: Sản xuất công nghiệp, sau khi xử lý phù hợp; nước không gây mùi khó chịu.
Mức/lớp D: Giao thông thủy và các mục đích khác yêu cầu chất lượng nước thấp.
Mức phân loại là A, B, C, D. Cách gọi A1/A2/B1/B2 thuộc QCVN 08-MT:2015/BTNMT, không dùng cho bản 2023.
Với nước mặt nhiễm mặn, văn bản yêu cầu dùng TOC thay cho COD khi phân loại (mục 2.3).
Văn bản không có thông số độ đục. Amoni (NH4+ tính theo N) chỉ xuất hiện ở Bảng 1 với giới hạn 0,3 mg/L (chưa kiểm chứng), không có trong Bảng 2.

## Bảng giá trị giới hạn

| Thông số | Đơn vị | A | B | C | D |
|---|---|---|---|---|---|
| pH | - | 6.5–8.5 | 6–8.5 | 6–8.5 | — |
| DO | mg/L | ≥ 6 | ≥ 5 | ≥ 4 | ≥ 2 |
| BOD5 | mg/L | ≤ 4 | ≤ 6 | ≤ 10 | — |
| COD | mg/L | ≤ 10 | ≤ 15 | ≤ 20 | — |
| TOC | mg/L | ≤ 4 | ≤ 6 | ≤ 8 | — |
| TSS | mg/L | ≤ 25 | ≤ 100 | — | — |
| Tổng phốt pho (TP) | mg/L | ≤ 0.1 | ≤ 0.3 | ≤ 0.5 | — |
| Tổng nitơ (TN) | mg/L | ≤ 0.6 | ≤ 1.5 | ≤ 2 | — |

Ký hiệu —: không có cận số riêng cho mức/lớp đó (xem ghi chú của từng thông số).

## pH
pH theo QCVN 08:2023/BTNMT: mức A: 6.5–8.5; mức B: 6–8.5; mức C: 6–8.5. Mức D: nhỏ hơn 6,0 hoặc lớn hơn 8,5.

## DO
DO theo QCVN 08:2023/BTNMT: mức A: ≥ 6 mg/L; mức B: ≥ 5 mg/L; mức C: ≥ 4 mg/L; mức D: ≥ 2 mg/L.

## BOD5
BOD5 theo QCVN 08:2023/BTNMT: mức A: ≤ 4 mg/L; mức B: ≤ 6 mg/L; mức C: ≤ 10 mg/L. Mức D: lớn hơn 10.

## COD
COD theo QCVN 08:2023/BTNMT: mức A: ≤ 10 mg/L; mức B: ≤ 15 mg/L; mức C: ≤ 20 mg/L. Mức D: lớn hơn 20.

## TOC
TOC theo QCVN 08:2023/BTNMT: mức A: ≤ 4 mg/L; mức B: ≤ 6 mg/L; mức C: ≤ 8 mg/L. Mức D: lớn hơn 8.

## TSS
TSS theo QCVN 08:2023/BTNMT: mức A: ≤ 25 mg/L; mức B: ≤ 100 mg/L. Mức C: lớn hơn 100 và không có rác nổi; mức D: lớn hơn 100 và có rác nổi.

## Tổng phốt pho (TP)
Tổng phốt pho (TP) theo QCVN 08:2023/BTNMT: mức A: ≤ 0.1 mg/L; mức B: ≤ 0.3 mg/L; mức C: ≤ 0.5 mg/L. Mức D: lớn hơn 0,5.

## Tổng nitơ (TN)
Tổng nitơ (TN) theo QCVN 08:2023/BTNMT: mức A: ≤ 0.6 mg/L; mức B: ≤ 1.5 mg/L; mức C: ≤ 2 mg/L. Mức D: lớn hơn 2,0.
