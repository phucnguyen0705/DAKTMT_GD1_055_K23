---
id: sys_rules
title: Quy tắc cảnh báo của hệ thống
type: system
source: rules.yaml
verified: false
params: []
---
# Quy tắc cảnh báo của hệ thống

*Tài liệu sinh tự động từ policy/rules.yaml.*

## Nguyên tắc
Cảnh báo do luật tường minh quyết định, không do mô hình ngôn ngữ. Mô hình chỉ diễn giải. Tất cả luật khớp đều được ghi nhận. Cùng một luật trên cùng một trạm không gửi lại trong thời gian chờ (cooldown). Khi điều kiện hết, cảnh báo tự chuyển sang trạng thái đã xử lý.

## Luật wqi_critical
Luật wqi_critical (mức critical): WQI ở mức rất kém (dưới 26). Điều kiện: wqi < 26. Tiêu chuẩn tham chiếu: operational. Hành động: notify_telegram, notify_email, trigger_llm_report, recommend_stop_usage.

## Luật wqi_poor
Luật wqi_poor (mức warning): WQI ở mức kém (từ 26 đến dưới 51). Điều kiện: 26 <= wqi < 51. Tiêu chuẩn tham chiếu: operational. Hành động: notify_telegram, trigger_llm_report.

## Luật ph_out_of_range
Luật ph_out_of_range (mức warning): pH ngoài khoảng 6.0-8.5 (mức D của QCVN 08:2023/BTNMT Bảng 2 là pH nhỏ hơn 6.0 hoặc lớn hơn 8.5). Điều kiện: ph < 6.0 or ph > 8.5. Tiêu chuẩn tham chiếu: qcvn08_2023. Hành động: notify_telegram, trigger_llm_report.

## Luật do_low
Luật do_low (mức warning): DO dưới 4.0 mg/L (thấp hơn mức C của QCVN 08:2023/BTNMT Bảng 2). Điều kiện: do_mgL < 4.0 and do_mgL >= 2.0. Tiêu chuẩn tham chiếu: qcvn08_2023. Hành động: notify_telegram, trigger_llm_report.

## Luật do_critical_low
Luật do_critical_low (mức critical): DO dưới 2.0 mg/L (thấp hơn cả mức D của QCVN 08:2023/BTNMT Bảng 2), nguy cơ thiếu oxy cho thủy sinh. Điều kiện: do_mgL < 2.0. Tiêu chuẩn tham chiếu: qcvn08_2023. Hành động: notify_telegram, notify_email, trigger_llm_report.

## Luật nh4n_high
Luật nh4n_high (mức warning): Amoni (NH4-N) trên 1.0 mg/L (vượt lớp III của GB 3838-2002). Điều kiện: nh4n_mgL > 1.0 and nh4n_mgL <= 2.0. Tiêu chuẩn tham chiếu: gb3838_2002. Hành động: notify_telegram, trigger_llm_report.

## Luật nh4n_critical
Luật nh4n_critical (mức critical): Amoni (NH4-N) trên 2.0 mg/L (vượt cả lớp V của GB 3838-2002). Điều kiện: nh4n_mgL > 2.0. Tiêu chuẩn tham chiếu: gb3838_2002. Hành động: notify_telegram, notify_email, trigger_llm_report.

## Luật codmn_high
Luật codmn_high (mức warning): CODMn trên 6 mg/L (vượt lớp III của GB 3838-2002). Điều kiện: codmn_mgL > 6.0. Tiêu chuẩn tham chiếu: gb3838_2002. Hành động: notify_telegram, trigger_llm_report.

## Luật turbidity_high
Luật turbidity_high (mức warning): Độ đục trên 50 NTU, có thể do mưa lớn hoặc xả thải (ngưỡng vận hành nội bộ). Điều kiện: turbidity_ntu > 50. Tiêu chuẩn tham chiếu: operational. Hành động: notify_telegram.

## Luật normal_condition
Luật normal_condition (mức info): Chất lượng nước tốt (WQI từ 76 trở lên). Điều kiện: wqi >= 76. Tiêu chuẩn tham chiếu: operational. Hành động: log_only.
