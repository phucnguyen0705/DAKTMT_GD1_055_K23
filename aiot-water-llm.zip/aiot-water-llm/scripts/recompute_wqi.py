"""Tính lại WQI cho toàn bộ bản ghi sau khi sửa config/wqi.yaml (không cần nạp lại dữ liệu)."""
from __future__ import annotations

from config.settings import get_settings
from data_processing.wqi_calculator import WQIConfig, compute_wqi
from storage.db import Storage


def recompute(storage: Storage, cfg: WQIConfig) -> int:
    n = 0
    for batch in storage.iter_readings():
        ups = []
        for r in batch:
            usable = {k: v for k, v in r["values"].items() if v is not None and k not in r["flags"]}
            w = compute_wqi(usable, cfg)
            ups.append((w.wqi, w.label, r["id"]))
        storage.update_reading_wqi(ups)
        n += len(ups)
    return n


if __name__ == "__main__":
    s = get_settings()
    print("đã cập nhật", recompute(Storage(s.DB_PATH), WQIConfig.load(s.WQI_CONFIG_PATH)), "bản ghi")
