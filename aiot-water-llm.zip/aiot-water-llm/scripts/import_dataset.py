"""Nạp bộ dữ liệu quan trắc lịch sử (parquet) vào SQLite: kiểm tra chất lượng từng giá trị + tính WQI.
Không sinh cảnh báo (đây là dữ liệu lịch sử).  station_id = '<nguồn>-<id gốc>' để tránh trùng giữa các nguồn.

  python -m scripts.import_dataset --sources CNEMC [--limit-stations 20]
"""
from __future__ import annotations

import argparse
import json

from config.registry import ParameterRegistry
from config.settings import get_settings
from data_processing.dataset import load_wide
from data_processing.wqi_calculator import WQIConfig, compute_wqi
from storage.db import Storage, to_iso


def import_dataset(storage: Storage, registry: ParameterRegistry, wqi_cfg: WQIConfig, parquet: str,
                   sources: list[str] | None, limit_stations: int | None = None) -> dict:
    df = load_wide(parquet, registry, sources)
    cols = [c for c in df.columns if c in registry.specs]
    if limit_stations:
        keep = df.groupby(["source", "station_id"]).size().sort_values(ascending=False).head(limit_stations).index
        df = df.set_index(["source", "station_id"]).loc[keep].reset_index()
    stations, rows, flagged = {}, [], 0
    for r in df.itertuples(index=False):
        sid = f"{r.source}-{r.station_id}"
        stations[sid] = (sid, sid, getattr(r, "lat", None), getattr(r, "lon", None), r.source)
        values, flags = {}, {}
        for c in cols:
            v = getattr(r, c)
            st = registry.check(c, None if v != v else v)
            if st == "missing":
                continue
            if st in ("ok", "suspect"):
                values[c] = float(v)
            else:
                values[c] = None
            if st != "ok":
                flags[c] = st
                flagged += 1
        usable = {k: v for k, v in values.items() if v is not None and k not in flags}
        w = compute_wqi(usable, wqi_cfg)
        rows.append((sid, None, to_iso(r.date), json.dumps(values), json.dumps(flags), w.wqi, w.label, r.source))
    for s in stations.values():
        storage.upsert_station(s[0], name=s[1], lat=s[2], lon=s[3], source=s[4])
    n = storage.add_readings_bulk(rows)
    return {"stations": len(stations), "rows_in": len(rows), "rows_inserted": n, "flagged_values": flagged}


def main() -> None:
    s = get_settings()
    ap = argparse.ArgumentParser()
    ap.add_argument("--parquet", default=str(__import__("config.settings", fromlist=["ROOT_DIR"]).ROOT_DIR / "data/processed/water_quality_wide.parquet"))
    ap.add_argument("--sources", nargs="*", default=["CNEMC"])
    ap.add_argument("--limit-stations", type=int, default=None)
    a = ap.parse_args()
    st = Storage(s.DB_PATH)
    print(json.dumps(import_dataset(st, ParameterRegistry.load(s.PARAMETERS_PATH), WQIConfig.load(s.WQI_CONFIG_PATH),
                                    a.parquet, a.sources, a.limit_stations), indent=2))


if __name__ == "__main__":
    main()
