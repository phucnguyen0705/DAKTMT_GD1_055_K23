"""Huấn luyện mô hình dự báo WQI từ dữ liệu trong DB:  python -m scripts.train_forecaster [--source CNEMC]"""
from __future__ import annotations

import argparse
import json

from config.settings import get_settings
from forecasting.train import train_forecaster
from storage.db import Storage

if __name__ == "__main__":
    s = get_settings()
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", default="CNEMC")
    a = ap.parse_args()
    print(json.dumps(train_forecaster(Storage(s.DB_PATH), s.MODELS_DIR, source=a.source), indent=2))
