"""Tạo dữ liệu demo nhỏ (3 trạm mô phỏng: bình thường / ô nhiễm / lỗi cảm biến) qua đường ingest thật.
Chạy khi API KHÔNG cần chạy:  python -m scripts.seed_demo"""
from __future__ import annotations

import random
from datetime import datetime, timedelta, timezone

from backend.app.context import AppContext
from config.settings import get_settings
from devices.simulator import generate


def seed_demo(ctx: AppContext, n: int = 72) -> dict:
    start = datetime(2025, 6, 1, tzinfo=timezone.utc)
    for station, scenario in (("DEMO-OK", "normal"), ("DEMO-POLLUTED", "pollution"), ("DEMO-FAULT", "sensor_fault")):
        rng = random.Random(station)
        for k in range(n):
            ctx.ingest.process(station, generate(scenario, k, rng, n), ts=start + timedelta(hours=k), source="demo")
    return {"stations": ["DEMO-OK", "DEMO-POLLUTED", "DEMO-FAULT"], "readings": n * 3}


if __name__ == "__main__":
    print(seed_demo(AppContext.build(get_settings(), llm=None)))
