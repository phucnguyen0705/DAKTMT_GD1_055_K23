"""
Sinh các tài liệu knowledge base có số liệu từ file cấu hình, để RAG không bao giờ lệch với cấu hình:

    knowledge_base/docs/std_<id>.md   <- config/standards.yaml
    knowledge_base/docs/sys_wqi.md    <- config/wqi.yaml
    knowledge_base/docs/sys_rules.md  <- policy/rules.yaml

Chạy:  python -m scripts.build_kb          (ghi đè các file trên)
       python -m scripts.build_kb --check  (chỉ kiểm tra có lệch không; dùng trong test/CI)
Các tài liệu viết tay (param_*.md, guide_*.md, sys_faq.md) không bị đụng tới.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict

import yaml

ROOT = Path(__file__).resolve().parent.parent
DOCS = ROOT / "knowledge_base" / "docs"


def _fmt(v) -> str:
    if isinstance(v, (list, tuple)):
        return f"{v[0]:g}–{v[1]:g}"
    return f"{v:g}"


def _limit_sentence(kind: str, cls: str, lim, unit: str) -> str:
    u = f" {unit}" if unit else ""
    if kind == "range":
        return f"mức {cls}: {_fmt(lim)}{u}".strip()
    sign = "≥" if kind == "min" else "≤"
    return f"mức {cls}: {sign} {_fmt(lim)}{u}"


def build_standard_doc(sid: str, s: dict) -> str:
    classes = s["classes"]
    lines = [
        "---", f"id: std_{sid}", f"title: {s['name']}", "type: standard", f"source: {sid}",
        f"verified: {str(bool(s.get('verified', False))).lower()}", "params: [" + ", ".join(s["parameters"]) + "]", "---",
        f"# {s['name']}", "",
        f"*Tài liệu sinh tự động từ config/standards.yaml. Phạm vi: {s.get('scope', '')}.*", "",
        "## Trạng thái kiểm chứng",
        f"Trạng thái: {'đã đối chiếu văn bản gốc' if s.get('verified') else 'CHƯA đối chiếu văn bản gốc'}. {s.get('verification', '')}".strip(),
        f"Nguồn tham khảo: {s.get('source_url', '')}", "",
        "## Phân loại và mục đích sử dụng",
        f"Các mức/lớp theo thứ tự từ tốt đến kém: {', '.join(classes)}.",
    ]
    for c in classes:
        if c in s.get("class_usage", {}):
            lines.append(f"Mức/lớp {c}: {s['class_usage'][c]}.")
    for n in s.get("notes", []):
        lines.append(n if n.endswith(".") else n + ".")
    lines += ["", "## Bảng giá trị giới hạn", "",
              "| Thông số | Đơn vị | " + " | ".join(classes) + " |", "|---|---|" + "---|" * len(classes)]
    for key, p in s["parameters"].items():
        cells = []
        for c in classes:
            lim = p["limits"].get(c)
            cells.append("—" if lim is None else (("" if p["kind"] == "range" else ("≥ " if p["kind"] == "min" else "≤ ")) + _fmt(lim)))
        lines.append(f"| {p['label']} | {p.get('unit') or '-'} | " + " | ".join(cells) + " |")
    lines.append("")
    lines.append("Ký hiệu —: không có cận số riêng cho mức/lớp đó (xem ghi chú của từng thông số).")
    for key, p in s["parameters"].items():
        parts = [_limit_sentence(p["kind"], c, p["limits"][c], p.get("unit", "")) for c in classes if p["limits"].get(c) is not None]
        text = f"{p['label']} theo {s['name'].split(' - ')[0]}: " + "; ".join(parts) + "."
        if p.get("note"):
            text += " " + p["note"]
        lines += ["", f"## {p['label']}", text]
    return "\n".join(lines) + "\n"


def build_wqi_doc(w: dict) -> str:
    lines = [
        "---", "id: sys_wqi", "title: Cách hệ thống tính WQI", "type: system", "source: wqi.yaml", "verified: false",
        "params: [" + ", ".join(w["parameters"]) + "]", "---",
        "# Cách hệ thống tính WQI", "",
        f"*Tài liệu sinh tự động từ config/wqi.yaml (phiên bản {w['version']}).*", "",
        "## Tổng quan",
        "WQI của hệ thống là chỉ số RÚT GỌN mang tính minh họa, chưa phải chỉ số chính thức. Mỗi thông số có mặt trong mẫu đo được quy đổi "
        "về điểm 0-100 bằng nội suy tuyến tính giữa các điểm neo, sau đó lấy trung bình có trọng số trên các thông số có mặt "
        f"(trọng số chuẩn hóa lại). Cần tối thiểu {w.get('min_params', 2)} thông số. Giá trị bị gắn cờ nghi ngờ không được dùng.",
        "", "## Phân loại WQI",
    ]
    for c in w["classes"]:
        lines.append(f"WQI từ {c['min']:g} trở lên: {c['label']}." if c["min"] else f"WQI dưới mức trên: {c['label']}.")
    for key, p in w["parameters"].items():
        pts = ", ".join(f"{x:g}→{y:g}" for x, y in p["points"])
        if p["weight"] > 0:
            lines += ["", f"## Điểm của {key}", f"Trọng số {p['weight']:g}. Điểm neo (giá trị→điểm): {pts}."]
        else:
            lines += ["", f"## Điểm của {key}", "Không tham gia WQI (chỉ hiển thị)."]
    return "\n".join(lines) + "\n"


def build_rules_doc(r: dict) -> str:
    lines = [
        "---", "id: sys_rules", "title: Quy tắc cảnh báo của hệ thống", "type: system", "source: rules.yaml", "verified: false",
        "params: []", "---", "# Quy tắc cảnh báo của hệ thống", "",
        "*Tài liệu sinh tự động từ policy/rules.yaml.*", "",
        "## Nguyên tắc",
        "Cảnh báo do luật tường minh quyết định, không do mô hình ngôn ngữ. Mô hình chỉ diễn giải. Tất cả luật khớp đều được ghi nhận. "
        "Cùng một luật trên cùng một trạm không gửi lại trong thời gian chờ (cooldown). Khi điều kiện hết, cảnh báo tự chuyển sang trạng thái đã xử lý.",
    ]
    for rule in r["rules"]:
        lines += ["", f"## Luật {rule['id']}",
                  f"Luật {rule['id']} (mức {rule['severity']}): {rule['description']}. Điều kiện: {rule['condition']}. "
                  f"Tiêu chuẩn tham chiếu: {rule.get('standard', 'không')}. Hành động: {', '.join(rule.get('actions', [])) or 'không'}."]
    return "\n".join(lines) + "\n"


def build_all(root: Path = ROOT) -> Dict[str, str]:
    standards = yaml.safe_load((root / "config" / "standards.yaml").read_text(encoding="utf-8"))
    wqi = yaml.safe_load((root / "config" / "wqi.yaml").read_text(encoding="utf-8"))
    rules = yaml.safe_load((root / "policy" / "rules.yaml").read_text(encoding="utf-8"))
    out = {f"std_{sid}.md": build_standard_doc(sid, s) for sid, s in standards.items()}
    out["sys_wqi.md"] = build_wqi_doc(wqi)
    out["sys_rules.md"] = build_rules_doc(rules)
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="chỉ kiểm tra tài liệu có khớp cấu hình không")
    args = ap.parse_args(argv)
    DOCS.mkdir(parents=True, exist_ok=True)
    stale = []
    for name, text in build_all().items():
        path = DOCS / name
        if args.check:
            if not path.exists() or path.read_text(encoding="utf-8") != text:
                stale.append(name)
        else:
            path.write_text(text, encoding="utf-8")
            print("ghi", path.relative_to(ROOT))
    if args.check and stale:
        print("Tài liệu KB lệch với cấu hình, hãy chạy: python -m scripts.build_kb ->", ", ".join(stale))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
