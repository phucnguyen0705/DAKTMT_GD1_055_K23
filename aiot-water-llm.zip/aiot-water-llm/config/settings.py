"""
Cấu hình trung tâm cho toàn bộ hệ thống (đọc từ biến môi trường / file .env).
Xem .env.example để biết cần khai báo gì.

Sử dụng:
    from config.settings import get_settings
    s = get_settings()

Trong test hoặc khi muốn chạy nhiều cấu hình: tạo thẳng `Settings(DB_PATH=..., ...)`
rồi truyền cho `create_app(settings)`; không phụ thuộc biến toàn cục.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    # ---------------- LLM (Ollama / OpenAI-compatible) ----------------
    LLM_PROVIDER: str = "ollama"                 # ollama | openai_compatible
    LLM_MODEL_NAME: str = "qwen2.5:1.5b"         # tên model trong Ollama (kiểm tra bằng `ollama list`)
    LLM_BASE_URL: str = "http://localhost:11434"  # Ollama gốc; với openai_compatible thì thêm /v1
    LLM_API_KEY: str = ""
    LLM_TIMEOUT_SEC: float = 120.0
    LLM_NUM_CTX: int = 4096
    LLM_NUM_THREAD: int = 0                      # 0 = để Ollama tự chọn
    LLM_NUM_GPU: int = -1                        # -1 = tự chọn; số layer đẩy lên GPU nếu muốn ép
    LLM_TEMPERATURE: float = 0.1
    LLM_KEEP_ALIVE: str = "30m"
    LLM_PRICE_PER_1K_TOKENS: float = 0.0         # chỉ để tính chi phí khi so sánh với dịch vụ cloud

    # ---------------- Orchestrator ----------------
    ROUTER_MODE: str = "llm_with_fallback"       # llm_with_fallback | llm | rules
    COMPOSE_MODE: str = "llm_with_check"         # llm_with_check | template
    GROUNDING_MODE: str = "strict"               # strict | warn | off
    RAG_TOP_K: int = 3
    DEFAULT_CHART_POINTS: int = 120

    # ---------------- Tri thức / RAG ----------------
    KB_DIR: str = str(ROOT_DIR / "knowledge_base")
    RETRIEVER: str = "bm25"                      # bm25 | chroma
    EMBEDDING_MODEL_NAME: str = "intfloat/multilingual-e5-small"
    VECTOR_DB_PATH: str = str(ROOT_DIR / "knowledge_base" / "index")
    VECTOR_DB_COLLECTION: str = "water_quality_docs"

    # ---------------- Dữ liệu & mô hình ----------------
    DB_PATH: str = str(ROOT_DIR / "data" / "aiot.db")
    CHARTS_DIR: str = str(ROOT_DIR / "data" / "charts")
    MODELS_DIR: str = str(ROOT_DIR / "models")
    WQI_CONFIG_PATH: str = str(ROOT_DIR / "config" / "wqi.yaml")
    STANDARDS_PATH: str = str(ROOT_DIR / "config" / "standards.yaml")
    PARAMETERS_PATH: str = str(ROOT_DIR / "config" / "parameters.yaml")
    RULES_PATH: str = str(ROOT_DIR / "policy" / "rules.yaml")
    EVAL_RESULTS_DIR: str = str(ROOT_DIR / "evaluation" / "results")

    # ---------------- Thiết bị / ingest ----------------
    REQUIRE_INGEST_AUTH: bool = False            # đặt True khi triển khai thật
    INGEST_SERVICE_KEY: str = ""                 # khóa cho bridge MQTT / simulator
    ADMIN_API_KEY: str = ""                      # khóa cho API quản trị thiết bị (rỗng = mở, chỉ dùng khi dev)
    DEVICE_OFFLINE_AFTER_SEC: int = 600
    MQTT_BROKER_HOST: str = "localhost"
    MQTT_BROKER_PORT: int = 1883
    MQTT_USERNAME: str = ""
    MQTT_PASSWORD: str = ""
    MQTT_TOPIC_ROOT: str = "aiot/water"          # aiot/water/<station_id>/<device_id>/telemetry
    API_URL: str = "http://localhost:8000"       # bridge / simulator / UI gọi tới API này

    # ---------------- Cảnh báo ----------------
    ALERT_COOLDOWN_MIN: int = 60
    WQI_ALERT_THRESHOLD: float = 50.0
    TELEGRAM_BOT_TOKEN: str = ""
    TELEGRAM_CHAT_ID: str = ""
    SMTP_HOST: str = ""
    SMTP_PORT: int = 587
    SMTP_USERNAME: str = ""
    SMTP_PASSWORD: str = ""
    ALERT_EMAIL_TO: str = ""

    # ---------------- API / UI ----------------
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000
    CORS_ORIGINS: str = "*"                      # danh sách phân tách bằng dấu phẩy; siết lại khi triển khai
    STREAMLIT_SERVER_PORT: int = 8501

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
