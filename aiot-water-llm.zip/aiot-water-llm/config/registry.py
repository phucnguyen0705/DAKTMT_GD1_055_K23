"""
Nạp và tra cứu: đăng ký thông số (parameters.yaml) và tiêu chuẩn (standards.yaml).

- ParameterRegistry: tên chuẩn <-> bí danh, nhãn, đơn vị, kiểm tra khoảng giá trị.
- Standards: phân lớp một giá trị theo tiêu chuẩn, trả về các đường ngưỡng để vẽ biểu đồ.
"""
from __future__ import annotations

import math
import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

CONFIG_DIR = Path(__file__).resolve().parent


# --------------------------------------------------------------------------- văn bản
def strip_accents(text: str) -> str:
    """Bỏ dấu tiếng Việt (kể cả đ/Đ) để so khớp không phân biệt dấu."""
    text = text.replace("đ", "d").replace("Đ", "D")
    text = unicodedata.normalize("NFD", text)
    return "".join(c for c in text if unicodedata.category(c) != "Mn")


def norm_text(text: str) -> str:
    """Chữ thường, không dấu, gộp khoảng trắng."""
    return re.sub(r"\s+", " ", strip_accents(text).lower()).strip()


# --------------------------------------------------------------------------- thông số
@dataclass(frozen=True)
class ParameterSpec:
    key: str
    label: str
    unit: str
    decimals: int
    physical: Tuple[float, float]
    plausible: Tuple[float, float]
    aliases: Tuple[str, ...] = ()
    synonyms: Tuple[str, ...] = ()


class ParameterRegistry:
    def __init__(self, specs: Dict[str, ParameterSpec]):
        self.specs = specs
        self._alias: Dict[str, str] = {}
        for key, spec in specs.items():
            self._alias[key.lower()] = key
            for a in spec.aliases:
                self._alias[a.lower()] = key

    @classmethod
    def load(cls, path: str | Path | None = None) -> "ParameterRegistry":
        path = Path(path) if path else CONFIG_DIR / "parameters.yaml"
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))["parameters"]
        specs = {}
        for key, p in raw.items():
            specs[key] = ParameterSpec(
                key=key, label=p["label"], unit=p.get("unit", ""), decimals=int(p.get("decimals", 2)),
                physical=tuple(p["physical"]), plausible=tuple(p["plausible"]),
                aliases=tuple(p.get("aliases", [])), synonyms=tuple(p.get("synonyms", [])),
            )
        return cls(specs)

    @property
    def keys(self) -> List[str]:
        return list(self.specs)

    def canonical(self, name: str) -> Optional[str]:
        """'DO' -> 'do_mgL', 'pH' -> 'ph'; không biết thì trả None."""
        return self._alias.get(str(name).strip().lower())

    def label(self, key: str) -> str:
        return self.specs[key].label if key in self.specs else key

    def unit(self, key: str) -> str:
        return self.specs[key].unit if key in self.specs else ""

    def format(self, key: str, value: float) -> str:
        spec = self.specs.get(key)
        if spec is None:
            return f"{value:g}"
        text = f"{value:.{spec.decimals}f}"
        return f"{text} {spec.unit}".strip()

    def check(self, key: str, value: Any) -> str:
        """Trả về 'ok' | 'suspect' | 'invalid' | 'missing'."""
        if value is None:
            return "missing"
        try:
            v = float(value)
        except (TypeError, ValueError):
            return "invalid"
        if math.isnan(v) or math.isinf(v):
            return "invalid"
        spec = self.specs.get(key)
        if spec is None:
            return "ok"
        if not (spec.physical[0] <= v <= spec.physical[1]):
            return "invalid"
        if not (spec.plausible[0] <= v <= spec.plausible[1]):
            return "suspect"
        return "ok"

    def detect_in_text(self, norm_question: str) -> Optional[str]:
        """Tìm thông số được nhắc tới trong câu hỏi (đã norm_text). Ưu tiên cụm dài nhất."""
        best: Tuple[int, Optional[str]] = (0, None)
        for key, spec in self.specs.items():
            for syn in spec.synonyms + (key.lower(),):
                pattern = r"(?<![a-z0-9])" + re.escape(syn) + r"(?![a-z0-9])"
                if re.search(pattern, norm_question) and len(syn) > best[0]:
                    best = (len(syn), key)
        return best[1]


# --------------------------------------------------------------------------- tiêu chuẩn
@dataclass
class ParamLimits:
    key: str
    label: str
    unit: str
    kind: str                               # min | max | range
    limits: Dict[str, Any]                  # lớp -> số | [lo, hi] | None
    note: str = ""


@dataclass
class Standard:
    id: str
    name: str
    scope: str
    classes: List[str]
    class_usage: Dict[str, str]
    parameters: Dict[str, ParamLimits]
    source_url: str = ""
    verified: bool = False
    verification: str = ""
    notes: List[str] = field(default_factory=list)

    def classify(self, key: str, value: float) -> Optional[str]:
        """Lớp TỐT NHẤT mà giá trị còn thoả. None nếu thông số không có trong tiêu chuẩn
        hoặc giá trị tệ hơn mọi lớp (chỉ xảy ra với DO thấp hơn mức cuối)."""
        pl = self.parameters.get(key)
        if pl is None:
            return None
        for cls in self.classes:
            lim = pl.limits.get(cls)
            if lim is None:                     # mức mở: thoả mọi giá trị còn lại
                return cls
            if pl.kind == "min" and value >= lim:
                return cls
            if pl.kind == "max" and value <= lim:
                return cls
            if pl.kind == "range" and lim[0] <= value <= lim[1]:
                return cls
        return None

    def limit_lines(self, key: str) -> List[Tuple[str, float]]:
        """Các đường ngưỡng (nhãn, giá trị) để vẽ lên biểu đồ."""
        pl = self.parameters.get(key)
        if pl is None:
            return []
        out: List[Tuple[str, float]] = []
        for cls in self.classes:
            lim = pl.limits.get(cls)
            if lim is None:
                continue
            if pl.kind == "range":
                out.append((f"{cls} min", float(lim[0])))
                out.append((f"{cls} max", float(lim[1])))
            else:
                sign = "≥" if pl.kind == "min" else "≤"
                out.append((f"{cls} {sign} {lim:g}", float(lim)))
        # bỏ trùng giá trị (pH các lớp B, C có cùng cận)
        seen, uniq = set(), []
        for lab, val in out:
            if val not in seen:
                seen.add(val)
                uniq.append((lab, val))
        return uniq


class Standards:
    def __init__(self, standards: Dict[str, Standard]):
        self.standards = standards

    @classmethod
    def load(cls, path: str | Path | None = None) -> "Standards":
        path = Path(path) if path else CONFIG_DIR / "standards.yaml"
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
        out: Dict[str, Standard] = {}
        for sid, s in raw.items():
            params = {
                k: ParamLimits(key=k, label=p["label"], unit=p.get("unit", ""), kind=p["kind"],
                               limits=p["limits"], note=p.get("note", ""))
                for k, p in s["parameters"].items()
            }
            out[sid] = Standard(
                id=sid, name=s["name"], scope=s.get("scope", ""), classes=list(s["classes"]),
                class_usage=s.get("class_usage", {}), parameters=params,
                source_url=s.get("source_url", ""), verified=bool(s.get("verified", False)),
                verification=s.get("verification", ""), notes=list(s.get("notes", [])),
            )
        return cls(out)

    def get(self, sid: str) -> Standard:
        return self.standards[sid]

    def __contains__(self, sid: str) -> bool:
        return sid in self.standards

    def ids(self) -> List[str]:
        return list(self.standards)
