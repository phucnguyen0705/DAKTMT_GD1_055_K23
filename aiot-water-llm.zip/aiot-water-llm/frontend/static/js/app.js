// Bản nhẹ: gọi cùng REST API với Streamlit. Mọi dữ liệu từ server đều gán qua textContent (không innerHTML).
const $ = (id) => document.getElementById(id);
let current = null;
const el = (tag, text, cls) => { const e = document.createElement(tag); if (text != null) e.textContent = text; if (cls) e.className = cls; return e; };
async function api(path, opts) {
  const r = await fetch(path, opts);
  if (!r.ok) throw new Error(r.status + ' ' + (await r.text()).slice(0, 200));
  return r.json();
}
async function loadHealth() {
  try { const h = await api('/api/health'); $('health').textContent = `LLM: ${h.llm_available ? 'sẵn sàng' : 'không kết nối'} · ${h.n_stations} trạm`; }
  catch (e) { $('health').textContent = 'API lỗi'; }
}
async function loadStations() {
  const ul = $('station-list'); ul.replaceChildren();
  for (const s of await api('/api/stations')) {
    const b = el('button', `${s.station_id}  ·  WQI ${s.wqi ?? '—'}`); b.onclick = () => select(s.station_id, b);
    const li = el('li'); li.append(b); ul.append(li);
  }
}
async function select(id, btn) {
  current = id;
  document.querySelectorAll('#station-list button').forEach((b) => b.classList.remove('sel')); btn.classList.add('sel');
  $('detail-title').textContent = `Trạm ${id}`;
  const s = await api(`/api/stations/${encodeURIComponent(id)}/status`);
  const box = $('status'); box.replaceChildren();
  if (!s.ok) { box.append(el('p', 'Chưa có dữ liệu')); return; }
  box.append(el('p', `WQI ${s.wqi ?? '—'} (${s.wqi_class ?? 'n/a'}) · mức ${s.severity} · ${s.ts}`));
  for (const p of s.parameters) box.append(el('div', `${p.label}: ${p.display}${p.flag ? ' ⚠ ' + p.flag : ''}`));
  const t = await api(`/api/stations/${encodeURIComponent(id)}/trend?chart=true`);
  const img = $('chart'); if (t.chart) { img.src = `/api/charts/${t.chart}`; img.hidden = false; } else img.hidden = true;
}
$('chat-form').onsubmit = async (ev) => {
  ev.preventDefault(); const q = $('q').value.trim(); if (!q) return; $('q').value = '';
  $('log').append(el('div', q, 'msg u'));
  try {
    const r = await api('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: q, station_id: current }) });
    $('log').append(el('div', r.answer, 'msg'));
    if (r.chart_url) { const i = el('img'); i.src = r.chart_url; i.style.maxWidth = '100%'; $('log').append(i); }
    $('log').append(el('div', `${r.intent} · ${r.grounded && !r.fallback_used ? 'số liệu khớp' : 'câu mẫu'} · ${Math.round(r.latency_ms.total)} ms`, 'meta'));
  } catch (e) { $('log').append(el('div', 'Lỗi: ' + e.message, 'msg')); }
  $('log').scrollTop = $('log').scrollHeight;
};
loadHealth(); loadStations();
