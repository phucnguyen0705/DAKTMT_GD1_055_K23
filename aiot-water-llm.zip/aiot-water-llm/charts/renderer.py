"""Vẽ biểu đồ bằng mã cố định (matplotlib). LLM chỉ chọn loại/thông số; không bao giờ tự viết mã vẽ."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


class ChartRenderer:
    def __init__(self, out_dir: str | Path):
        self.out = Path(out_dir)
        self.out.mkdir(parents=True, exist_ok=True)

    def _path(self, spec: dict) -> Path:
        h = hashlib.sha1(json.dumps(spec, sort_keys=True, default=str).encode()).hexdigest()[:12]
        return self.out / f"{spec.get('kind', 'chart')}_{h}.png"

    def _save(self, fig, path: Path) -> str:
        fig.tight_layout()
        fig.savefig(path, dpi=110)
        plt.close(fig)
        return path.name

    def line(self, spec: dict, ts: Sequence, ys: Sequence, title: str, ylabel: str,
             thresholds: dict[str, float] | None = None) -> str:
        path = self._path({**spec, "kind": "line", "n": len(ys), "last": str(ts[-1]) if len(ts) else ""})
        fig, ax = plt.subplots(figsize=(7, 3.4))
        ax.plot(ts, ys, marker="o", ms=3, lw=1.4)
        for label, v in (thresholds or {}).items():
            ax.axhline(v, ls="--", lw=1, color="tab:red", alpha=.7)
            ax.annotate(label, (ts[0], v), fontsize=8, color="tab:red", va="bottom")
        ax.set_title(title); ax.set_ylabel(ylabel); ax.grid(alpha=.3)
        fig.autofmt_xdate()
        return self._save(fig, path)

    def bar(self, spec: dict, labels: Sequence[str], values: Sequence[float], title: str, ylabel: str) -> str:
        path = self._path({**spec, "kind": "bar", "labels": list(labels), "values": list(values)})
        fig, ax = plt.subplots(figsize=(7, 3.4))
        ax.bar([str(x) for x in labels], values, color="tab:blue")
        ax.set_title(title); ax.set_ylabel(ylabel); ax.grid(axis="y", alpha=.3)
        return self._save(fig, path)

    def forecast(self, spec: dict, hist_ts: Sequence, hist: Sequence[float], fc: list[dict], step_hours: float | None,
                 title: str) -> str:
        import pandas as pd
        path = self._path({**spec, "kind": "forecast", "last": str(hist_ts[-1]), "fc": [f["wqi"] for f in fc]})
        t = pd.to_datetime(list(hist_ts))
        dt = pd.Timedelta(hours=step_hours or 24)
        ft = [t[-1] + dt * f["step"] for f in fc]
        fig, ax = plt.subplots(figsize=(7, 3.4))
        ax.plot(t, hist, marker="o", ms=3, label="Lịch sử")
        ax.plot([t[-1]] + ft, [hist[-1]] + [f["wqi"] for f in fc], "--o", ms=3, color="tab:orange", label="Dự báo")
        ax.fill_between(ft, [f["low"] for f in fc], [f["high"] for f in fc], alpha=.2, color="tab:orange")
        ax.set_title(title); ax.set_ylabel("WQI"); ax.grid(alpha=.3); ax.legend()
        fig.autofmt_xdate()
        return self._save(fig, path)
