"""Trang tổng quan:  streamlit run ui/app.py   (API phải đang chạy; đặt API_URL nếu khác localhost:8000)"""
import pandas as pd
import streamlit as st

from ui import api_client as api
from ui.common import SEV_ICON, page, safe

page("Tổng quan hệ thống")
h = safe(api.health)
if h:
    c = st.columns(5)
    c[0].metric("Trạm", h["n_stations"])
    c[1].metric("Bản ghi", h["n_readings"])
    c[2].metric("LLM", "sẵn sàng" if h["llm_available"] else "không kết nối")
    c[3].metric("Mô hình dự báo", "có" if h["forecaster_model"] else "Holt (dự phòng)")
    c[4].metric("Tài liệu KB", h["kb_chunks"])
    if not h["llm_available"]:
        st.warning("Không kết nối được Ollama: hệ thống vẫn chạy bằng router theo luật và câu trả lời mẫu.")
    st.caption(f"Phiên bản WQI: {h['wqi_version']} (chỉ số minh họa, chưa phải công thức chính thức)")

sts = safe(api.stations, default=[]) or []
if sts:
    df = pd.DataFrame(sts)[["station_id", "wqi", "wqi_class", "last_ts"]]
    st.subheader("Các trạm")
    st.dataframe(df, use_container_width=True, hide_index=True)
open_alerts = safe(api.alerts, "open", default=[]) or []
st.subheader(f"Cảnh báo đang mở ({len(open_alerts)})")
for a in open_alerts[:10]:
    st.write(f"{SEV_ICON.get(a['severity'], '')} **{a['station_id']}** · {a['message']} · _{a['ts']}_")
