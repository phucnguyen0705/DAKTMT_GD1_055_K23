from __future__ import annotations

import streamlit as st

from ui import api_client as api

SEV_ICON = {"info": "🟢", "warning": "🟠", "critical": "🔴"}


def page(title: str, icon: str = "💧"):
    st.set_page_config(page_title=f"{title} · AIoT Water", page_icon=icon, layout="wide")
    st.title(f"{icon} {title}")


def safe(fn, *a, default=None, **kw):
    try:
        return fn(*a, **kw)
    except api.ApiError as e:
        st.error(str(e))
        return default


def station_picker(key: str = "station", allow_none: bool = False):
    sts = safe(api.stations, default=[]) or []
    ids = [s["station_id"] for s in sts]
    if not ids:
        st.info("Chưa có trạm nào. Chạy `python -m scripts.seed_demo` hoặc gửi dữ liệu tới /api/ingest.")
        return None
    options = ([None] if allow_none else []) + ids
    default = st.session_state.get(key)
    idx = options.index(default) if default in options else 0
    sel = st.sidebar.selectbox("Trạm", options, index=idx, key=f"{key}_sel", format_func=lambda x: x or "(không chọn)")
    st.session_state[key] = sel
    return sel
