import pandas as pd
import streamlit as st

from ui import api_client as api
from ui.common import page, safe

page("Hệ thống & hiệu năng", "🛠️")
h = safe(api.health)
if h:
    st.json(h)
m = safe(api.metrics)
if m and m.get("n"):
    c = st.columns(4)
    c[0].metric("Độ trễ p50 (ms)", m["latency_ms_p50"])
    c[1].metric("Độ trễ p95 (ms)", m["latency_ms_p95"])
    c[2].metric("Tỉ lệ số liệu khớp", f"{m['grounded_rate']:.0%}")
    c[3].metric("Tỉ lệ dùng câu mẫu", f"{m['fallback_rate']:.0%}")
    st.caption(f"Token vào/ra: {m['tokens_in']} / {m['tokens_out']} (n={m['n']} câu hỏi gần nhất)")
else:
    st.info("Chưa có câu hỏi nào được ghi nhận.")
