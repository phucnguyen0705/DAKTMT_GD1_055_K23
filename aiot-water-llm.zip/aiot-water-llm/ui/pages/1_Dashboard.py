import pandas as pd
import streamlit as st

from ui import api_client as api
from ui.common import SEV_ICON, page, safe, station_picker

page("Dashboard trạm", "📊")
sid = station_picker()
if sid:
    s = safe(api.status, sid)
    if s and s.get("ok"):
        c = st.columns(4)
        c[0].metric("WQI", "—" if s["wqi"] is None else f"{s['wqi']:g}", s["wqi_class"])
        c[1].metric("Mức cảnh báo", f"{SEV_ICON.get(s['severity'], '')} {s['severity']}")
        c[2].metric("Thông số kéo WQI xuống", s["driver_label"] or "—")
        c[3].metric("Cập nhật", s["ts"])
        if s["suspect_params"]:
            st.warning("Nghi lỗi cảm biến: " + ", ".join(s["suspect_params"]))
        if s["missing_params"]:
            st.caption("WQI tính trên các thông số hiện có; thiếu: " + ", ".join(s["missing_params"]))
        st.subheader("Giá trị mới nhất")
        st.dataframe(pd.DataFrame(s["parameters"])[["label", "display", "qcvn_class", "flag"]]
                     .rename(columns={"label": "Thông số", "display": "Giá trị", "qcvn_class": "Lớp QCVN", "flag": "Cờ"}),
                     hide_index=True, use_container_width=True)
        for d in s["rule_descriptions"]:
            st.write("• " + d)
    hours = st.sidebar.select_slider("Cửa sổ (giờ, theo mẫu mới nhất)", [6, 24, 72, 168, 720, 8760], value=168)
    rows = safe(api.readings, sid, hours, 2000, default=[]) or []
    if rows:
        df = pd.DataFrame([{"ts": r["ts"], "WQI": r["wqi"], **r["values"]} for r in rows])
        df["ts"] = pd.to_datetime(df["ts"])
        df = df.set_index("ts")
        st.subheader("WQI theo thời gian")
        st.line_chart(df["WQI"])
        opts = [c for c in df.columns if c != "WQI"]
        pick = st.multiselect("Thông số", opts, default=opts[:2])
        if pick:
            st.line_chart(df[pick])
    f = safe(api.forecast, sid, 3)
    if f and f.get("ok"):
        st.subheader("Dự báo WQI")
        st.caption(f"Phương pháp: {f['method']} · mỗi bước ≈ {f['step_hours']} giờ · khoảng bất định xấp xỉ")
        st.dataframe(pd.DataFrame(f["forecast"]), hide_index=True)
    elif f:
        st.info("Chưa đủ dữ liệu để dự báo.")
