import pandas as pd
import streamlit as st

from ui import api_client as api
from ui.common import page, safe

page("Thiết bị IoT", "📡")
devs = safe(api.devices, default=[]) or []
if devs:
    df = pd.DataFrame(devs)[["device_id", "station_id", "online", "last_seen", "fw_version", "last_rssi", "battery_pct"]]
    st.dataframe(df, hide_index=True, use_container_width=True)
else:
    st.info("Chưa có thiết bị. Tạo thiết bị mới bên dưới để lấy API key.")

with st.expander("➕ Đăng ký thiết bị"):
    did = st.text_input("device_id", placeholder="esp32-01")
    sid = st.text_input("station_id", placeholder="S1")
    if st.button("Tạo") and did and sid:
        r = safe(api.create_device, did, sid)
        if r:
            st.success("Đã tạo. Sao chép khóa ngay, sẽ không hiển thị lại:")
            st.code(r["api_key"])

if devs:
    with st.expander("⚙️ Gửi lệnh"):
        d = st.selectbox("Thiết bị", [x["device_id"] for x in devs])
        cmd = st.selectbox("Lệnh", ["ping", "reboot", "set_interval"])
        sec = st.number_input("Chu kỳ gửi (giây)", 10, 86400, 60) if cmd == "set_interval" else None
        if st.button("Gửi lệnh"):
            r = safe(api.send_command, d, cmd, {"seconds": int(sec)} if sec else {})
            if r:
                st.success("Đã xếp hàng; thiết bị nhận ở lần gửi dữ liệu kế tiếp.")
    with st.expander("🗑️ Xóa thiết bị"):
        d2 = st.selectbox("Chọn", [x["device_id"] for x in devs], key="del")
        if st.button("Xóa") and safe(api.delete_device, d2):
            st.rerun()
