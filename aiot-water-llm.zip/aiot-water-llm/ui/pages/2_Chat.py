import streamlit as st

from ui import api_client as api
from ui.common import page, safe, station_picker

page("Trợ lý chất lượng nước", "💬")
sid = station_picker(allow_none=True)
st.session_state.setdefault("history", [])
st.sidebar.caption("Gợi ý: «Tình trạng trạm …», «Vẽ biểu đồ DO 7 ngày qua», «Dự báo WQI», «Ngưỡng DO theo QCVN», «Vì sao WQI thấp?»")

for m in st.session_state["history"]:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])
        if m.get("chart"):
            st.image(m["chart"])
        if m.get("meta"):
            st.caption(m["meta"])

if q := st.chat_input("Hỏi về chất lượng nước…"):
    st.session_state["history"].append({"role": "user", "content": q})
    with st.chat_message("user"):
        st.markdown(q)
    with st.chat_message("assistant"):
        with st.spinner("Đang xử lý…"):
            r = safe(api.chat, q, sid)
        if r:
            st.markdown(r["answer"])
            img = None
            if r.get("chart_url"):
                img = safe(api.chart_bytes, r["chart_url"])
                if img:
                    st.image(img)
            tag = "✅ số liệu khớp dữ liệu" if r["grounded"] and not r["fallback_used"] else (
                "↩️ dùng câu trả lời mẫu (đảm bảo đúng số liệu)" if r["fallback_used"] else "⚠️ chưa kiểm chứng đầy đủ")
            meta = f"{tag} · ý định: {r['intent']} ({r['route']['source']}) · {r['latency_ms']['total']:.0f} ms"
            if r["sources"]:
                meta += " · nguồn: " + ", ".join(r["sources"])
            st.caption(meta)
            st.session_state["history"].append({"role": "assistant", "content": r["answer"], "chart": img, "meta": meta})
