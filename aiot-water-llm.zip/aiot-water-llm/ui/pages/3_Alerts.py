import streamlit as st

from ui import api_client as api
from ui.common import SEV_ICON, page, safe

page("Cảnh báo & khuyến nghị", "🚨")
status = st.sidebar.radio("Trạng thái", ["open", "acked", "resolved"], format_func={"open": "Đang mở", "acked": "Đã xác nhận", "resolved": "Đã đóng"}.get)
items = safe(api.alerts, status, default=[]) or []
st.write(f"{len(items)} cảnh báo")
for a in items:
    with st.expander(f"{SEV_ICON.get(a['severity'], '')} {a['station_id']} · {a['rule_id']} · {a['ts']}"):
        st.write(a["message"])
        if a.get("report"):
            st.markdown("**Khuyến nghị tự động**")
            st.write(a["report"]["text"])
            st.caption("Số liệu đã được kiểm chứng" if a["report"].get("grounded") else "Chưa kiểm chứng đầy đủ")
        if a.get("notify"):
            st.caption(f"Thông báo: {a['notify']}")
        if status == "open" and st.button("Đã xem", key=f"ack{a['id']}"):
            safe(api.ack, a["id"])
            st.rerun()
