"""Client REST dùng cho giao diện. UI KHÔNG đọc DB hay import orchestrator: mọi thứ đi qua API."""
from __future__ import annotations

import os
from typing import Any, Optional

import httpx

_client: Optional[httpx.Client] = None


class ApiError(RuntimeError):
    pass


def get_client() -> httpx.Client:
    global _client
    if _client is None:
        _client = httpx.Client(base_url=os.getenv("API_URL", "http://localhost:8000"), timeout=120.0)
    return _client


def set_client(c: httpx.Client | None) -> None:
    """Dùng trong test (truyền starlette TestClient)."""
    global _client
    _client = c


def _req(method: str, path: str, admin: bool = False, **kw) -> Any:
    headers = {}
    if admin and os.getenv("ADMIN_API_KEY"):
        headers["X-Admin-Key"] = os.environ["ADMIN_API_KEY"]
    try:
        r = get_client().request(method, path, headers=headers, **kw)
    except httpx.HTTPError as e:
        raise ApiError(f"Không kết nối được API ({type(e).__name__})") from e
    if r.status_code >= 400:
        try:
            detail = r.json().get("detail", r.text)
        except ValueError:
            detail = r.text
        raise ApiError(f"{r.status_code}: {detail}")
    return r.json()


def health(): return _req("GET", "/api/health")
def stations(): return _req("GET", "/api/stations")
def status(sid): return _req("GET", f"/api/stations/{sid}/status")
def readings(sid, hours=None, limit=500): return _req("GET", f"/api/stations/{sid}/readings", params={"hours": hours, "limit": limit})
def forecast(sid, steps=3): return _req("GET", f"/api/stations/{sid}/forecast", params={"steps": steps})
def chat(question, station_id=None): return _req("POST", "/api/chat", json={"question": question, "station_id": station_id})
def alerts(status=None, station_id=None): return _req("GET", "/api/alerts", params={"status": status, "station_id": station_id})
def ack(alert_id): return _req("POST", f"/api/alerts/{alert_id}/ack")
def devices(): return _req("GET", "/api/devices", admin=True)
def create_device(device_id, station_id): return _req("POST", "/api/devices", admin=True, json={"device_id": device_id, "station_id": station_id})
def delete_device(device_id): return _req("DELETE", f"/api/devices/{device_id}", admin=True)
def send_command(device_id, command, params=None): return _req("POST", f"/api/devices/{device_id}/commands", admin=True, json={"command": command, "params": params or {}})
def metrics(): return _req("GET", "/api/metrics")
def chart_bytes(url): 
    r = get_client().get(url)
    r.raise_for_status()
    return r.content
