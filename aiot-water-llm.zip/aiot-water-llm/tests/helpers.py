from __future__ import annotations

from datetime import datetime, timedelta, timezone

from llm_engine.ollama_client import LLMResponse, LLMUnavailable


class FakeLLM:
    """LLM giả lập: route_json trả cho router (có json_schema), text trả cho compose."""

    def __init__(self, route: dict | None = None, text: str = "", fail: bool = False):
        self.route, self.text, self.fail, self.calls = route, text, fail, []

    def chat(self, messages, json_schema=None, temperature=None, max_tokens=512):
        self.calls.append(bool(json_schema))
        if self.fail:
            raise LLMUnavailable("down")
        if json_schema:
            import json
            return LLMResponse(json.dumps(self.route), 50, 20, 5.0, parsed=self.route)
        return LLMResponse(self.text, 200, 60, 12.0)

    def is_available(self):
        return not self.fail


def seed(ctx, station="S1", n=8, base_ts="2025-06-01T00:00:00Z", step_h=1, **vals):
    """Nạp n mẫu qua ingest (đi đúng đường thật)."""
    t0 = datetime.fromisoformat(base_ts.replace("Z", "+00:00"))
    v = {"ph": 7.2, "do_mgL": 6.5, "turbidity_ntu": 8, "tds_ppm": 300, "nh4n_mgL": 0.3, "codmn_mgL": 3.0, **vals}
    out = None
    for i in range(n):
        vv = {k: (x + (i * 0.05 if k == "do_mgL" else 0)) for k, x in v.items()}
        out = ctx.ingest.process(station, vv, ts=t0 + timedelta(hours=i * step_h))
    return out
