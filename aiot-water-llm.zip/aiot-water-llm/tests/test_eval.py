import json

from backend.app.context import AppContext
from evaluation.metrics import percentile, route_match, summarize
from evaluation.run_eval import TESTSET, evaluate, load_testset
from scripts.seed_demo import seed_demo


def test_testset_is_valid():
    items = load_testset()
    assert len(items) >= 30 and len({i["id"] for i in items}) == len(items)
    from orchestrator.schemas import INTENTS
    assert all(i["expect"]["intent"] in INTENTS for i in items)
    assert {i["expect"]["intent"] for i in items} == set(INTENTS)       # đủ mọi intent


def test_metrics_pure():
    assert percentile([1, 2, 3, 4, 5], .5) == 3 and percentile([], .9) == 0
    m = route_match({"intent": "status", "station_id": "A"}, {"intent": "status", "station_id": "B"}, "status")
    assert m == {"intent": True, "station_id": False}
    assert summarize([])["n"] == 0


def test_rules_baseline_quality(settings):
    c = AppContext.build(settings.model_copy(update={"ROUTER_MODE": "rules", "COMPOSE_MODE": "template"}), llm=None)
    seed_demo(c)
    out = evaluate(c, load_testset())
    s = out["summary"]
    # baseline luật phải đủ tốt để làm fallback; ngưỡng thấp hơn thực tế để test không dễ vỡ
    assert s["router_accuracy"]["intent"] >= 0.85, [r["id"] for r in out["rows"] if not r["match"]["intent"]]
    assert s["router_accuracy"]["station_id"] >= 0.9 and s["router_accuracy"]["parameter"] >= 0.85
    assert s["grounded_rate"] == 1.0 and s["refusal_correct"] == 1.0
    json.dumps(out, default=str)
