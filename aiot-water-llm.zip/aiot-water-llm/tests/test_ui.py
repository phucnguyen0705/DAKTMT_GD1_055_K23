import pytest
from fastapi.testclient import TestClient

st_testing = pytest.importorskip("streamlit.testing.v1")
from streamlit.testing.v1 import AppTest  # noqa: E402

from backend.app.context import AppContext  # noqa: E402
from backend.app.main import create_app  # noqa: E402
from scripts.seed_demo import seed_demo  # noqa: E402
from ui import api_client  # noqa: E402

from pathlib import Path  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
PAGES = ["ui/app.py", "ui/pages/1_Dashboard.py", "ui/pages/2_Chat.py", "ui/pages/3_Alerts.py",
         "ui/pages/4_Devices.py", "ui/pages/5_He_thong.py"]


@pytest.fixture()
def api(settings):
    app = create_app(settings, llm=None)
    seed_demo(app.state.ctx, n=48)
    c = TestClient(app)
    api_client.set_client(c)
    yield c
    api_client.set_client(None)


@pytest.mark.parametrize("path", PAGES)
def test_pages_render_without_exception(api, path):
    at = AppTest.from_file(str(ROOT / path), default_timeout=30).run()
    assert not at.exception, [e.value for e in at.exception]


def test_chat_page_answers(api):
    at = AppTest.from_file(str(ROOT / "ui/pages/2_Chat.py"), default_timeout=30).run()
    at.chat_input[0].set_value("Tình trạng hiện tại của trạm DEMO-OK").run()
    assert not at.exception
    assert any("WQI" in m.value for m in at.markdown)


def test_ui_without_api_shows_error_not_crash():
    class Dead:
        def request(self, *a, **k):
            import httpx
            raise httpx.ConnectError("x")
    api_client.set_client(Dead())
    try:
        at = AppTest.from_file(str(ROOT / "ui/app.py"), default_timeout=30).run()
        assert not at.exception and at.error
    finally:
        api_client.set_client(None)
