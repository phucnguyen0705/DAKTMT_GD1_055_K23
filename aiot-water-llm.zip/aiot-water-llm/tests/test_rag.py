import subprocess
import sys
from pathlib import Path

from llm_engine.rag.retriever import BM25Retriever, load_kb

KB = Path(__file__).resolve().parents[1] / "knowledge_base" / "docs"


def test_chunks_have_ids():
    ch = load_kb(KB)
    assert len(ch) > 20
    assert len({c.id for c in ch}) == len(ch)
    assert all("#" in c.id for c in ch)


def test_search_do_recommendation():
    r = BM25Retriever.from_dir(KB)
    hits = r.search("DO thấp thì nên làm gì khuyến nghị", k=3)
    assert hits and hits[0]["doc_id"] == "param_do"


def test_search_without_accents():
    r = BM25Retriever.from_dir(KB)
    hits = r.search("nguong pH QCVN", k=5)
    assert any(h["doc_id"] in ("std_qcvn08_2023", "param_ph") for h in hits)


def test_get_sections_and_filter():
    r = BM25Retriever.from_dir(KB)
    s = r.get_sections("param_do", ["Khuyến nghị"])
    assert len(s) == 1
    assert all(h["type"] == "guide" for h in r.search("WQI rất kém", doc_types=["guide"]))


def test_kb_no_drift():
    root = Path(__file__).resolve().parents[1]
    rc = subprocess.run([sys.executable, "-m", "scripts.build_kb", "--check"], cwd=root).returncode
    assert rc == 0
