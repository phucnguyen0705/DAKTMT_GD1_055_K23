from pathlib import Path

import pytest

from backend.app.context import AppContext
from forecasting.train import train_forecaster
from scripts.import_dataset import import_dataset
from scripts.recompute_wqi import recompute
from scripts.seed_demo import seed_demo

PARQUET = Path(__file__).resolve().parents[1] / "data/processed/water_quality_wide.parquet"


@pytest.mark.skipif(not PARQUET.exists(), reason="chưa có parquet")
def test_import_train_forecast(settings):
    c = AppContext.build(settings, llm=None)
    r = import_dataset(c.storage, c.registry, c.wqi_cfg, str(PARQUET), ["CNEMC"], limit_stations=5)
    assert r["stations"] == 5 and r["rows_inserted"] > 500
    assert c.storage.station_ids()[0].startswith("CNEMC-")
    assert recompute(c.storage, c.wqi_cfg) == c.storage.count_readings()
    m = train_forecaster(c.storage, settings.MODELS_DIR, source="CNEMC")
    assert m["n_test"] > 50 and m["mae"] > 0
    sid = c.storage.station_ids()[0]
    f = c.tools.forecast(sid, 3)
    assert f["ok"] and f["method"] == "gbr_lag" and len(f["forecast"]) == 3
    assert all(0 <= x["low"] <= x["wqi"] <= x["high"] <= 100 for x in f["forecast"])
    # trạm lịch sử vẫn có cửa sổ thời gian dù dữ liệu cũ
    t = c.tools.get_trend(sid, hours=24 * 60)
    assert t["ok"] and t["n_points"] > 3


def test_seed_demo_chat(settings):
    c = AppContext.build(settings, llm=None)
    seed_demo(c, n=48)
    assert c.storage.list_alerts(station_id="DEMO-POLLUTED")
    r = c.orchestrator.answer("Vì sao trạm DEMO-POLLUTED có cảnh báo?")
    assert r["intent"] == "explain" and r["facts"]["knowledge"]
    assert c.storage.list_alerts(station_id="DEMO-FAULT")
