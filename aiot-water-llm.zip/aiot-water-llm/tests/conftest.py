"""Fixture dùng chung. Mọi test dùng thư mục tạm; không đụng tới data/ thật và không cần Ollama."""
from __future__ import annotations

import pytest

from config.settings import Settings


@pytest.fixture()
def settings(tmp_path):
    return Settings(
        DB_PATH=str(tmp_path / "test.db"),
        CHARTS_DIR=str(tmp_path / "charts"),
        MODELS_DIR=str(tmp_path / "models"),
        EVAL_RESULTS_DIR=str(tmp_path / "eval"),
        LLM_BASE_URL="http://127.0.0.1:9",          # cổng không có dịch vụ: gọi LLM thật sẽ lỗi, test phải dùng giả lập
        LLM_TIMEOUT_SEC=2,
        ALERT_COOLDOWN_MIN=60,
        _env_file=None,
    )
