import json

import pytest
from jsonschema import validate

from evaluation.run_eval import load_testset
from orchestrator.grounding import check_grounding, collect_numbers
from orchestrator.schemas import INTENTS
from training.make_dataset import build


@pytest.fixture(scope="module")
def data():
    return build(seed=1, per_template=3)


def test_splits_and_no_leak(data):
    assert all(len(v) > 10 for v in data.values())
    ev = {i["question"].lower() for i in load_testset()}
    users = lambda rows: {r["messages"][1]["content"].lower() for r in rows if r["task"] == "router"}   # noqa: E731
    assert not (users(data["train"]) & ev) and not (users(data["train"]) & users(data["test"]))


def test_router_labels_valid_against_schema(data):
    from orchestrator.schemas import router_json_schema
    from config.registry import ParameterRegistry
    from config.settings import Settings
    schema = router_json_schema(ParameterRegistry.load(Settings(_env_file=None).PARAMETERS_PATH).keys)
    for split in data.values():
        for r in split:
            if r["task"] == "router":
                lab = json.loads(r["messages"][-1]["content"])
                validate(lab, schema)
                assert lab["intent"] in INTENTS


def test_compose_labels_are_grounded(data):
    n = 0
    for split in data.values():
        for r in split:
            if r["task"] == "compose":
                facts_line = r["messages"][1]["content"].split("FACTS: ", 1)[1].split("\nKIẾN THỨC", 1)[0]
                ok, bad = check_grounding(r["messages"][-1]["content"], json.loads(facts_line))
                assert ok or all(b in collect_numbers(r["messages"][1]["content"]) for b in bad), bad
                n += 1
    assert n >= 4
