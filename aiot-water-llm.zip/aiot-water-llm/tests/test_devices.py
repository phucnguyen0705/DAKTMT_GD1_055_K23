import random
from datetime import datetime, timezone

from fastapi.testclient import TestClient

from backend.app.main import create_app
from devices import simulator
from devices.mqtt_bridge import build_payload, parse_topic
from devices.serial_bridge import parse_line


def test_generate_deterministic_and_scenarios():
    a = simulator.generate("pollution", 30, random.Random(1), 60)
    b = simulator.generate("pollution", 30, random.Random(1), 60)
    assert a == b
    assert a["do_mgL"] < simulator.generate("normal", 30, random.Random(1), 60)["do_mgL"]
    assert simulator.generate("sensor_fault", 6, random.Random(0))["ph"] > 14


def test_simulator_end_to_end_pollution_raises_alert(settings):
    c = TestClient(create_app(settings, llm=None))
    post = lambda p: c.post("/api/ingest", json=p).json()          # noqa: E731
    n = simulator.run(post, "SIM", None, "pollution", 60, 0, start=datetime(2025, 6, 1, tzinfo=timezone.utc))
    assert n == 60
    rules = {a["rule_id"] for a in c.get("/api/alerts").json()}
    assert rules & {"do_low", "do_critical_low", "nh4n_high", "wqi_poor", "wqi_critical"}
    rows = c.get("/api/stations/SIM/readings", params={"limit": 500}).json()
    assert min(r["wqi"] for r in rows) < max(r["wqi"] for r in rows) - 20


def test_simulator_sensor_fault_flagged(settings):
    c = TestClient(create_app(settings, llm=None))
    simulator.run(lambda p: c.post("/api/ingest", json=p).json(), "F", None, "sensor_fault", 14, 0,
                  start=datetime(2025, 6, 1, tzinfo=timezone.utc))
    assert any(a["rule_id"].startswith("sensor_fault") for a in c.get("/api/alerts").json())


def test_simulator_applies_commands(settings):
    c = TestClient(create_app(settings, llm=None))
    d = c.post("/api/devices", json={"device_id": "d1", "station_id": "S"}).json()
    c.post("/api/devices/d1/commands", json={"command": "set_interval", "params": {"seconds": 30}})
    seen = []
    simulator.run(lambda p: c.post("/api/ingest", json=p, headers={"X-API-Key": d["api_key"]}).json(), "S", "d1",
                  "normal", 2, 0, start=datetime(2025, 6, 1, tzinfo=timezone.utc),
                  on_result=lambda k, p, r: seen.append(r["commands"]))
    assert seen[0] and seen[0][0]["command"] == "set_interval" and seen[1] == []


def test_mqtt_topic_and_payload():
    root = "aiot/water"
    assert parse_topic("aiot/water/S1/esp-1/telemetry", root) == ("S1", "esp-1")
    for bad in ("aiot/water/S1/telemetry", "x/S1/e/telemetry", "aiot/water/S1/../telemetry", "aiot/water/S1/e/cmd",
                "aiot/water/S 1/e/telemetry"):
        assert parse_topic(bad, root) is None
    ok = build_payload("aiot/water/S1/e/telemetry", b'{"values":{"ph":7.1},"meta":{"rssi":-50}}', root)
    assert ok["station_id"] == "S1" and ok["device_id"] == "e" and ok["values"] == {"ph": 7.1}
    assert build_payload("aiot/water/S1/e/telemetry", b"not json", root) is None
    assert build_payload("aiot/water/S1/e/telemetry", b'{"values":[1]}', root) is None


def test_serial_parse():
    assert parse_line('{"ph": 7.1}\n') == {"ph": 7.1}
    assert parse_line("boot...") is None and parse_line("{bad") is None
