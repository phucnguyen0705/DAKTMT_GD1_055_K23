import pytest
from fastapi.testclient import TestClient

from backend.app.main import create_app
from tests.helpers import FakeLLM

GOOD = {"ph": 7.2, "do_mgL": 6.5, "turbidity_ntu": 8, "tds_ppm": 300, "nh4n_mgL": 0.3, "codmn_mgL": 3}
BAD = {**GOOD, "do_mgL": 1.5, "nh4n_mgL": 3.0}


@pytest.fixture()
def client(settings):
    return TestClient(create_app(settings, llm=None))


def post(c, vals, ts, station="S1", headers=None, **kw):
    return c.post("/api/ingest", json={"station_id": station, "ts": ts, "values": vals, **kw}, headers=headers)


def test_health_and_ingest_flow(client):
    assert client.get("/api/health").json()["status"] == "ok"
    r = post(client, GOOD, "2025-06-01T00:00:00Z").json()
    assert r["is_new"] and r["wqi"] > 70 and r["severity"] == "info"
    assert not post(client, GOOD, "2025-06-01T00:00:00Z").json()["is_new"]       # idempotent
    r = post(client, BAD, "2025-06-01T01:00:00Z").json()
    assert r["new_alert_ids"] and r["severity"] != "info"
    alerts = client.get("/api/alerts", params={"status": "open"}).json()
    assert alerts
    assert client.post(f"/api/alerts/{alerts[0]['id']}/ack").status_code == 200
    # BackgroundTasks đã chạy dispatcher: alert có báo cáo (reporter dùng mẫu vì không có LLM)
    full = client.get(f"/api/alerts/{r['new_alert_ids'][0]}").json()
    assert full["notify"] is not None


def test_read_endpoints_and_chat(client):
    for i in range(8):
        post(client, GOOD, f"2025-06-01T0{i}:00:00Z")
    assert client.get("/api/stations").json()[0]["station_id"] == "S1"
    assert client.get("/api/stations/S1/status").json()["ok"]
    assert client.get("/api/stations/NOPE/status").status_code == 404
    assert len(client.get("/api/stations/S1/readings", params={"limit": 3}).json()) == 3
    assert client.get("/api/stations/S1/trend", params={"parameter": "bad"}).status_code == 422
    r = client.post("/api/chat", json={"question": "Vẽ biểu đồ pH trạm S1", "station_id": "S1"}).json()
    assert r["chart_url"].startswith("/api/charts/")
    png = client.get(r["chart_url"])
    assert png.status_code == 200 and png.content[:4] == b"\x89PNG"
    assert client.get("/api/charts/..%2Fetc.png").status_code in (400, 404)
    assert client.get("/api/metrics").json()["n"] >= 1
    assert client.get("/api/kb/search", params={"q": "oxy hòa tan"}).json()


def test_bad_payload(client):
    assert client.post("/api/ingest", json={"values": GOOD}).status_code == 422          # thiếu station
    assert post(client, GOOD, "not-a-date").status_code == 422


def test_device_auth_and_commands(settings):
    s = settings.model_copy(update={"REQUIRE_INGEST_AUTH": True, "ADMIN_API_KEY": "adm", "INGEST_SERVICE_KEY": "svc"})
    c = TestClient(create_app(s, llm=None))
    assert post(c, GOOD, "2025-06-01T00:00:00Z").status_code == 401
    assert c.get("/api/devices").status_code == 401
    adm = {"X-Admin-Key": "adm"}
    d = c.post("/api/devices", json={"device_id": "esp-1", "station_id": "S9"}, headers=adm)
    assert d.status_code == 201
    key = d.json()["api_key"]
    assert "key_hash" not in d.json()
    assert c.post("/api/devices", json={"device_id": "esp-1", "station_id": "S9"}, headers=adm).status_code == 409
    # thiết bị bị khoá vào trạm của nó dù body ghi trạm khác
    r = post(c, GOOD, "2025-06-01T00:00:00Z", station="HACK", headers={"X-API-Key": key})
    assert r.status_code == 200 and r.json()["station_id"] == "S9"
    assert post(c, GOOD, "2025-06-01T01:00:00Z", headers={"X-API-Key": key}, device_id="other").status_code == 403
    assert post(c, GOOD, "2025-06-01T02:00:00Z", headers={"X-API-Key": "wrong"}).status_code == 401
    assert post(c, GOOD, "2025-06-01T03:00:00Z", station="S5", headers={"X-API-Key": "svc"}).status_code == 200
    assert c.post("/api/devices/esp-1/commands", json={"command": "rm -rf"}, headers=adm).status_code == 422
    assert c.post("/api/devices/esp-1/commands", json={"command": "set_interval", "params": {"seconds": 5}},
                  headers=adm).status_code == 422
    assert c.post("/api/devices/esp-1/commands", json={"command": "set_interval", "params": {"seconds": 60}},
                  headers=adm).status_code == 201
    r = post(c, GOOD, "2025-06-01T04:00:00Z", headers={"X-API-Key": key}).json()
    assert r["commands"] == [{"id": 1, "command": "set_interval", "params": {"seconds": 60}}]
    dev = c.get("/api/devices", headers=adm).json()[0]
    assert dev["online"] is True and "key_hash" not in dev


def test_chat_with_llm_fake(settings):
    llm = FakeLLM(route={"intent": "status", "station_id": None, "parameter": None, "hours": None, "chart": False})
    c = TestClient(create_app(settings, llm=llm))
    post(c, GOOD, "2025-06-01T00:00:00Z")
    r = c.post("/api/chat", json={"question": "thế nào rồi", "station_id": "S1"}).json()
    assert r["route"]["source"] == "llm" and r["intent"] == "status"
    assert c.post("/api/chat", json={"question": "x", "station_id": "ZZ"}).status_code == 404
