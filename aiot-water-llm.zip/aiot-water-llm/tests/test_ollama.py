import json

import httpx
import pytest

from backend.app.context import AppContext
from llm_engine.ollama_client import LLMUnavailable, OllamaClient
from tests.helpers import seed


def make(settings, handler):
    return OllamaClient(settings, transport=httpx.MockTransport(handler))


def test_chat_sends_schema_and_parses(settings):
    seen = {}

    def handler(req: httpx.Request):
        if req.url.path == "/api/chat":
            seen.update(json.loads(req.content))
            return httpx.Response(200, json={"message": {"content": '{"intent":"status","chart":false}'},
                                             "prompt_eval_count": 30, "eval_count": 9})
        return httpx.Response(200, json={"models": [{"name": "qwen2.5:1.5b"}]})

    c = make(settings, handler)
    r = c.chat([{"role": "user", "content": "x"}], json_schema={"type": "object"}, max_tokens=50)
    assert seen["format"] == {"type": "object"} and seen["stream"] is False
    assert seen["model"] == "qwen2.5:1.5b" and seen["options"]["num_predict"] == 50 and seen["options"]["num_ctx"] == 4096
    assert r.parsed == {"intent": "status", "chart": False} and (r.tokens_in, r.tokens_out) == (30, 9)
    assert c.is_available() and c.model_installed()


def test_errors_become_llm_unavailable(settings):
    for h in (lambda r: httpx.Response(500), lambda r: (_ for _ in ()).throw(httpx.ConnectError("x")),
              lambda r: httpx.Response(200, content=b"not json")):
        with pytest.raises(LLMUnavailable):
            make(settings, h).chat([{"role": "user", "content": "x"}])
    assert not make(settings, lambda r: httpx.Response(500)).is_available()


def test_bad_json_from_model_is_none(settings):
    c = make(settings, lambda r: httpx.Response(200, json={"message": {"content": "xin chào"}}))
    assert c.chat([], json_schema={"type": "object"}).parsed is None


def test_full_pipeline_over_http_fake(settings):
    """Router + compose đi qua OllamaClient thật (HTTP giả): kiểm tra cả đường fallback khi model trả JSON rác."""
    state = {"n": 0}

    def handler(req: httpx.Request):
        body = json.loads(req.content)
        state["n"] += 1
        if "format" in body:
            return httpx.Response(200, json={"message": {"content": "```không phải json```"}})
        return httpx.Response(200, json={"message": {"content": "WQI là 424242."}, "prompt_eval_count": 1, "eval_count": 1})

    ctx = AppContext.build(settings, llm=make(settings, handler))
    seed(ctx, "S1")
    r = ctx.orchestrator.answer("Tình trạng hiện tại của trạm S1")
    assert r["route"]["source"] == "rules" and "424242" not in r["answer"] and r["facts"]["ok"]
    assert "router" in (r["llm_error"] or "")
