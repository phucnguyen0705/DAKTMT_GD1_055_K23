import pytest

from backend.app.context import AppContext
from orchestrator.grounding import check_grounding
from tests.helpers import FakeLLM, seed


@pytest.fixture()
def ctx(settings):
    c = AppContext.build(settings, llm=None)
    seed(c, "S1", n=10)
    seed(c, "S2", n=10, do_mgL=2.0, nh4n_mgL=2.5)
    return c


def test_grounding():
    ok, bad = check_grounding("WQI là 81.2 và pH 7,2", {"wqi": 81.2, "ph": 7.2})
    assert ok and not bad
    ok, bad = check_grounding("WQI là 99", {"wqi": 81.2})
    assert not ok and bad == [99.0]


def test_rules_status_and_chart(ctx):
    r = ctx.orchestrator.answer("Tình trạng hiện tại của trạm S2 thế nào?")
    assert r["intent"] == "status" and r["station_id"] == "S2" and "WQI" in r["answer"]
    r = ctx.orchestrator.answer("Vẽ biểu đồ DO của trạm S1 trong 5 giờ qua")
    assert r["intent"] == "trend" and r["chart"] and r["facts"]["n_points"] >= 5


def test_compare_standard_alerts_forecast(ctx):
    r = ctx.orchestrator.answer("So sánh WQI các trạm")
    assert r["intent"] == "compare" and r["facts"]["best"]["station_id"] == "S1"
    r = ctx.orchestrator.answer("Ngưỡng DO theo QCVN là bao nhiêu?")
    assert r["intent"] == "standard" and "qcvn08_2023" in r["sources"]
    r = ctx.orchestrator.answer("Có cảnh báo nào không?")
    assert r["intent"] == "alerts" and r["facts"]["n_open"] >= 1
    r = ctx.orchestrator.answer("Dự báo WQI trạm S1", station_id="S1")
    assert r["intent"] == "forecast" and r["facts"]["ok"]


def test_context_station_and_need_station(ctx):
    r = ctx.orchestrator.answer("Tình trạng hiện tại?", station_id="S1")
    assert r["station_id"] == "S1" and r["facts"]["ok"]
    r = ctx.orchestrator.answer("Tình trạng hiện tại?")
    assert "trạm nào" in r["answer"]


def test_explain_without_station_goes_to_knowledge(ctx):
    r = ctx.orchestrator.answer("DO thấp thì nên làm gì?")
    assert r["intent"] == "knowledge" and any(s.startswith("param_do") for s in r["sources"])


def test_out_of_scope(ctx):
    r = ctx.orchestrator.answer("Hôm nay giá vàng bao nhiêu?")
    assert r["intent"] == "out_of_scope"


def test_llm_route_invalid_station_ignored(settings):
    llm = FakeLLM(route={"intent": "status", "station_id": "BIA", "parameter": None, "hours": None, "chart": False})
    c = AppContext.build(settings, llm=llm)
    seed(c, "S1")
    r = c.orchestrator.answer("cho tôi biết tình hình", station_id="S1")
    assert r["route"]["source"] == "llm" and r["station_id"] == "S1"


def test_llm_down_falls_back_to_rules(settings):
    c = AppContext.build(settings, llm=FakeLLM(fail=True))
    seed(c, "S1")
    r = c.orchestrator.answer("Tình trạng hiện tại của trạm S1")
    assert r["route"]["source"] == "rules" and r["llm_error"] and r["facts"]["ok"]


def test_compose_grounding_blocks_hallucination(settings):
    route = {"intent": "status", "station_id": "S1", "parameter": None, "hours": None, "chart": False}
    c = AppContext.build(settings, llm=FakeLLM(route, text="WQI trạm S1 là 12345."))
    seed(c, "S1")
    r = c.orchestrator.answer("trạm S1 thế nào")
    assert r["fallback_used"] and r["composer"] == "template" and 12345.0 in r["bad_numbers"]
    st = c.tools.get_status("S1")
    good = FakeLLM(route, text=f"Trạm S1 có WQI {st['wqi']:g}, mức {st['wqi_class']}.")
    c2 = AppContext.build(settings, llm=good)
    r = c2.orchestrator.answer("trạm S1 thế nào")
    assert r["composer"] == "llm" and r["grounded"] and not r["fallback_used"]


def test_bare_do_is_not_dissolved_oxygen(ctx):
    from orchestrator.rules_router import detect_entities
    st = ctx.storage.list_stations()
    for q in ("Vẽ biểu đồ trạm S1", "Thủ đô của Pháp là gì?", "do mưa lớn nên nước đục"):
        assert detect_entities(q, ctx.registry, st)["parameter"] != "do_mgL", q
    for q in ("DO của trạm S1", "Vẽ biểu đồ DO", "oxy hòa tan thấp"):
        assert detect_entities(q, ctx.registry, st)["parameter"] == "do_mgL", q
