"""Test lớp cấu hình, WQI, bộ đánh giá luật an toàn, lưu trữ và luồng ingest."""
from __future__ import annotations

import pytest

from backend.app.services.ingest import IngestService
from config.registry import ParameterRegistry, Standards, norm_text
from data_processing.wqi_calculator import WQIConfig, WaterSample, calculate_wqi, classify_wqi, compute_wqi
from policy.expr import CompiledCondition, UnsafeExpression
from policy.policy_engine import PolicyEngine
from storage.db import Storage, to_iso


@pytest.fixture()
def registry():
    return ParameterRegistry.load()


@pytest.fixture()
def engine(registry):
    return PolicyEngine(allowed_names=registry.keys)


@pytest.fixture()
def svc(settings, registry, engine):
    return IngestService(Storage(settings.DB_PATH), registry, WQIConfig.load(), engine, settings)


# ------------------------------------------------------------------ registry / standards
def test_alias_and_checks(registry):
    assert registry.canonical("DO") == "do_mgL" and registry.canonical("pH") == "ph"
    assert registry.canonical("NH4N") == "nh4n_mgL" and registry.canonical("xyz") is None
    assert registry.check("ph", 7) == "ok"
    assert registry.check("ph", 3) == "suspect"          # ngoài 4-11 nhưng trong 0-14
    assert registry.check("ph", 15) == "invalid"
    assert registry.check("do_mgL", None) == "missing"
    assert registry.check("do_mgL", float("nan")) == "invalid"


def test_detect_parameter_in_text(registry):
    assert registry.detect_in_text(norm_text("Oxy hòa tan của trạm 65")) == "do_mgL"
    assert registry.detect_in_text(norm_text("amoni đang cao")) == "nh4n_mgL"
    assert registry.detect_in_text(norm_text("độ đục hôm nay")) == "turbidity_ntu"
    assert registry.detect_in_text(norm_text("xin chào")) is None


def test_standards_values_and_classification():
    s = Standards.load()
    q = s.get("qcvn08_2023")
    assert q.classes == ["A", "B", "C", "D"]            # không phải A1/A2/B1/B2
    assert q.classify("do_mgL", 6.5) == "A" and q.classify("do_mgL", 4.2) == "C" and q.classify("do_mgL", 1.0) is None
    assert q.classify("ph", 7.0) == "A" and q.classify("ph", 6.2) == "B" and q.classify("ph", 9.0) == "D"
    gb = s.get("gb3838_2002")
    assert gb.classify("nh4n_mgL", 0.4) == "II" and gb.classify("codmn_mgL", 7) == "IV"


def test_wqi_anchors_match_gb_classes():
    """Điểm neo trong wqi.yaml cho DO/CODMn/NH4N phải khớp các cận lớp GB 3838-2002 trong standards.yaml."""
    cfg, gb = WQIConfig.load(), Standards.load().get("gb3838_2002")
    for key in ("do_mgL", "codmn_mgL", "nh4n_mgL"):
        ps = cfg.params[key]
        for cls, score in zip(gb.classes, (100, 80, 60, 40, 20)):
            limit = gb.parameters[key].limits[cls]
            assert ps.score(limit) == pytest.approx(score), (key, cls)


# ------------------------------------------------------------------ WQI
def test_wqi_legacy_api():
    good = WaterSample(ph=7.0, do_mgL=8.0, turbidity_ntu=2, tds_ppm=100, temperature_c=25)
    assert calculate_wqi(good) > 75 and classify_wqi(calculate_wqi(good)) in ("Tốt", "Rất tốt")
    bad = WaterSample(ph=4.5, do_mgL=1.0, turbidity_ntu=80, tds_ppm=1200, temperature_c=35)
    assert calculate_wqi(bad) < 50
    assert classify_wqi(95) == "Rất tốt" and classify_wqi(10) == "Rất kém / Ô nhiễm nặng"


def test_wqi_uses_available_params_only():
    r = compute_wqi({"ph": 7.0, "do_mgL": 8.0})
    assert r.wqi == 100.0 and set(r.used) == {"ph", "do_mgL"} and r.driver is None
    r2 = compute_wqi({"ph": 7.0, "do_mgL": 3.0, "nh4n_mgL": 1.5})
    assert r2.driver in ("do_mgL", "nh4n_mgL") and r2.wqi < 100
    assert compute_wqi({"ph": 7.0}).wqi is None                  # dưới min_params
    assert compute_wqi({"ph": None, "do_mgL": float("nan")}).wqi is None
    # nhiệt độ không tham gia WQI
    assert compute_wqi({"ph": 7.0, "do_mgL": 8.0, "temperature_c": 39}).wqi == 100.0


# ------------------------------------------------------------------ biểu thức an toàn
@pytest.mark.parametrize("src", [
    "__import__('os').system('echo hacked')",
    "().__class__.__bases__[0].__subclasses__()",
    "abs(wqi) > 1", "wqi.real > 1", "[1][0] > 0", "lambda: 1", "wqi if wqi else 1", "'a' == 'a'", "unknown_var > 1",
    "wqi > 1; import os", "True",
])
def test_unsafe_expressions_rejected(src):
    with pytest.raises(UnsafeExpression):
        CompiledCondition(src, {"wqi", "ph"})


def test_expression_semantics():
    c = CompiledCondition("26 <= wqi < 51", {"wqi"})
    assert c.evaluate({"wqi": 30}) is True and c.evaluate({"wqi": 51}) is False and c.evaluate({"wqi": 26}) is True
    c2 = CompiledCondition("ph < 6.0 or ph > 8.5", {"ph"})
    assert c2.evaluate({"ph": 9}) is True and c2.evaluate({"ph": 7}) is False
    assert c2.evaluate({"ph": None}) is None and c2.evaluate({}) is None     # thiếu biến -> không áp dụng


# ------------------------------------------------------------------ policy engine
def test_policy_rules(engine):
    r = engine.evaluate({"wqi": 20, "ph": 7.0, "do_mgL": 6.0})
    assert r.severity == "critical" and "wqi_critical" in r.matched_rules and "recommend_stop_usage" in r.actions
    r = engine.evaluate({"wqi": 90, "ph": 7.2, "do_mgL": 8.0})
    assert r.severity == "info" and r.matched_rules == ["normal_condition"]
    assert "ph_out_of_range" in engine.evaluate({"wqi": 60, "ph": 9.2}).matched_rules
    r = engine.evaluate({"wqi": 60, "do_mgL": 3.0})
    assert "do_low" in r.matched_rules and "do_critical_low" not in r.matched_rules
    assert "do_critical_low" in engine.evaluate({"wqi": 60, "do_mgL": 1.5}).matched_rules
    assert "nh4n_high" in engine.evaluate({"wqi": 60, "nh4n_mgL": 1.5}).matched_rules
    assert "nh4n_critical" in engine.evaluate({"wqi": 60, "nh4n_mgL": 2.5}).matched_rules
    assert engine.evaluate({"do_mgL": 3.0}).matched_rules == ["do_low"]        # wqi thiếu: chỉ luật không cần wqi


def test_policy_reload_rejects_bad_rule(tmp_path, registry):
    bad = tmp_path / "rules.yaml"
    bad.write_text("rules:\n  - {id: x, description: d, condition: \"__import__('os')\", severity: info, actions: []}\n", encoding="utf-8")
    with pytest.raises(ValueError):
        PolicyEngine(bad, allowed_names=registry.keys)
    dup = tmp_path / "dup.yaml"
    dup.write_text("rules:\n  - {id: a, description: d, condition: \"wqi<1\", severity: info, actions: []}\n"
                   "  - {id: a, description: d, condition: \"wqi<2\", severity: info, actions: []}\n", encoding="utf-8")
    with pytest.raises(ValueError):
        PolicyEngine(dup, allowed_names=registry.keys)


# ------------------------------------------------------------------ storage
def test_storage_idempotent_and_windows(settings):
    st = Storage(settings.DB_PATH)
    st.upsert_station("s1")
    rid, new = st.add_reading("s1", "2026-01-01T00:00:00Z", {"ph": 7}, {}, 80.0, "Tốt")
    rid2, new2 = st.add_reading("s1", "2026-01-01T00:00:00Z", {"ph": 7}, {}, 80.0, "Tốt")
    assert new and not new2 and rid == rid2
    for h in range(1, 5):
        st.add_reading("s1", f"2026-01-01T0{h}:00:00Z", {"ph": 7 + h / 10}, {}, 80.0, "Tốt")
    assert st.count_readings("s1") == 5
    since = st.window_since("s1", 2)
    assert since == "2026-01-01T02:00:00Z"
    assert len(st.get_readings("s1", since=since)) == 3
    assert [r["ts"] for r in st.get_readings("s1", limit=2, newest=True)] == ["2026-01-01T03:00:00Z", "2026-01-01T04:00:00Z"]
    assert st.readings_df("s1", hours=2).shape[0] == 3


def test_to_iso_variants():
    assert to_iso("2026-01-01T07:00:00+07:00") == "2026-01-01T00:00:00Z"
    assert to_iso(1767225600) == "2026-01-01T00:00:00Z"
    assert to_iso(1767225600000) == "2026-01-01T00:00:00Z"
    assert to_iso("2026-01-01 00:00:00") == "2026-01-01T00:00:00Z"


# ------------------------------------------------------------------ ingest
def test_ingest_flow_alert_cooldown_and_resolve(svc):
    base = {"ph": 7.2, "do_mgL": 6.5, "turbidity_ntu": 10, "tds_ppm": 200}
    r = svc.process("st1", base, ts="2026-01-01T00:00:00Z")
    assert r.is_new and r.wqi is not None and r.severity == "info" and not r.new_alert_ids

    low = {**base, "do_mgL": 1.5}
    r = svc.process("st1", low, ts="2026-01-01T00:10:00Z")
    assert "do_critical_low" in r.matched_rules and len(r.new_alert_ids) >= 1
    n_first = len(svc.storage.list_alerts("st1", status="open"))
    # 10 phút sau, vẫn thấp: nằm trong cooldown -> không tạo alert trùng
    r = svc.process("st1", low, ts="2026-01-01T00:20:00Z")
    assert not r.new_alert_ids and "do_critical_low" in r.suppressed_rules
    assert len(svc.storage.list_alerts("st1", status="open")) == n_first
    # DO hồi phục -> alert đóng
    svc.process("st1", base, ts="2026-01-01T00:30:00Z")
    assert svc.storage.list_alerts("st1", status="open") == []
    assert any(a["status"] == "resolved" for a in svc.storage.list_alerts("st1"))
    # sau cooldown, thấp lại -> alert mới
    r = svc.process("st1", low, ts="2026-01-01T02:00:00Z")
    assert r.new_alert_ids


def test_ingest_duplicate_is_idempotent(svc):
    a = svc.process("st1", {"ph": 7, "do_mgL": 3.0}, ts="2026-01-01T00:00:00Z")
    b = svc.process("st1", {"ph": 7, "do_mgL": 3.0}, ts="2026-01-01T00:00:00Z")
    assert a.is_new and not b.is_new and a.reading_id == b.reading_id and not b.new_alert_ids


def test_ingest_sensor_faults(svc):
    r = svc.process("st1", {"ph": 7.0, "do_mgL": 35.0, "temperature_c": 25}, ts="2026-01-01T00:00:00Z")
    assert r.flags["do_mgL"] == "suspect"
    assert r.wqi is None                                   # chỉ còn pH hợp lệ -> không đủ để tính
    faults = [a for a in svc.storage.list_alerts("st1") if a["kind"] == "sensor_fault"]
    assert faults and "do_mgL" in faults[0]["rule_id"]
    r = svc.process("st1", {"ph": 99, "do_mgL": 6.0, "nh4n_mgL": None, "bogus": 1}, ts="2026-01-01T00:01:00Z")
    assert r.flags["ph"] == "invalid" and r.values["ph"] is None and r.flags["nh4n_mgL"] == "missing"
    assert r.ignored_fields == ["bogus"]


def test_partial_reading_does_not_close_unrelated_alerts(svc):
    svc.process("st1", {"ph": 7, "do_mgL": 1.5, "nh4n_mgL": 3.0}, ts="2026-01-01T00:00:00Z")
    assert {a["rule_id"] for a in svc.storage.list_alerts("st1", status="open")} >= {"do_critical_low", "nh4n_critical"}
    svc.process("st1", {"ph": 7, "do_mgL": 7.0}, ts="2026-01-01T00:05:00Z")      # không báo amoni
    open_rules = {a["rule_id"] for a in svc.storage.list_alerts("st1", status="open")}
    assert "do_critical_low" not in open_rules and "nh4n_critical" in open_rules   # amoni chưa được kiểm tra lại


def test_ingest_registers_device_and_returns_commands(svc):
    svc.storage.create_device("dev1", "st1", key="secret", name="Node 1")
    svc.storage.add_command("dev1", "set_interval", {"seconds": 30})
    r = svc.process("st1", {"ph": 7, "do_mgL": 7}, ts="2026-01-01T00:00:00Z", device_id="dev1",
                    meta={"fw": "1.0.0", "rssi": -60, "battery": 88})
    assert r.commands == [{"id": 1, "command": "set_interval", "params": {"seconds": 30}}]
    d = svc.storage.get_device("dev1")
    assert d["fw_version"] == "1.0.0" and d["last_rssi"] == -60 and d["last_seen"]
    assert svc.storage.pop_pending_commands("dev1") == []                          # đã giao rồi
