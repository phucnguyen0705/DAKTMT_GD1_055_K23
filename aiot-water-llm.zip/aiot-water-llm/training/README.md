# Fine-tune Qwen2.5-1.5B cho router + soạn câu trả lời

**Không huấn luyện trên bảng số liệu thô.** Mô hình chỉ học (1) định tuyến câu hỏi → JSON, (2) viết lại FACTS thành câu tiếng Việt
không thêm số, (3) từ chối câu ngoài phạm vi. Số liệu luôn lấy từ API lúc chạy.

1. `python -m training.make_dataset` → `training/data/{train,val,test}.jsonl` (+ `router_schema.json`). Tập test dùng cách diễn đạt
   chưa có trong train và loại mọi câu trùng bộ `evaluation/testset`.
2. `python -m training.train_qlora` (GPU; xem ghi chú VRAM trong file). **Chưa được chạy thử trong môi trường phát triển.**
3. Gộp LoRA → GGUF → Ollama (cần llama.cpp):
   ```
   python -c "from peft import AutoPeftModelForCausalLM as M; m=M.from_pretrained('models/qwen1.5b-water-lora').merge_and_unload(); m.save_pretrained('models/merged'); "
   python llama.cpp/convert_hf_to_gguf.py models/merged --outfile models/water-1.5b.gguf --outtype q8_0
   printf 'FROM ./models/water-1.5b.gguf\n' > Modelfile && ollama create water-qwen -f Modelfile
   ```
   Rồi đặt `LLM_MODEL_NAME=water-qwen` trong `.env`.
4. Đánh giá: so `python -m evaluation.run_eval --router llm --name base` (qwen2.5:1.5b gốc) với bản đã fine-tune; báo cáo cả
   router accuracy, grounded rate, latency. Nếu bản gốc + schema + fallback đã đủ tốt thì không cần fine-tune – hãy để số liệu quyết định.
