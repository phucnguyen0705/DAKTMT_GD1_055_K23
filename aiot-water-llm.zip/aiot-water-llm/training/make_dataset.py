"""Sinh dữ liệu fine-tune cho Qwen2.5-1.5B từ CHÍNH hệ thống (không dùng bảng thô):
  1) router: câu hỏi -> JSON (intent, station_id, parameter, hours, chart)  [ràng buộc bằng schema lúc suy luận]
  2) compose: (câu hỏi, FACTS, KIẾN THỨC) -> câu trả lời chỉ dùng số trong FACTS (nhãn = mẫu xác định, nên đúng theo cấu trúc)
  3) từ chối: câu hỏi ngoài phạm vi
Chia train/val/test theo MẪU CÂU (test dùng cách diễn đạt chưa thấy trong train) và loại mọi câu trùng bộ đánh giá.

  python -m training.make_dataset --out training/data
"""
from __future__ import annotations

import argparse
import json
import random
import tempfile
from pathlib import Path

from backend.app.context import AppContext
from config.settings import Settings
from evaluation.run_eval import load_testset
from llm_engine.prompts.compose import build_compose_messages
from llm_engine.prompts.router import build_router_messages
from orchestrator.compose import template_answer, _slim
from orchestrator.schemas import router_json_schema
from scripts.seed_demo import seed_demo

# (intent, mẫu câu, có chart, cần thông số, cần trạm) - nhóm "test" dùng cách diễn đạt riêng
TEMPLATES = {
    "train": [
        ("status", "Tình trạng hiện tại của trạm {st}?", False, False, True),
        ("status", "WQI trạm {st} bây giờ là bao nhiêu", False, False, True),
        ("status", "Cho tôi xem {p} của trạm {st}", False, True, True),
        ("trend", "Vẽ biểu đồ {p} của trạm {st}", True, True, True),
        ("trend", "Vẽ đồ thị {p} trạm {st} {h} ngày qua", True, True, True),
        ("trend", "Xu hướng WQI của {st} trong {h} ngày qua", False, False, True),
        ("compare", "So sánh {p} giữa các trạm", False, True, False),
        ("compare", "Trạm nào có WQI cao nhất?", False, False, False),
        ("forecast", "Dự báo WQI trạm {st}", False, False, True),
        ("forecast", "Vẽ biểu đồ dự báo WQI của {st}", True, False, True),
        ("explain", "Vì sao trạm {st} có WQI thấp?", False, False, True),
        ("explain", "Nguyên nhân cảnh báo ở trạm {st} là gì?", False, False, True),
        ("standard", "Ngưỡng {p} theo QCVN là bao nhiêu?", False, True, False),
        ("standard", "Quy chuẩn cho {p} như thế nào?", False, True, False),
        ("alerts", "Hiện có cảnh báo nào không?", False, False, False),
        ("alerts", "Danh sách cảnh báo của trạm {st}", False, False, True),
        ("knowledge", "{p} là gì và vì sao quan trọng?", False, True, False),
        ("knowledge", "{p} thấp thì nên làm gì?", False, True, False),
    ],
    "test": [
        ("status", "{st} hiện giờ chất lượng nước ra sao nhỉ", False, False, True),
        ("trend", "cho mình biểu đồ {p} ở {st} {h} ngày gần đây", True, True, True),
        ("compare", "trạm nào kém nhất về {p}", False, True, False),
        ("forecast", "sắp tới WQI của {st} có xấu đi không", False, False, True),
        ("explain", "tại sao {st} lại bị cảnh báo", False, False, True),
        ("standard", "giới hạn cho phép của {p} là gì", False, True, False),
        ("alerts", "đang có sự cố gì không", False, False, False),
        ("knowledge", "giải thích giúp tôi về {p}", False, True, False),
    ],
}
OUT_OF_SCOPE = ["Hôm nay giá xăng bao nhiêu?", "Viết giúp tôi email xin nghỉ phép", "Ai là tổng thống Mỹ?",
                "Dịch câu này sang tiếng Anh: xin chào", "Công thức nấu phở bò", "Bitcoin đang giá bao nhiêu",
                "Tính 25 nhân 17", "Kể một câu chuyện cười", "Giải phương trình x^2 - 5x + 6 = 0",
                "Thời tiết Hà Nội ngày mai", "Lập trình web bằng ngôn ngữ nào dễ học?", "Bóng đá tối nay có trận nào"]
OUT_OF_SCOPE_TEST = ["Thủ đô của Nhật là gì", "cho tôi lời khuyên mua laptop", "Phim nào hay trên Netflix"]
PARAM_PHRASES = {  # cách người dùng gọi từng thông số (cố tình có biến thể không dấu)
    "do_mgL": ["DO", "oxy hòa tan"], "ph": ["pH", "độ pH"], "nh4n_mgL": ["amoni", "NH4-N"],
    "codmn_mgL": ["CODMn", "chất hữu cơ"], "turbidity_ntu": ["độ đục"], "tds_ppm": ["TDS"],
    "temperature_c": ["nhiệt độ nước"]}


def _route_sample(ctx, stations, q, label):
    msgs = build_router_messages(q, stations, ctx.registry.keys, None)
    return {"task": "router", "messages": msgs + [{"role": "assistant", "content": json.dumps(label, ensure_ascii=False)}]}


def build(seed: int = 0, per_template: int = 12) -> dict[str, list[dict]]:
    rng = random.Random(seed)
    tmp = tempfile.mkdtemp(prefix="mk_")
    s = Settings(DB_PATH=f"{tmp}/d.db", CHARTS_DIR=f"{tmp}/c", MODELS_DIR=f"{tmp}/m", _env_file=None)
    ctx = AppContext.build(s, llm=None)
    seed_demo(ctx)
    stations = ctx.storage.list_stations()
    ids = [x["station_id"] for x in stations]
    eval_q = {i["question"].lower() for i in load_testset()}
    out: dict[str, list[dict]] = {"train": [], "val": [], "test": []}
    for group, tpls in TEMPLATES.items():
        for intent, tpl, chart, need_p, need_s in tpls:
            for _ in range(per_template if group == "train" else 6):
                p = rng.choice(list(PARAM_PHRASES)) if need_p else None
                st = rng.choice(ids) if need_s else None
                h = rng.choice([1, 2, 3, 7])
                q = tpl.format(st=st, p=rng.choice(PARAM_PHRASES[p]) if p else "", h=h).strip()
                if rng.random() < 0.15:
                    q = q.lower()
                if q.lower() in eval_q:
                    continue
                label = {"intent": intent, "station_id": st, "parameter": p,
                         "hours": h * 24 if "{h}" in tpl else None, "chart": chart}
                split = "test" if group == "test" else ("val" if rng.random() < 0.15 else "train")
                out[split].append(_route_sample(ctx, stations, q, label))
    for q in OUT_OF_SCOPE + OUT_OF_SCOPE_TEST:
        for split in (["train"] * 2 + ["val"] if q in OUT_OF_SCOPE else ["test"]):
            out[split].append(_route_sample(ctx, stations, q, {"intent": "out_of_scope", "station_id": None,
                                                                "parameter": None, "hours": None, "chart": False}))
    # compose: FACTS thật từ hệ thống, nhãn = câu mẫu xác định
    for sid in ids:
        for q, intent, f in (("Tình trạng trạm hiện tại?", "status", ctx.tools.get_status(sid)),
                             ("Xu hướng WQI thế nào?", "trend", ctx.tools.get_trend(sid)),
                             ("Giải thích tình trạng và khuyến nghị", "explain", ctx.tools.explain(sid)),
                             ("Dự báo WQI", "forecast", ctx.tools.forecast(sid))):
            if not f.get("ok"):
                continue
            ans = template_answer(intent, f, ctx.registry)
            msgs = build_compose_messages(q, _slim(f), f.get("knowledge", []))
            out["train" if sid != ids[-1] else "test"].append(
                {"task": "compose", "messages": msgs + [{"role": "assistant", "content": ans}]})
    for k in out:
        rng.shuffle(out[k])
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="training/data")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()
    d = Path(a.out); d.mkdir(parents=True, exist_ok=True)
    data = build(a.seed)
    for split, rows in data.items():
        with open(d / f"{split}.jsonl", "w", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        print(split, len(rows))
    (d / "router_schema.json").write_text(json.dumps(router_json_schema(list(PARAM_PHRASES)), indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
