"""QLoRA fine-tune Qwen2.5-1.5B-Instruct trên training/data/*.jsonl.
CHƯA CHẠY TRONG MÔI TRƯỜNG PHÁT TRIỂN NÀY (không có GPU). Đã nhắm tới RTX 3050 4GB: 4-bit, batch 1, grad-accum 16,
seq 1024, gradient checkpointing. Nếu hết VRAM: giảm --max-len 768 hoặc dùng Colab/Kaggle T4 (16GB).

  pip install -r training/requirements-train.txt
  python -m training.make_dataset
  python -m training.train_qlora --out models/qwen1.5b-water-lora
Sau đó gộp LoRA và chuyển GGUF cho Ollama: xem training/README.md.
"""
from __future__ import annotations

import argparse


def main() -> None:                                                        # pragma: no cover
    import torch
    from datasets import load_dataset
    from peft import LoraConfig
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    from trl import SFTConfig, SFTTrainer

    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="Qwen/Qwen2.5-1.5B-Instruct")
    ap.add_argument("--data", default="training/data")
    ap.add_argument("--out", default="models/qwen1.5b-water-lora")
    ap.add_argument("--epochs", type=float, default=3)
    ap.add_argument("--max-len", type=int, default=1024)
    a = ap.parse_args()

    tok = AutoTokenizer.from_pretrained(a.base)
    model = AutoModelForCausalLM.from_pretrained(
        a.base, quantization_config=BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                                                       bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True),
        device_map="auto")
    ds = load_dataset("json", data_files={"train": f"{a.data}/train.jsonl", "validation": f"{a.data}/val.jsonl"})
    ds = ds.remove_columns([c for c in ds["train"].column_names if c != "messages"])   # chỉ giữ 'messages'
    cfg = SFTConfig(output_dir=a.out, num_train_epochs=a.epochs, per_device_train_batch_size=1,
                    gradient_accumulation_steps=16, learning_rate=2e-4, lr_scheduler_type="cosine", warmup_ratio=0.03,
                    fp16=True, gradient_checkpointing=True, logging_steps=10, eval_strategy="epoch",
                    save_strategy="epoch", max_length=a.max_len, assistant_only_loss=False, report_to="none")
    peft = LoraConfig(r=16, lora_alpha=32, lora_dropout=0.05, task_type="CAUSAL_LM",
                      target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"])
    SFTTrainer(model=model, args=cfg, train_dataset=ds["train"], eval_dataset=ds["validation"],
               processing_class=tok, peft_config=peft).train()
    model.save_pretrained(a.out)
    tok.save_pretrained(a.out)


if __name__ == "__main__":
    main()
