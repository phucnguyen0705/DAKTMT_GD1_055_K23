"""Holt (làm trơn mũ kép) - dự báo cơ sở, không cần huấn luyện, dùng khi chưa có mô hình sklearn."""
from __future__ import annotations

import math
from typing import List, Sequence, Tuple


def holt_forecast(y: Sequence[float], steps: int, alpha: float = 0.5, beta: float = 0.2) -> Tuple[List[float], float]:
    """Trả về (dự báo, độ lệch chuẩn sai số một bước). Yêu cầu >= 3 điểm."""
    y = [float(v) for v in y]
    if len(y) < 3:
        raise ValueError("cần ít nhất 3 điểm")
    level, trend = y[0], y[1] - y[0]
    errs = []
    for v in y[1:]:
        pred = level + trend
        errs.append(v - pred)
        new_level = alpha * v + (1 - alpha) * (level + trend)
        trend = beta * (new_level - level) + (1 - beta) * trend
        level = new_level
    sd = math.sqrt(sum(e * e for e in errs) / len(errs))
    damp = 0.9                                      # giảm dần xu hướng để không ngoại suy quá đà
    out, acc = [], 0.0
    for h in range(1, steps + 1):
        acc += damp ** h
        out.append(level + acc * trend)
    return out, sd
