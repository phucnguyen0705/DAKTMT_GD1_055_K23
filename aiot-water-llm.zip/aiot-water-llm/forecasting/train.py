"""Huấn luyện mô hình dự báo WQI (sklearn) và so với đường cơ sở persistence, chia theo THỜI GIAN."""
from __future__ import annotations

import json
from pathlib import Path

import joblib
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor

from forecasting.features import N_LAGS, make_supervised
from storage.db import Storage


def train_forecaster(storage: Storage, models_dir: str | Path, source: str | None = None,
                     test_frac: float = 0.2, min_len: int = 12) -> dict:
    df = storage.all_wqi_series(source=source)
    if df.empty:
        raise ValueError("không có dữ liệu WQI để huấn luyện")
    tr_X, tr_y, te_X, te_y, te_prev = [], [], [], [], []
    for _, g in df.groupby("station_id"):
        s = g.sort_values("ts")["wqi"].astype(float).tolist()
        if len(s) < min_len:
            continue
        X, y = make_supervised(s, N_LAGS)
        cut = int(len(y) * (1 - test_frac))
        tr_X.append(X[:cut]); tr_y.append(y[:cut])
        te_X.append(X[cut:]); te_y.append(y[cut:]); te_prev.append(X[cut:, 0])
    if not tr_X:
        raise ValueError("không trạm nào đủ dài để huấn luyện")
    tr_X, tr_y = np.vstack(tr_X), np.concatenate(tr_y)
    te_X, te_y, te_prev = np.vstack(te_X), np.concatenate(te_y), np.concatenate(te_prev)
    model = GradientBoostingRegressor(n_estimators=150, max_depth=3, learning_rate=0.05, random_state=0)
    model.fit(tr_X, tr_y)
    pred = model.predict(te_X)
    mae = float(np.mean(np.abs(pred - te_y)))
    base = float(np.mean(np.abs(te_prev - te_y)))
    resid = float(np.std(te_y - pred))
    out = Path(models_dir)
    out.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": model, "n_lags": N_LAGS, "resid_sd": resid}, out / "wqi_forecaster.joblib")
    metrics = {"mae": round(mae, 3), "baseline_persistence_mae": round(base, 3),
               "improvement_pct": round(100 * (base - mae) / base, 1) if base else None,
               "n_train": int(len(tr_y)), "n_test": int(len(te_y)), "resid_sd": round(resid, 3)}
    (out / "wqi_forecaster_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    return metrics
