"""Đặc trưng trễ cho dự báo WQI một bước (dùng chung cho huấn luyện và dự báo)."""
from __future__ import annotations

import numpy as np

N_LAGS = 4


def lag_row(history: list[float], n_lags: int = N_LAGS) -> list[float]:
    h = history[-n_lags:]
    mean = float(np.mean(h))
    return list(h[::-1]) + [mean, h[-1] - h[0]]          # lag1..lagN, trung bình, chênh lệch


def make_supervised(series: list[float], n_lags: int = N_LAGS):
    X, y = [], []
    for i in range(n_lags, len(series)):
        X.append(lag_row(series[:i], n_lags))
        y.append(series[i])
    return np.array(X), np.array(y)
