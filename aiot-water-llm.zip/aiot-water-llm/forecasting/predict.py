from __future__ import annotations

from pathlib import Path

import joblib
import pandas as pd

from forecasting.features import lag_row
from forecasting.holt import holt_forecast
from storage.db import Storage


class Forecaster:
    def __init__(self, storage: Storage, models_dir: str | Path):
        self.storage = storage
        self.path = Path(models_dir) / "wqi_forecaster.joblib"
        self._bundle = None

    def _load(self):
        if self._bundle is None and self.path.exists():
            self._bundle = joblib.load(self.path)
        return self._bundle

    def forecast(self, station_id: str, steps: int = 3, history: int = 60) -> dict:
        rows = self.storage.get_readings(station_id, limit=history, newest=True)
        pts = [(r["ts"], r["wqi"]) for r in rows if r["wqi"] is not None]
        if len(pts) < 5:
            return {"ok": False, "reason": "not_enough_data", "n_history": len(pts)}
        ts = pd.to_datetime([p[0] for p in pts])
        y = [float(p[1]) for p in pts]
        step = pd.Series(ts).diff().median()
        step_hours = round(step.total_seconds() / 3600, 2) if pd.notna(step) else None
        b = self._load()
        method = "holt"
        if b is not None and len(y) >= b["n_lags"]:
            method, h, preds = "gbr_lag", list(y), []
            for _ in range(steps):
                p = float(b["model"].predict([lag_row(h, b["n_lags"])])[0])
                preds.append(p); h.append(p)
            sd = b["resid_sd"]
        else:
            preds, sd = holt_forecast(y, steps)
        preds = [max(0.0, min(100.0, p)) for p in preds]
        # khoảng bất định nở dần theo căn bậc hai số bước (xấp xỉ, không phải khoảng tin cậy chặt)
        out = [{"step": i + 1, "wqi": round(p, 1),
                "low": round(max(0.0, p - 1.64 * sd * (i + 1) ** 0.5), 1),
                "high": round(min(100.0, p + 1.64 * sd * (i + 1) ** 0.5), 1)} for i, p in enumerate(preds)]
        return {"ok": True, "method": method, "step_hours": step_hours, "last_ts": pts[-1][0],
                "last_wqi": round(y[-1], 1), "n_history": len(y), "forecast": out,
                "history_ts": [p[0] for p in pts], "history_wqi": [round(v, 1) for v in y]}
