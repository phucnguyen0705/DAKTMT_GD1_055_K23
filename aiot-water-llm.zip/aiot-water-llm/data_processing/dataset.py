"""
Đọc bộ dữ liệu quan trắc đã làm sạch (parquet dạng wide) và đổi tên cột sang khóa chuẩn của hệ thống.

Cột gốc  -> khóa chuẩn:  DO -> do_mgL, pH -> ph, NH4N -> nh4n_mgL, CODMn -> codmn_mgL, TEMP -> temperature_c
"""
from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional

import pandas as pd

from config.registry import ParameterRegistry

META_COLS = ["station_id", "lon", "lat", "date", "source"]


def load_wide(path: str | Path, registry: ParameterRegistry, sources: Optional[Iterable[str]] = None) -> pd.DataFrame:
    """Đọc parquet wide, lọc theo nguồn (CNEMC/NMEMC/GRQA), đổi tên cột về khóa chuẩn, giữ cột có dữ liệu."""
    df = pd.read_parquet(path)
    if sources:
        df = df[df["source"].isin(list(sources))]
    rename = {}
    for col in df.columns:
        if col in META_COLS:
            continue
        key = registry.canonical(col)
        if key is not None:
            rename[col] = key
    df = df.rename(columns=rename)
    keep = META_COLS + [c for c in df.columns if c in registry.specs]
    df = df[[c for c in keep if c in df.columns]].copy()
    value_cols = [c for c in df.columns if c in registry.specs]
    df = df.dropna(subset=value_cols, how="all")
    df["station_id"] = df["station_id"].astype(str)
    df["source"] = df["source"].astype(str)
    df["date"] = pd.to_datetime(df["date"])
    return df.sort_values(["station_id", "date"]).reset_index(drop=True)
