"""
Làm sạch dữ liệu: nội suy giá trị thiếu, phát hiện/loại outlier, và áp ngưỡng hợp lý theo thông số.
Các hàm gốc (fill_missing, detect_outliers_zscore, remove_outliers, clean_pipeline) được giữ nguyên
hành vi; thêm `apply_plausible_ranges` dùng chung khoảng hợp lý với bộ kiểm tra lúc ingest.
"""
from __future__ import annotations

from typing import Iterable, List

import numpy as np
import pandas as pd

from config.registry import ParameterRegistry


def fill_missing(df: pd.DataFrame, method: str = "interpolate") -> pd.DataFrame:
    """Điền dữ liệu thiếu bằng nội suy tuyến tính (hoặc ffill/bfill)."""
    df = df.copy()
    if method == "interpolate":
        df = df.interpolate(method="linear", limit_direction="both")
    elif method == "ffill":
        df = df.ffill().bfill()
    return df


def detect_outliers_zscore(series: pd.Series, threshold: float = 3.0) -> pd.Series:
    """Mask boolean đánh dấu outlier theo Z-score."""
    std = series.std(ddof=0)
    if not std or np.isnan(std):
        return pd.Series(False, index=series.index)
    return ((series - series.mean()) / std).abs() > threshold


def remove_outliers(df: pd.DataFrame, columns: list, threshold: float = 3.0) -> pd.DataFrame:
    """Thay outlier bằng NaN rồi nội suy lại."""
    df = df.copy()
    for col in columns:
        if col in df.columns:
            df.loc[detect_outliers_zscore(df[col], threshold), col] = np.nan
    return fill_missing(df)


def clean_pipeline(df: pd.DataFrame, sensor_columns: list) -> pd.DataFrame:
    """Pipeline làm sạch đầy đủ: loại outlier + điền thiếu."""
    df = remove_outliers(df, sensor_columns)
    return fill_missing(df)


def apply_plausible_ranges(df: pd.DataFrame, registry: ParameterRegistry,
                           columns: Iterable[str] | None = None) -> tuple[pd.DataFrame, dict]:
    """
    Đặt NaN cho các giá trị ngoài khoảng hợp lý (parameters.yaml). Trả về (df mới, số giá trị bị loại theo cột).
    Khoảng hợp lý trùng với ngưỡng đã dùng khi lọc bộ dữ liệu CNEMC (pH 4-11, DO 0-20, ...).
    """
    df = df.copy()
    removed = {}
    cols: List[str] = list(columns) if columns is not None else [c for c in df.columns if c in registry.specs]
    for col in cols:
        spec = registry.specs.get(col)
        if spec is None or col not in df.columns:
            continue
        lo, hi = spec.plausible
        bad = df[col].notna() & ((df[col] < lo) | (df[col] > hi))
        removed[col] = int(bad.sum())
        df.loc[bad, col] = np.nan
    return df, removed
