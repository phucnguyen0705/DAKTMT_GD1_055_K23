"""
Tính WQI rút gọn theo cấu hình config/wqi.yaml.

Khác với bản gốc (cố định 4 thông số), bản này tính trên CÁC THÔNG SỐ CÓ MẶT trong mẫu đo, và chuẩn
hóa lại trọng số. Nhờ vậy cùng một công thức dùng được cho:
  - thiết bị IoT (pH, DO, độ đục, TDS, nhiệt độ),
  - bộ dữ liệu quan trắc CNEMC (pH, DO, NH4N, CODMn).

LƯU Ý: điểm neo và trọng số là MINH HỌA. Thay bằng phương pháp chính thức bạn chọn khi viết luận văn.
Các hàm `WaterSample`, `calculate_wqi`, `classify_wqi` được giữ lại để tương thích với mã cũ.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Dict, List, Mapping, Optional, Tuple

import numpy as np
import yaml

DEFAULT_PATH = Path(__file__).resolve().parent.parent / "config" / "wqi.yaml"


@dataclass(frozen=True)
class ParamScoring:
    key: str
    weight: float
    xs: Tuple[float, ...]
    ys: Tuple[float, ...]

    def score(self, value: float) -> float:
        return float(np.interp(value, self.xs, self.ys))


@dataclass(frozen=True)
class WQIConfig:
    version: str
    min_params: int
    classes: Tuple[Tuple[float, str], ...]          # (ngưỡng dưới, nhãn), giảm dần
    params: Dict[str, ParamScoring]

    @classmethod
    def load(cls, path: str | Path | None = None) -> "WQIConfig":
        raw = yaml.safe_load(Path(path or DEFAULT_PATH).read_text(encoding="utf-8"))
        params = {}
        for key, p in raw["parameters"].items():
            pts = sorted((float(x), float(y)) for x, y in p["points"])
            params[key] = ParamScoring(key, float(p["weight"]), tuple(x for x, _ in pts), tuple(y for _, y in pts))
        classes = tuple(sorted(((float(c["min"]), c["label"]) for c in raw["classes"]), reverse=True))
        return cls(str(raw["version"]), int(raw.get("min_params", 2)), classes, params)

    def classify(self, wqi: float) -> str:
        for lower, label in self.classes:
            if wqi >= lower:
                return label
        return self.classes[-1][1]


@dataclass
class WQIResult:
    wqi: Optional[float]
    label: Optional[str]
    sub_indices: Dict[str, float] = field(default_factory=dict)
    used: List[str] = field(default_factory=list)
    missing: List[str] = field(default_factory=list)
    driver: Optional[str] = None                    # thông số kéo WQI xuống nhiều nhất
    version: str = ""

    def to_dict(self) -> dict:
        return {
            "wqi": self.wqi, "wqi_class": self.label, "sub_indices": {k: round(v, 1) for k, v in self.sub_indices.items()},
            "used_params": self.used, "missing_params": self.missing, "driver": self.driver, "wqi_version": self.version,
        }


@lru_cache(maxsize=4)
def default_config(path: str | None = None) -> WQIConfig:
    return WQIConfig.load(path)


def _finite(v) -> bool:
    try:
        return v is not None and math.isfinite(float(v))
    except (TypeError, ValueError):
        return False


def compute_wqi(values: Mapping[str, Optional[float]], cfg: WQIConfig | None = None) -> WQIResult:
    """Tính WQI từ dict {khóa thông số: giá trị}. Giá trị None/NaN bị coi là thiếu."""
    cfg = cfg or default_config()
    subs: Dict[str, float] = {}
    for key, ps in cfg.params.items():
        if ps.weight <= 0:
            continue
        v = values.get(key)
        if _finite(v):
            subs[key] = ps.score(float(v))
    missing = [k for k, ps in cfg.params.items() if ps.weight > 0 and k not in subs]
    if len(subs) < cfg.min_params:
        return WQIResult(None, None, subs, list(subs), missing, None, cfg.version)
    wsum = sum(cfg.params[k].weight for k in subs)
    wqi = sum(subs[k] * cfg.params[k].weight for k in subs) / wsum
    wqi = round(float(wqi), 2)
    # thông số kéo WQI xuống nhiều nhất = (100 - điểm) * trọng số lớn nhất
    driver = max(subs, key=lambda k: (100.0 - subs[k]) * cfg.params[k].weight)
    if subs[driver] >= 99.0:
        driver = None                                # mọi thông số đều tốt
    return WQIResult(wqi, cfg.classify(wqi), subs, list(subs), missing, driver, cfg.version)


# ------------------------------------------------------------------ tương thích mã cũ
@dataclass
class WaterSample:
    ph: float
    do_mgL: float
    turbidity_ntu: float
    tds_ppm: float
    temperature_c: float


def calculate_wqi(sample: WaterSample, cfg: WQIConfig | None = None) -> float:
    res = compute_wqi({"ph": sample.ph, "do_mgL": sample.do_mgL, "turbidity_ntu": sample.turbidity_ntu,
                       "tds_ppm": sample.tds_ppm}, cfg)
    return res.wqi if res.wqi is not None else float("nan")


def classify_wqi(wqi: float, cfg: WQIConfig | None = None) -> str:
    return (cfg or default_config()).classify(wqi)


if __name__ == "__main__":
    print(compute_wqi({"ph": 7.2, "do_mgL": 6.5, "turbidity_ntu": 12.3, "tds_ppm": 320}).to_dict())
    print(compute_wqi({"ph": 7.6, "do_mgL": 5.1, "nh4n_mgL": 0.8, "codmn_mgL": 4.2}).to_dict())
