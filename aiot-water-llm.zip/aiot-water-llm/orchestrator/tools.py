"""Các 'công cụ' mà orchestrator gọi. Mỗi hàm trả về dict FACTS thuần dữ liệu (không văn bản tự do).
Cùng bộ hàm này cũng được REST API dùng, nên chatbot và dashboard luôn thấy cùng một sự thật."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from charts.renderer import ChartRenderer
from config.registry import ParameterRegistry, Standards
from config.settings import Settings
from data_processing.wqi_calculator import WQIConfig, compute_wqi
from forecasting.predict import Forecaster
from llm_engine.rag.retriever import BM25Retriever
from policy.policy_engine import PolicyEngine
from storage.db import Storage

PRIMARY_STANDARD = "qcvn08_2023"


class Tools:
    def __init__(self, settings: Settings, storage: Storage, registry: ParameterRegistry, standards: Standards,
                 wqi_cfg: WQIConfig, policy: PolicyEngine, retriever: BM25Retriever, forecaster: Forecaster,
                 charts: ChartRenderer):
        self.s, self.storage, self.registry, self.standards = settings, storage, registry, standards
        self.wqi_cfg, self.policy, self.retriever, self.forecaster, self.charts = wqi_cfg, policy, retriever, forecaster, charts

    # ------------------------------------------------------------------ helpers
    def _usable(self, reading: dict) -> dict:
        return {k: v for k, v in reading["values"].items() if v is not None and reading["flags"].get(k) is None}

    def _std_class(self, key: str, value: float) -> Optional[str]:
        std = self.standards.get(PRIMARY_STANDARD) if PRIMARY_STANDARD in self.standards else None
        return std.classify(key, value) if std else None

    # ------------------------------------------------------------------ tools
    def get_status(self, station_id: str) -> dict:
        r = self.storage.latest_reading(station_id)
        if not r:
            return {"ok": False, "reason": "no_data", "station_id": station_id}
        usable = self._usable(r)
        w = compute_wqi(usable, self.wqi_cfg)
        params = []
        for k, v in r["values"].items():
            if v is None:
                continue
            flag = r["flags"].get(k)
            params.append({"key": k, "label": self.registry.label(k), "value": v, "unit": self.registry.unit(k),
                           "display": self.registry.format(k, v), "flag": flag,
                           "qcvn_class": None if flag else self._std_class(k, v)})
        pol = self.policy.evaluate({**usable, "wqi": w.wqi})
        return {"ok": True, "station_id": station_id, "ts": r["ts"], "wqi": w.wqi, "wqi_class": w.label,
                "driver": w.driver, "driver_label": self.registry.label(w.driver) if w.driver else None,
                "missing_params": w.missing, "wqi_version": w.version, "parameters": params,
                "severity": pol.severity, "matched_rules": [m.id for m in pol.matched],
                "rule_descriptions": [m.description for m in pol.matched],
                "suspect_params": [k for k, f in r["flags"].items() if f == "suspect"]}

    def get_trend(self, station_id: str, parameter: Optional[str] = None, hours: Optional[int] = None,
                  chart: bool = False) -> dict:
        n = self.s.DEFAULT_CHART_POINTS
        df = self.storage.readings_df(station_id, hours=hours, limit=None if hours else n)
        col = parameter or "wqi"
        if df.empty or col not in df or df[col].dropna().empty:
            return {"ok": False, "reason": "no_data", "station_id": station_id, "parameter": col}
        s = df[col].astype(float)
        keep = s.notna()
        s, ts = s[keep], df.loc[keep, "ts"]
        first, last = float(s.iloc[0]), float(s.iloc[-1])
        label = self.registry.label(col) if parameter else "WQI"
        unit = self.registry.unit(col) if parameter else ""
        facts = {"ok": True, "station_id": station_id, "parameter": col, "label": label, "unit": unit,
                 "n_points": int(len(s)), "from_ts": str(ts.iloc[0]), "to_ts": str(ts.iloc[-1]),
                 "first": round(first, 2), "last": round(last, 2), "min": round(float(s.min()), 2),
                 "max": round(float(s.max()), 2), "mean": round(float(s.mean()), 2),
                 "change": round(last - first, 2),
                 "direction": "tăng" if last - first > 0.05 * (abs(first) or 1) else
                              "giảm" if last - first < -0.05 * (abs(first) or 1) else "ổn định"}
        if chart:
            thr = {}
            if parameter:
                std = self.standards.get(PRIMARY_STANDARD) if PRIMARY_STANDARD in self.standards else None
                thr = dict(std.limit_lines(parameter)) if std else {}
                thr = {k: v for k, v in thr.items() if s.min() * 0.5 <= v <= s.max() * 1.5 + 1}
            facts["chart"] = self.charts.line({"st": station_id, "p": col, "h": hours}, list(ts), list(s),
                                              f"{label} - trạm {station_id}", unit or "WQI", thr)
        return facts

    def compare(self, parameter: Optional[str] = None, chart: bool = False, top: int = 10) -> dict:
        rows = []
        for st in self.storage.list_stations():
            r = self.storage.latest_reading(st["station_id"])
            if not r:
                continue
            v = (r["values"].get(parameter) if parameter and not r["flags"].get(parameter) else
                 r["wqi"] if not parameter else None)
            if v is None:
                continue
            rows.append({"station_id": st["station_id"], "value": round(float(v), 2), "ts": r["ts"]})
        if not rows:
            return {"ok": False, "reason": "no_data"}
        # WQI/DO càng cao càng tốt; các thông số ô nhiễm càng thấp càng tốt
        higher_better = parameter in (None, "do_mgL")
        rows.sort(key=lambda x: x["value"], reverse=higher_better)
        label = self.registry.label(parameter) if parameter else "WQI"
        facts = {"ok": True, "parameter": parameter or "wqi", "label": label, "n_stations": len(rows),
                 "best": rows[0], "worst": rows[-1], "ranking": rows[:top], "higher_is_better": higher_better}
        if chart:
            facts["chart"] = self.charts.bar({"p": parameter}, [r["station_id"] for r in rows[:top]],
                                             [r["value"] for r in rows[:top]], f"{label} theo trạm", label)
        return facts

    def forecast(self, station_id: str, steps: int = 3, chart: bool = False) -> dict:
        f = self.forecaster.forecast(station_id, steps)
        if not f["ok"]:
            return {**f, "station_id": station_id}
        facts = {k: f[k] for k in ("ok", "method", "step_hours", "last_ts", "last_wqi", "n_history", "forecast")}
        facts["station_id"] = station_id
        facts["note"] = "Dự báo thống kê từ chuỗi WQI trước đó, khoảng bất định xấp xỉ."
        if chart:
            facts["chart"] = self.charts.forecast({"st": station_id}, f["history_ts"], f["history_wqi"], f["forecast"],
                                                  f["step_hours"], f"Dự báo WQI - trạm {station_id}")
        return facts

    def explain(self, station_id: str) -> dict:
        st = self.get_status(station_id)
        if not st["ok"]:
            return st
        kb = []
        queries = []
        if st.get("driver"):
            queries.append((f"{st['driver_label']} khuyến nghị nguyên nhân", [st["driver"]]))
        if st["severity"] != "info":
            queries.append((f"WQI {st['wqi_class']} khuyến nghị xử lý", None))
        for q, params in queries:
            kb += self.retriever.search(q, k=2, params=params)
        seen, uniq = set(), []
        for c in kb:
            if c["id"] not in seen:
                seen.add(c["id"]); uniq.append(c)
        return {**st, "knowledge": [{"id": c["id"], "text": c["text"]} for c in uniq[: self.s.RAG_TOP_K + 1]]}

    def standard_info(self, parameter: Optional[str] = None) -> dict:
        out = []
        for sid in self.standards.ids():
            std = self.standards.get(sid)
            pl = std.parameters.get(parameter) if parameter else None
            if parameter and pl is None:
                continue
            items = [pl] if pl else list(std.parameters.values())
            out.append({"standard": sid, "name": std.name, "verified": std.verified, "classes": std.classes,
                        "parameters": [{"key": p.key, "label": p.label, "unit": p.unit, "kind": p.kind,
                                        "limits": p.limits} for p in items]})
        if not out:
            return {"ok": False, "reason": "no_standard", "parameter": parameter}
        return {"ok": True, "parameter": parameter, "standards": out,
                "warning": "Giá trị ngưỡng trong cấu hình chưa được đối chiếu với văn bản gốc."
                if any(not s["verified"] for s in out) else None}

    def alerts(self, station_id: Optional[str] = None, limit: int = 5) -> dict:
        items = self.storage.list_alerts(station_id=station_id, status="open")[:limit]
        return {"ok": True, "station_id": station_id, "n_open": len(items),
                "alerts": [{"id": a["id"], "ts": a["ts"], "station_id": a["station_id"], "rule_id": a["rule_id"],
                            "severity": a["severity"], "message": a["message"]} for a in items]}

    def knowledge(self, query: str, parameter: Optional[str] = None) -> dict:
        hits = self.retriever.search(query, k=self.s.RAG_TOP_K, params=[parameter] if parameter else None)
        return {"ok": bool(hits), "query": query,
                "knowledge": [{"id": h["id"], "title": h["title"], "section": h["section"], "text": h["text"]} for h in hits]}
