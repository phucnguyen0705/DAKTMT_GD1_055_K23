"""Router theo từ khóa: baseline để so sánh với LLM và fallback khi LLM lỗi/trả sai."""
from __future__ import annotations

import re
from typing import Iterable, Optional

from config.registry import ParameterRegistry, norm_text
from orchestrator.schemas import RouteDecision

CHART_KW = ["ve ", "bieu do", "do thi", "chart", "plot", "hinh ve"]
KW = [  # thứ tự = độ ưu tiên
    ("forecast", ["du bao", "tuong lai", "ngay mai", "tuan toi", "se ra sao", "predict", "sap toi"]),
    ("explain", ["tai sao", "vi sao", "nguyen nhan", "giai thich", "nen lam gi", "khuyen nghi", "xu ly", "lam sao", "khac phuc"]),
    ("alerts", ["canh bao", "bao dong", "alert", "su co"]),
    ("compare", ["so sanh", "tram nao", "xep hang", "cao nhat", "thap nhat", "tot nhat", "te nhat", "kem nhat"]),
    ("standard", ["nguong", "quy chuan", "qcvn", "tieu chuan", "gb 3838", "gb3838", "gioi han", "lop a", "lop b"]),
    ("trend", ["xu huong", "bien dong", "lich su", "thay doi", "vua qua", "gan day", "ngay qua", "tuan qua", "thang qua", "theo thoi gian"]),
    ("knowledge", ["la gi", "anh huong", "y nghia", "co nghia", "dung de lam gi"]),
    ("status", ["hien tai", "bay gio", "moi nhat", "tinh trang", "chat luong nuoc", "wqi", "the nao", "ra sao"]),
]


def detect_hours(t: str) -> Optional[int]:
    m = re.search(r"(\d+)\s*(gio|ngay|tuan|thang)", t)
    if m:
        n, u = int(m.group(1)), m.group(2)
        return n * {"gio": 1, "ngay": 24, "tuan": 168, "thang": 720}[u]
    for word, h in (("hom nay", 24), ("tuan qua", 168), ("tuan nay", 168), ("thang qua", 720), ("thang nay", 720)):
        if word in t:
            return h
    return None


def detect_station(t: str, stations: Iterable[dict]) -> Optional[str]:
    best = (0, None)
    for s in stations:
        for cand in (s["station_id"], s.get("name") or ""):
            c = norm_text(str(cand))
            if len(c) >= 2 and re.search(r"(?<![a-z0-9])" + re.escape(c) + r"(?![a-z0-9])", t) and len(c) > best[0]:
                best = (len(c), s["station_id"])
    return best[1]


_BARE_DO = re.compile(r"(?<![a-z0-9])do(?![a-z0-9])")


def detect_parameter(question: str, t: str, registry: ParameterRegistry) -> Optional[str]:
    """Phát hiện thông số. 'do' (sau khi bỏ dấu) trùng với 'đồ' (biểu đồ), 'đo', 'do' (bởi vì), nên chỉ chấp nhận
    DO khi viết hoa đứng riêng, hoặc có 'oxy'/'dissolved'; ngược lại bỏ từ 'do' trần rồi dò lại."""
    key = registry.detect_in_text(t)
    if key == "do_mgL" and not (re.search(r"(?<![A-Za-z0-9])DO(?![A-Za-z0-9])", question) or "oxy" in t or "dissolved" in t):
        key = registry.detect_in_text(_BARE_DO.sub(" ", t))
    return key


def detect_entities(question: str, registry: ParameterRegistry, stations: Iterable[dict]) -> dict:
    t = norm_text(question) + " "
    return {"t": t, "parameter": detect_parameter(question, t, registry), "station_id": detect_station(t, stations),
            "hours": detect_hours(t), "chart": any(k in t for k in CHART_KW)}


def route_by_rules(question: str, registry: ParameterRegistry, stations: Iterable[dict]) -> RouteDecision:
    e = detect_entities(question, registry, stations)
    t = e["t"]
    intent = None
    for name, kws in KW:
        if any(k in t for k in kws):
            intent = name
            break
    if intent is None:
        if e["chart"] and (e["parameter"] or e["station_id"]):
            intent = "trend"
        elif e["parameter"] or e["station_id"]:
            intent = "status"
        else:
            intent = "out_of_scope"
    WATER = ("nuoc", "wqi", "o nhiem", "oxy", "tram", "cam bien", "quan trac")
    if intent in ("knowledge", "explain") and not e["parameter"] and not e["station_id"] \
            and not any(w in t for w in WATER):
        intent = "out_of_scope"                       # "X là gì?" không liên quan chất lượng nước
    if intent == "status" and e["chart"]:
        intent = "trend"
    return RouteDecision(intent=intent, station_id=e["station_id"], parameter=e["parameter"],
                         hours=e["hours"], chart=e["chart"], source="rules")
