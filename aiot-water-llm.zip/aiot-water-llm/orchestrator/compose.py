"""Soạn câu trả lời: mẫu xác định (luôn đúng) hoặc LLM + kiểm tra neo dữ liệu, sai thì rơi về mẫu."""
from __future__ import annotations

from typing import List, Optional

from config.registry import ParameterRegistry
from config.settings import Settings
from llm_engine.ollama_client import LLMUnavailable, OllamaClient
from llm_engine.prompts.compose import build_compose_messages
from orchestrator.grounding import check_grounding

DISCLAIMER = "Đây là hướng dẫn tham khảo, không thay thế đánh giá của chuyên gia."


def _fmt_limit(pl: dict, cls: str) -> str:
    v = pl["limits"].get(cls)
    if v is None:
        return "không giới hạn"
    if pl["kind"] == "range":
        return f"{v[0]:g} - {v[1]:g}"
    return f"{'≥' if pl['kind'] == 'min' else '≤'} {v:g}"


def template_answer(intent: str, f: dict, reg: ParameterRegistry) -> str:
    if not f.get("ok", True) and f.get("reason") == "need_station":
        return "Bạn muốn hỏi về trạm nào? Hãy chọn một trạm hoặc nêu tên trạm trong câu hỏi."
    if not f.get("ok", True):
        why = {"no_data": "Chưa có dữ liệu cho yêu cầu này.",
               "not_enough_data": "Chưa đủ dữ liệu lịch sử để dự báo (cần ít nhất 5 mẫu có WQI).",
               "no_standard": "Không tìm thấy ngưỡng tiêu chuẩn cho thông số này."}
        return why.get(f.get("reason"), "Không thực hiện được yêu cầu.")
    if intent == "status":
        s = f"Trạm {f['station_id']} lúc {f['ts']}: "
        s += f"WQI {f['wqi']:g} ({f['wqi_class']})." if f["wqi"] is not None else "chưa đủ thông số để tính WQI."
        s += " " + "; ".join(f"{p['label']} {p['display']}" for p in f["parameters"] if not p["flag"]) + "."
        if f["driver_label"]:
            s += f" Thông số kéo WQI xuống nhiều nhất: {f['driver_label']}."
        if f["rule_descriptions"] and f["severity"] != "info":
            s += " Cảnh báo: " + "; ".join(f["rule_descriptions"]) + "."
        if f["suspect_params"]:
            s += " Nghi lỗi cảm biến: " + ", ".join(reg.label(k) for k in f["suspect_params"]) + "."
        return s
    if intent == "trend":
        u = f" {f['unit']}" if f["unit"] else ""
        return (f"{f['label']} trạm {f['station_id']} từ {f['from_ts']} đến {f['to_ts']} ({f['n_points']} mẫu): "
                f"đầu kỳ {f['first']:g}{u}, cuối kỳ {f['last']:g}{u}, thấp nhất {f['min']:g}{u}, cao nhất {f['max']:g}{u}, "
                f"trung bình {f['mean']:g}{u}; xu hướng {f['direction']}.")
    if intent == "compare":
        b, w = f["best"], f["worst"]
        return (f"{f['label']} theo {f['n_stations']} trạm: tốt nhất là trạm {b['station_id']} ({b['value']:g}), "
                f"kém nhất là trạm {w['station_id']} ({w['value']:g}).")
    if intent == "forecast":
        unit = f"{f['step_hours']:g} giờ" if f.get("step_hours") else "một bước"
        pts = "; ".join(f"bước {x['step']}: {x['wqi']:g} (khoảng {x['low']:g}-{x['high']:g})" for x in f["forecast"])
        return (f"Dự báo WQI trạm {f['station_id']} (mỗi bước ≈ {unit}, phương pháp {f['method']}): {pts}. "
                f"Giá trị hiện tại {f['last_wqi']:g}. Đây là ước lượng thống kê, độ bất định tăng theo số bước.")
    if intent == "explain":
        s = template_answer("status", f, reg)
        recs = [k["text"] for k in f.get("knowledge", []) if "khuyen-nghi" in k["id"]]
        if recs:
            s += " Khuyến nghị: " + " ".join(recs[:2])
        return s + " " + DISCLAIMER
    if intent == "standard":
        parts: List[str] = []
        for st in f["standards"]:
            for p in st["parameters"]:
                lim = ", ".join(f"{c}: {_fmt_limit(p, c)}" for c in st["classes"])
                parts.append(f"{st['name']} - {p['label']} ({p['unit']}): {lim}")
        s = "\n".join(parts[:8])
        if f.get("warning"):
            s += f"\nLưu ý: {f['warning']}"
        return s
    if intent == "alerts":
        if not f["alerts"]:
            return "Hiện không có cảnh báo đang mở."
        return f"Có {f['n_open']} cảnh báo đang mở:\n" + "\n".join(
            f"- [{a['severity']}] trạm {a['station_id']}: {a['message']}" for a in f["alerts"])
    if intent == "knowledge":
        return "\n".join(k["text"] for k in f["knowledge"][:2]) if f.get("knowledge") else "Chưa có tri thức phù hợp."
    return "Tôi chỉ hỗ trợ các câu hỏi về chất lượng nước và dữ liệu quan trắc của hệ thống."


def _slim(f: dict) -> dict:
    """Bỏ phần nặng (văn bản KB, lịch sử) khỏi FACTS gửi cho LLM nhỏ."""
    return {k: v for k, v in f.items() if k not in ("knowledge", "history_ts", "history_wqi", "rule_descriptions")}


class Composer:
    def __init__(self, settings: Settings, registry: ParameterRegistry, llm: OllamaClient | None):
        self.s, self.registry, self.llm = settings, registry, llm

    def compose(self, question: str, intent: str, facts: dict) -> dict:
        tmpl = template_answer(intent, facts, self.registry)
        res = {"answer": tmpl, "grounded": True, "fallback_used": False, "tokens_in": 0, "tokens_out": 0,
               "latency_ms": 0.0, "bad_numbers": [], "composer": "template", "llm_error": None}
        direct = intent in ("out_of_scope", "alerts", "standard") or not facts.get("ok", True)
        if self.s.COMPOSE_MODE == "template" or self.llm is None or direct:
            return res                       # các intent này trả lời chính xác bằng mẫu; không cần LLM
        snippets = facts.get("knowledge", [])
        try:
            r = self.llm.chat(build_compose_messages(question, _slim(facts), snippets), max_tokens=300)
        except LLMUnavailable as e:
            res.update(fallback_used=True, llm_error=str(e))
            return res
        res.update(tokens_in=r.tokens_in, tokens_out=r.tokens_out, latency_ms=r.latency_ms)
        text = r.text.strip()
        ok, bad = check_grounding(text, _slim(facts), [s["text"] for s in snippets])
        if not text or (not ok and self.s.GROUNDING_MODE == "strict"):
            res.update(fallback_used=True, grounded=ok if text else False, bad_numbers=bad)
            return res
        res.update(answer=text, grounded=ok, bad_numbers=bad, composer="llm")
        return res
