"""Router: LLM nhỏ trả JSON theo schema; thực thể (trạm, thông số, thời gian) luôn được bổ sung/kiểm tra bằng luật."""
from __future__ import annotations

import logging
from typing import Iterable

from config.registry import ParameterRegistry
from config.settings import Settings
from llm_engine.ollama_client import LLMUnavailable, OllamaClient
from llm_engine.prompts.router import build_router_messages
from orchestrator.rules_router import detect_entities, route_by_rules
from orchestrator.schemas import INTENTS, RouteDecision, router_json_schema

log = logging.getLogger(__name__)


class Router:
    def __init__(self, settings: Settings, registry: ParameterRegistry, llm: OllamaClient | None):
        self.s, self.registry, self.llm = settings, registry, llm
        self.schema = router_json_schema(registry.keys)

    def route(self, question: str, stations: list[dict], ctx_station: str | None = None) -> tuple[RouteDecision, dict]:
        """Trả về (quyết định, thông tin đo đạc: tokens, latency, lỗi)."""
        meta = {"tokens_in": 0, "tokens_out": 0, "latency_ms": 0.0, "llm_error": None}
        mode = self.s.ROUTER_MODE
        if mode == "rules" or self.llm is None:
            return route_by_rules(question, self.registry, stations), meta
        ent = detect_entities(question, self.registry, stations)
        try:
            resp = self.llm.chat(build_router_messages(question, stations, self.registry.keys, ctx_station),
                                 json_schema=self.schema, temperature=0.0, max_tokens=120)
            meta.update(tokens_in=resp.tokens_in, tokens_out=resp.tokens_out, latency_ms=resp.latency_ms)
            p = resp.parsed
            if not isinstance(p, dict) or p.get("intent") not in INTENTS:
                raise ValueError("router trả JSON không hợp lệ")
        except (LLMUnavailable, ValueError) as e:
            meta["llm_error"] = f"{type(e).__name__}: {e}"
            if mode == "llm":
                return RouteDecision(intent="out_of_scope", source="llm_error"), meta
            return route_by_rules(question, self.registry, stations), meta
        known = {s["station_id"] for s in stations}
        st = p.get("station_id")
        par = p.get("parameter")
        d = RouteDecision(
            intent=p["intent"],
            station_id=ent["station_id"] or (st if st in known else None),   # luật ưu tiên: không tin trạm LLM bịa
            parameter=ent["parameter"] or (par if par in self.registry.keys else None),
            hours=ent["hours"] or (p.get("hours") if isinstance(p.get("hours"), int) and p["hours"] > 0 else None),
            chart=bool(p.get("chart")) or ent["chart"], source="llm")
        return d, meta
