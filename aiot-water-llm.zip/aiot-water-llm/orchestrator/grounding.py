"""Kiểm tra 'neo dữ liệu': mọi con số trong câu trả lời phải xuất hiện trong FACTS (cho phép sai khác do làm tròn)."""
from __future__ import annotations

import re
from typing import Any, Iterable, List

NUM = re.compile(r"(?<![\w.])-?\d+(?:[.,]\d+)?")
STR_NUM = re.compile(r"\d+(?:\.\d+)?")


def numbers_in_text(text: str) -> List[tuple[float, int]]:
    """[(giá trị, số chữ số thập phân)] - bỏ ký hiệu mục danh sách dạng '1.' ở đầu dòng."""
    text = re.sub(r"(?m)^\s*\d+[.)]\s+", "", text)
    out = []
    for m in NUM.findall(text):
        s = m.replace(",", ".")
        out.append((float(s), len(s.split(".")[1]) if "." in s else 0))
    return out


def collect_numbers(obj: Any, acc: set | None = None) -> set:
    acc = set() if acc is None else acc
    if isinstance(obj, bool) or obj is None:
        return acc
    if isinstance(obj, (int, float)):
        acc.add(float(obj))
    elif isinstance(obj, str):
        acc.update(float(x) for x in STR_NUM.findall(obj))
    elif isinstance(obj, dict):
        for k, v in obj.items():
            collect_numbers(k, acc); collect_numbers(v, acc)
    elif isinstance(obj, Iterable):
        for v in obj:
            collect_numbers(v, acc)
    return acc


def check_grounding(answer: str, facts: Any, extra_text: Iterable[str] = ()) -> tuple[bool, List[float]]:
    allowed = collect_numbers(facts)
    for t in extra_text:
        allowed.update(float(x) for x in STR_NUM.findall(t))
    bad = []
    for val, dec in numbers_in_text(answer):
        tol = 0.5 * 10 ** (-dec) + 1e-9
        if not any(abs(val - a) <= tol or abs(abs(val) - a) <= tol for a in allowed):
            bad.append(val)
    return (not bad), bad
