"""Orchestrator: câu hỏi -> router -> tool -> soạn câu trả lời (+ kiểm tra) -> ghi log."""
from __future__ import annotations

import time
from typing import Optional

from config.settings import Settings
from orchestrator.compose import Composer
from orchestrator.router import Router
from orchestrator.schemas import RouteDecision
from orchestrator.tools import Tools
from storage.db import Storage


class Orchestrator:
    def __init__(self, settings: Settings, storage: Storage, router: Router, tools: Tools, composer: Composer):
        self.s, self.storage, self.router, self.tools, self.composer = settings, storage, router, tools, composer

    def _run_tool(self, d: RouteDecision, question: str, station: Optional[str]) -> dict:
        t, st = self.tools, station
        if d.intent in ("status", "trend", "forecast", "explain") and not st:
            return {"ok": False, "reason": "need_station"}
        if d.intent == "status":
            return t.get_status(st)
        if d.intent == "trend":
            return t.get_trend(st, d.parameter, d.hours, chart=d.chart)
        if d.intent == "forecast":
            return t.forecast(st, chart=d.chart)
        if d.intent == "explain":
            return t.explain(st)
        if d.intent == "compare":
            return t.compare(d.parameter, chart=d.chart)
        if d.intent == "standard":
            return t.standard_info(d.parameter)
        if d.intent == "alerts":
            return t.alerts(st)
        if d.intent == "knowledge":
            return t.knowledge(question, d.parameter)
        return {"ok": True}

    def answer(self, question: str, station_id: Optional[str] = None, log: bool = True) -> dict:
        t0 = time.perf_counter()
        stations = self.storage.list_stations()
        d, rmeta = self.router.route(question, stations, station_id)
        station = d.station_id or station_id                  # trạm nêu trong câu hỏi thắng trạm đang chọn
        if d.intent == "explain" and not station:             # "DO thấp thì làm gì" không gắn trạm -> tri thức chung
            d.intent = "knowledge"
        t1 = time.perf_counter()
        facts = self._run_tool(d, question, station)
        t2 = time.perf_counter()
        c = self.composer.compose(question, d.intent, facts)
        t3 = time.perf_counter()
        sources = [k["id"] for k in facts.get("knowledge", [])] + [s["standard"] for s in facts.get("standards", [])]
        out = {
            "answer": c["answer"], "intent": d.intent, "route": d.to_dict(), "station_id": station,
            "chart": facts.get("chart"), "facts": facts, "sources": sources,
            "grounded": c["grounded"], "fallback_used": c["fallback_used"], "composer": c["composer"],
            "bad_numbers": c["bad_numbers"], "llm_error": rmeta["llm_error"] or c["llm_error"],
            "usage": {"tokens_in": rmeta["tokens_in"] + c["tokens_in"], "tokens_out": rmeta["tokens_out"] + c["tokens_out"],
                      "cost_usd": round((rmeta["tokens_in"] + c["tokens_in"] + rmeta["tokens_out"] + c["tokens_out"])
                                        / 1000 * self.s.LLM_PRICE_PER_1K_TOKENS, 6)},
            "latency_ms": {"router": round(rmeta["latency_ms"], 1), "tool": round((t2 - t1) * 1000, 1),
                           "compose": round(c["latency_ms"], 1), "total": round((time.perf_counter() - t0) * 1000, 1)},
        }
        if log:
            self.storage.add_chat_log(question, station, d.intent, d.source, out["answer"], int(out["grounded"]),
                                      int(out["fallback_used"]), out["latency_ms"]["total"],
                                      out["usage"]["tokens_in"], out["usage"]["tokens_out"],
                                      {"route": out["route"], "bad_numbers": out["bad_numbers"], "llm_error": out["llm_error"]})
        return out
