from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Optional

INTENTS = ["status", "trend", "compare", "forecast", "explain", "standard", "alerts", "knowledge", "out_of_scope"]


@dataclass
class RouteDecision:
    intent: str = "out_of_scope"
    station_id: Optional[str] = None
    parameter: Optional[str] = None     # khóa chuẩn, vd do_mgL; None = WQI
    hours: Optional[int] = None         # cửa sổ thời gian (giờ), None = mặc định
    chart: bool = False
    source: str = "rules"               # rules | llm | llm+rules

    def to_dict(self) -> dict:
        return asdict(self)


def router_json_schema(param_keys: list[str]) -> dict:
    """Schema ràng buộc đầu ra của router (Ollama `format`)."""
    return {
        "type": "object",
        "properties": {
            "intent": {"type": "string", "enum": INTENTS},
            "station_id": {"type": ["string", "null"]},
            "parameter": {"type": ["string", "null"], "enum": param_keys + [None]},
            "hours": {"type": ["integer", "null"]},
            "chart": {"type": "boolean"},
        },
        "required": ["intent", "chart"],
    }
