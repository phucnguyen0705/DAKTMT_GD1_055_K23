"""
Policy Engine: đánh giá mẫu đo theo luật trong rules.yaml, trả về luật khớp, mức nghiêm trọng và hành động.

Đây là lớp "ra quyết định" tách biệt hoàn toàn khỏi LLM: các hành động liên quan an toàn (cảnh báo khẩn,
khuyến nghị ngưng sử dụng nước) luôn dựa trên luật tường minh, kiểm chứng được. LLM chỉ diễn giải.

Lớp này THUẦN (không tác dụng phụ): gọi `evaluate` bao nhiêu lần cũng không gửi gì ra ngoài.
Việc gửi cảnh báo nằm ở `action_dispatcher.py`.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List

import yaml

from policy.expr import CompiledCondition, UnsafeExpression

DEFAULT_RULES_PATH = Path(__file__).resolve().parent / "rules.yaml"
SEVERITY_ORDER = {"info": 0, "warning": 1, "critical": 2}
KNOWN_ACTIONS = {"notify_telegram", "notify_email", "trigger_llm_report", "recommend_stop_usage", "log_only"}


@dataclass
class MatchedRule:
    id: str
    severity: str
    description: str
    standard: str
    actions: List[str]


@dataclass
class PolicyResult:
    matched: List[MatchedRule] = field(default_factory=list)
    severity: str = "info"                      # info | warning | critical
    actions: List[str] = field(default_factory=list)

    # tên cũ, giữ để tương thích
    @property
    def matched_rules(self) -> List[str]:
        return [m.id for m in self.matched]

    @property
    def explanations(self) -> List[str]:
        return [m.description for m in self.matched]

    def to_dict(self) -> dict:
        return {
            "severity": self.severity, "actions": self.actions,
            "matched": [m.__dict__ for m in self.matched],
            "matched_rules": self.matched_rules, "explanations": self.explanations,
        }


class PolicyEngine:
    def __init__(self, rules_path: str | Path = DEFAULT_RULES_PATH, allowed_names: Iterable[str] = ()):
        self.rules_path = Path(rules_path)
        self.allowed_names = set(allowed_names) | {"wqi"}
        self.rules: List[dict] = []
        self.actions_registry: Dict[str, str] = {}
        self._compiled: Dict[str, CompiledCondition] = {}
        self.reload()

    def reload(self) -> None:
        """Nạp lại rules.yaml; luật sai cú pháp/biến lạ làm hàm này ném lỗi (giữ nguyên luật cũ)."""
        cfg = yaml.safe_load(self.rules_path.read_text(encoding="utf-8"))
        rules, compiled, seen = cfg.get("rules", []), {}, set()
        for rule in rules:
            rid = rule["id"]
            if rid in seen:
                raise ValueError(f"Trùng id luật: {rid}")
            seen.add(rid)
            if rule["severity"] not in SEVERITY_ORDER:
                raise ValueError(f"Luật {rid}: severity không hợp lệ: {rule['severity']}")
            unknown = set(rule.get("actions", [])) - KNOWN_ACTIONS
            if unknown:
                raise ValueError(f"Luật {rid}: hành động không biết: {sorted(unknown)}")
            try:
                compiled[rid] = CompiledCondition(rule["condition"], self.allowed_names)
            except UnsafeExpression as e:
                raise ValueError(f"Luật {rid}: {e}") from e
        self.rules, self._compiled = rules, compiled
        self.actions_registry = cfg.get("actions_registry", {})

    def rule_names(self, rule_id: str) -> List[str]:
        """Các biến mà luật dùng (để hiển thị giá trị liên quan trong thông báo)."""
        return sorted(self._compiled[rule_id].names)

    def evaluable_ids(self, data: Dict[str, Any]) -> List[str]:
        """Id các luật ĐÁNH GIÁ ĐƯỢC với dữ liệu hiện có (đủ biến). Dùng để chỉ đóng alert khi luật thật sự được kiểm tra."""
        return [rid for rid, c in self._compiled.items() if all(data.get(n) is not None for n in c.names)]

    def evaluate(self, data: Dict[str, Any]) -> PolicyResult:
        """
        data: {"wqi": 38.5, "ph": 6.1, "do_mgL": 3.2, ...}; khóa thiếu/None -> luật dùng khóa đó không áp dụng.
        """
        result = PolicyResult()
        top = "info"
        for rule in self.rules:
            if self._compiled[rule["id"]].evaluate(data):
                result.matched.append(MatchedRule(
                    id=rule["id"], severity=rule["severity"], description=rule["description"],
                    standard=rule.get("standard", ""), actions=list(rule.get("actions", []))))
                result.actions.extend(rule.get("actions", []))
                if SEVERITY_ORDER[rule["severity"]] > SEVERITY_ORDER[top]:
                    top = rule["severity"]
        result.severity = top
        result.actions = list(dict.fromkeys(result.actions))      # bỏ trùng, giữ thứ tự
        return result


if __name__ == "__main__":
    engine = PolicyEngine(allowed_names=["ph", "do_mgL", "turbidity_ntu", "tds_ppm", "nh4n_mgL", "codmn_mgL"])
    res = engine.evaluate({"wqi": 22.0, "ph": 5.5, "do_mgL": 1.9, "turbidity_ntu": 60})
    print(res.severity, res.matched_rules, res.actions)
