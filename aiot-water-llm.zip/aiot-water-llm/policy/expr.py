"""
Bộ đánh giá biểu thức điều kiện AN TOÀN cho rules.yaml.

Bản gốc dùng eval() với __builtins__ rỗng, cách này vẫn có thể bị lách (ví dụ qua thuộc tính của đối tượng).
Ở đây biểu thức được phân tích bằng `ast` và chỉ chấp nhận một tập nút rất hẹp:
    so sánh (<, <=, >, >=, ==, !=, có thể xích: 26 <= wqi < 51), and / or / not,
    + - * /, số, tên biến thuộc danh sách cho phép.
Không có gọi hàm, truy cập thuộc tính, chỉ số, lambda, chuỗi... Biểu thức được kiểm tra khi nạp luật,
nên luật sai bị phát hiện ngay, không đợi đến lúc có dữ liệu.
"""
from __future__ import annotations

import ast
import operator as op
from typing import Any, Dict, Iterable, Optional, Set

_CMP = {ast.Lt: op.lt, ast.LtE: op.le, ast.Gt: op.gt, ast.GtE: op.ge, ast.Eq: op.eq, ast.NotEq: op.ne}
_BIN = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv}


class UnsafeExpression(ValueError):
    """Biểu thức chứa cú pháp không được phép hoặc biến không biết."""


def _validate(node: ast.AST, allowed: Set[str], names: Set[str]) -> None:
    if isinstance(node, ast.Expression):
        _validate(node.body, allowed, names)
    elif isinstance(node, ast.BoolOp) and isinstance(node.op, (ast.And, ast.Or)):
        for v in node.values:
            _validate(v, allowed, names)
    elif isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.Not, ast.USub, ast.UAdd)):
        _validate(node.operand, allowed, names)
    elif isinstance(node, ast.BinOp) and type(node.op) in _BIN:
        _validate(node.left, allowed, names)
        _validate(node.right, allowed, names)
    elif isinstance(node, ast.Compare) and all(type(o) in _CMP for o in node.ops):
        _validate(node.left, allowed, names)
        for c in node.comparators:
            _validate(c, allowed, names)
    elif isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
        return
    elif isinstance(node, ast.Name):
        if node.id not in allowed:
            raise UnsafeExpression(f"Biến không được phép: {node.id!r}")
        names.add(node.id)
    else:
        raise UnsafeExpression(f"Cú pháp không được phép: {type(node).__name__}")


def _eval(node: ast.AST, ctx: Dict[str, Any]) -> Any:
    if isinstance(node, ast.Expression):
        return _eval(node.body, ctx)
    if isinstance(node, ast.BoolOp):
        if isinstance(node.op, ast.And):
            return all(_eval(v, ctx) for v in node.values)
        return any(_eval(v, ctx) for v in node.values)
    if isinstance(node, ast.UnaryOp):
        val = _eval(node.operand, ctx)
        if isinstance(node.op, ast.Not):
            return not val
        return -val if isinstance(node.op, ast.USub) else +val
    if isinstance(node, ast.BinOp):
        return _BIN[type(node.op)](_eval(node.left, ctx), _eval(node.right, ctx))
    if isinstance(node, ast.Compare):
        left = _eval(node.left, ctx)
        for operator_, comparator in zip(node.ops, node.comparators):
            right = _eval(comparator, ctx)
            if not _CMP[type(operator_)](left, right):
                return False
            left = right
        return True
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name):
        return ctx[node.id]
    raise UnsafeExpression(type(node).__name__)          # không thể xảy ra sau _validate


class CompiledCondition:
    def __init__(self, source: str, allowed_names: Iterable[str]):
        self.source = source
        try:
            tree = ast.parse(source.strip(), mode="eval")
        except SyntaxError as e:
            raise UnsafeExpression(f"Biểu thức sai cú pháp: {source!r} ({e.msg})") from e
        names: Set[str] = set()
        _validate(tree, set(allowed_names), names)
        self.tree = tree
        self.names = names

    def evaluate(self, ctx: Dict[str, Any]) -> Optional[bool]:
        """True/False; None nếu thiếu dữ liệu cho một biến (luật không áp dụng được)."""
        for n in self.names:
            if ctx.get(n) is None:
                return None
        try:
            return bool(_eval(self.tree, ctx))
        except ZeroDivisionError:
            return None
