"""
Action Dispatcher: THỰC THI các hành động mà PolicyEngine quyết định cho một alert đã được tạo.

Tách riêng khỏi policy_engine (chỉ quyết định) để:
  - đánh giá luật không bao giờ gửi tin nhắn ngoài ý muốn (lỗi của bản gốc: mỗi lần mở trang đều gửi Telegram),
  - việc gửi chạy nền, không làm chậm API ingest.
Sinh báo cáo LLM (trigger_llm_report) được giao cho `reporter` (có thể None -> bỏ qua).
"""
from __future__ import annotations

import logging
from typing import Callable, Dict, Optional

from alerts.notifier import Notifier
from storage.db import Storage

log = logging.getLogger(__name__)


class Dispatcher:
    def __init__(self, storage: Storage, notifier: Notifier,
                 reporter: Optional[Callable[[int], None]] = None):
        self.storage = storage
        self.notifier = notifier
        self.reporter = reporter          # reporter(alert_id) -> sinh và lưu báo cáo

    def dispatch(self, alert_id: int) -> Dict[str, str]:
        alert = self.storage.get_alert(alert_id)
        if alert is None:
            return {}
        channels = []
        results: Dict[str, str] = {}
        for action in alert["actions"]:
            if action == "notify_telegram":
                channels.append("telegram")
            elif action == "notify_email":
                channels.append("email")
            elif action == "recommend_stop_usage":
                log.warning("KHUYẾN NGHỊ: tạm ngưng sử dụng nguồn nước cho sinh hoạt (trạm %s)", alert["station_id"])
                results["recommend_stop_usage"] = "logged"
            elif action == "log_only":
                log.info("[INFO] trạm %s: %s", alert["station_id"], alert["message"])
        if channels or "log_only" not in alert["actions"]:
            results.update(self.notifier.notify(alert, channels))
        if "trigger_llm_report" in alert["actions"] and self.reporter is not None:
            try:
                self.reporter(alert_id)
                results["llm_report"] = "done"
            except Exception as e:                                # noqa: BLE001
                log.exception("Không sinh được báo cáo cho alert %s", alert_id)
                results["llm_report"] = f"error:{type(e).__name__}"
        self.storage.set_alert_notify(alert_id, results)
        return results
