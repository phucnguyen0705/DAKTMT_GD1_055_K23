"""Thiết bị giả lập: sinh số liệu cảm biến theo kịch bản và gửi tới API như một node thật.

Kịch bản: normal | pollution (ô nhiễm hữu cơ: DO giảm, NH4/CODMn/độ đục tăng) | sensor_fault (pH nhảy vô lý)
          | drift (TDS trôi dần).  Sinh dữ liệu là hàm thuần (generate) nên test được không cần mạng.

  python -m devices.simulator --station S1 --device sim-1 --scenario pollution --interval 2 --count 30
"""
from __future__ import annotations

import argparse
import math
import random
import time
from datetime import datetime, timedelta, timezone
from typing import Callable, Dict

SCENARIOS = ("normal", "pollution", "sensor_fault", "drift")


def generate(scenario: str, k: int, rng: random.Random, n_total: int = 60) -> Dict[str, float]:
    """Mẫu thứ k (0-based) của kịch bản."""
    if scenario not in SCENARIOS:
        raise ValueError(f"kịch bản phải thuộc {SCENARIOS}")
    day = math.sin(2 * math.pi * k / 24)
    v = {"ph": 7.3 + 0.1 * day + rng.gauss(0, 0.04), "do_mgL": 7.0 - 0.4 * day + rng.gauss(0, 0.1),
         "temperature_c": 27 + 1.5 * day + rng.gauss(0, 0.1), "turbidity_ntu": 8 + rng.gauss(0, 0.8),
         "tds_ppm": 300 + rng.gauss(0, 5), "nh4n_mgL": 0.3 + rng.gauss(0, 0.03), "codmn_mgL": 3.0 + rng.gauss(0, 0.2)}
    if scenario == "pollution":
        p = max(0.0, min(1.0, (k - n_total * 0.4) / (n_total * 0.2)))     # leo thang giữa chuỗi
        p *= 1.0 if k < n_total * 0.8 else max(0.0, 1 - (k - n_total * 0.8) / (n_total * 0.2))
        v["do_mgL"] -= 5.0 * p; v["nh4n_mgL"] += 2.5 * p; v["codmn_mgL"] += 8 * p; v["turbidity_ntu"] += 40 * p
    elif scenario == "sensor_fault" and k % 7 == 6:
        v["ph"] = 15.2                                                    # ngoài khoảng hợp lý
    elif scenario == "drift":
        v["tds_ppm"] += 8 * k
    return {a: round(b, 3) for a, b in v.items()}


def run(post: Callable[[dict], dict], station: str, device: str | None, scenario: str, count: int, interval: float,
        seed: int = 0, start: datetime | None = None, step: timedelta = timedelta(hours=1), realtime: bool = False,
        on_result: Callable[[int, dict, dict], None] | None = None) -> int:
    """post(payload)->response dict. Trả về số mẫu gửi thành công. Lệnh từ máy chủ được áp dụng (set_interval)."""
    rng = random.Random(seed)
    t = start or datetime.now(timezone.utc)
    ok = 0
    for k in range(count):
        payload = {"station_id": station, "device_id": device, "ts": (datetime.now(timezone.utc) if realtime else t).strftime("%Y-%m-%dT%H:%M:%SZ"),
                   "values": generate(scenario, k, rng, count), "meta": {"fw": "sim-1.0", "rssi": -60, "battery": 100.0}}
        try:
            res = post(payload)
            ok += 1
            for cmd in res.get("commands", []):
                if cmd["command"] == "set_interval":
                    interval = float(cmd["params"].get("seconds", interval))
            if on_result:
                on_result(k, payload, res)
        except Exception as e:                                    # noqa: BLE001  - thiết bị thật cũng không dừng khi lỗi mạng
            print(f"[sim] lỗi gửi mẫu {k}: {type(e).__name__}")
        t += step
        if interval > 0:
            time.sleep(interval)
    return ok


def main() -> None:
    import httpx

    from config.settings import get_settings
    s = get_settings()
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--api", default=s.API_URL)
    ap.add_argument("--station", required=True)
    ap.add_argument("--device", default=None)
    ap.add_argument("--key", default="", help="API key của thiết bị (hoặc INGEST_SERVICE_KEY)")
    ap.add_argument("--scenario", choices=SCENARIOS, default="normal")
    ap.add_argument("--count", type=int, default=60)
    ap.add_argument("--interval", type=float, default=1.0, help="giây giữa hai lần gửi (thật)")
    ap.add_argument("--step-minutes", type=int, default=60, help="khoảng thời gian MÔ PHỎNG giữa hai mẫu")
    ap.add_argument("--realtime", action="store_true", help="dùng giờ hiện tại thay vì thời gian mô phỏng")
    a = ap.parse_args()
    headers = {"X-API-Key": a.key} if a.key else {}
    with httpx.Client(base_url=a.api, headers=headers, timeout=10) as c:
        def post(p):
            r = c.post("/api/ingest", json=p)
            r.raise_for_status()
            return r.json()
        start = datetime.now(timezone.utc) - timedelta(minutes=a.step_minutes * a.count)
        n = run(post, a.station, a.device, a.scenario, a.count, a.interval, start=start,
                step=timedelta(minutes=a.step_minutes), realtime=a.realtime,
                on_result=lambda k, p, r: print(f"[{k:03d}] WQI={r['wqi']} {r['severity']} {r['matched_rules']}"))
    print(f"đã gửi {n}/{a.count}")


if __name__ == "__main__":
    main()
