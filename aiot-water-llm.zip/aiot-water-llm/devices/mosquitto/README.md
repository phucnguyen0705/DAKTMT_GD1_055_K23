Dev: `docker compose up mosquitto`. Production: đặt `allow_anonymous false`, tạo user bằng `mosquitto_passwd`,
bật TLS (port 8883), và dùng ACL để mỗi thiết bị chỉ publish được vào topic của nó.
