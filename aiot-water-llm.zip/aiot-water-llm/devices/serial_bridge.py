"""Cầu nối cổng USB/Serial -> REST (dùng khi nối ESP32/Arduino bằng cáp, chưa có WiFi/MQTT).

Thiết bị in mỗi dòng một JSON: {"ph":7.2,"do":6.5,"tds":300,...}. Tên trường được API chuẩn hóa qua aliases.
  python -m devices.serial_bridge --port /dev/ttyUSB0 --station S1 --key dk_xxx
"""
from __future__ import annotations

import argparse
import json


def parse_line(line: str) -> dict | None:
    line = line.strip()
    if not line.startswith("{"):
        return None
    try:
        obj = json.loads(line)
    except ValueError:
        return None
    return obj if isinstance(obj, dict) and obj else None


def main() -> None:                                                        # pragma: no cover
    import httpx
    import serial                                                          # pip install pyserial

    from config.settings import get_settings
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", required=True)
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--station", default=None)
    ap.add_argument("--key", default="")
    a = ap.parse_args()
    s = get_settings()
    with serial.Serial(a.port, a.baud, timeout=5) as ser, httpx.Client(
            base_url=s.API_URL, headers={"X-API-Key": a.key} if a.key else {}, timeout=10) as c:
        while True:
            vals = parse_line(ser.readline().decode("utf-8", "ignore"))
            if vals:
                r = c.post("/api/ingest", json={"station_id": a.station, "values": vals})
                print(r.status_code, r.text[:120])


if __name__ == "__main__":
    main()
