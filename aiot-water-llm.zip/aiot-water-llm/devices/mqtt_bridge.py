"""Cầu nối MQTT -> REST: lắng nghe topic của thiết bị rồi POST /api/ingest bằng INGEST_SERVICE_KEY.

Topic: {root}/{station_id}/{device_id}/telemetry   payload JSON: {"ts":..., "values": {...}, "meta": {...}}
Bridge không chứa logic nghiệp vụ; mọi kiểm tra/ghi/cảnh báo nằm ở API (một đường duy nhất).
Lệnh cho thiết bị: API trả về trong phản hồi ingest; bridge publish lên {root}/{station}/{device}/cmd.
"""
from __future__ import annotations

import json
import logging
import re
from typing import Optional, Tuple

import httpx

from config.settings import Settings, get_settings

log = logging.getLogger("mqtt_bridge")
SEG = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}$")


def parse_topic(topic: str, root: str) -> Optional[Tuple[str, str]]:
    prefix = root.rstrip("/") + "/"
    if not topic.startswith(prefix):
        return None
    parts = topic[len(prefix):].split("/")
    if len(parts) != 3 or parts[2] != "telemetry" or not all(SEG.match(p) for p in parts[:2]):
        return None
    return parts[0], parts[1]


def build_payload(topic: str, payload: bytes, root: str) -> Optional[dict]:
    ids = parse_topic(topic, root)
    if not ids:
        return None
    try:
        body = json.loads(payload)
    except ValueError:
        return None
    if not isinstance(body, dict) or not isinstance(body.get("values"), dict):
        return None
    return {"station_id": ids[0], "device_id": ids[1], "ts": body.get("ts"), "values": body["values"],
            "meta": body.get("meta") if isinstance(body.get("meta"), dict) else {}}


def main() -> None:                                                        # pragma: no cover - cần broker thật
    import paho.mqtt.client as mqtt                                        # pip install paho-mqtt
    s: Settings = get_settings()
    logging.basicConfig(level=logging.INFO)
    http = httpx.Client(base_url=s.API_URL, headers={"X-API-Key": s.INGEST_SERVICE_KEY}, timeout=10)

    def on_message(client, _u, msg):
        item = build_payload(msg.topic, msg.payload, s.MQTT_TOPIC_ROOT)
        if item is None:
            log.warning("bỏ qua tin không hợp lệ: %s", msg.topic)
            return
        try:
            r = http.post("/api/ingest", json=item)
            r.raise_for_status()
            for cmd in r.json().get("commands", []):
                client.publish(f"{s.MQTT_TOPIC_ROOT}/{item['station_id']}/{item['device_id']}/cmd", json.dumps(cmd))
        except httpx.HTTPError as e:
            log.error("ingest lỗi: %s", type(e).__name__)

    c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    if s.MQTT_USERNAME:
        c.username_pw_set(s.MQTT_USERNAME, s.MQTT_PASSWORD)
    c.on_message = on_message
    c.on_connect = lambda cl, *_: cl.subscribe(f"{s.MQTT_TOPIC_ROOT}/+/+/telemetry", qos=1)
    c.connect(s.MQTT_BROKER_HOST, s.MQTT_BROKER_PORT)
    c.loop_forever()


if __name__ == "__main__":
    main()
