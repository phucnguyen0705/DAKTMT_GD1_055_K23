#pragma once
#define WIFI_SSID "your-wifi"
#define WIFI_PASS "your-pass"
#define API_URL   "http://192.168.1.10:8000"   // máy chạy FastAPI
#define DEVICE_ID "esp32-01"
#define DEVICE_KEY "dk_xxx"                     // lấy từ POST /api/devices (hiển thị một lần)
#define FW_VERSION "0.1.0"
#define SEND_INTERVAL_SEC 60
#define PIN_PH 34
#define PIN_TURBIDITY 35
#define PIN_TDS 32
#define PIN_DS18B20 4
// Hệ số hiệu chuẩn MẪU - phải đo lại
#define PH_SLOPE (-5.70f)
#define PH_OFFSET 21.34f
#define TURB_A (-1120.4f)
#define TURB_B 5742.3f
#define TURB_C (-4352.9f)
