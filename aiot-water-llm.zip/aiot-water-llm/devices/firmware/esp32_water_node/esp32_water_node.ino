// ESP32 water node - gửi telemetry qua HTTP (mặc định) hoặc MQTT.
// CHƯA ĐƯỢC KIỂM THỬ TRÊN PHẦN CỨNG: hệ số hiệu chuẩn bên dưới chỉ là GIÁ TRỊ MẪU, phải hiệu chuẩn lại
// bằng dung dịch chuẩn (pH 4.0/7.0/10.0, TDS 1413 uS/cm) trước khi dùng số liệu.
// Thư viện: ArduinoJson, OneWire, DallasTemperature (và PubSubClient nếu dùng MQTT).
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include "config.h"   // sao chép config.example.h -> config.h và điền thông tin

OneWire oneWire(PIN_DS18B20);
DallasTemperature ds18(&oneWire);
unsigned long intervalMs = SEND_INTERVAL_SEC * 1000UL;

float readAdcVolts(int pin, int samples = 20) {
  long sum = 0;
  for (int i = 0; i < samples; i++) { sum += analogRead(pin); delay(5); }
  return (sum / (float)samples) * 3.3f / 4095.0f;
}

float readPH() { return PH_SLOPE * readAdcVolts(PIN_PH) + PH_OFFSET; }          // hiệu chuẩn 2 điểm
float readTurbidityNTU(float v) { return max(0.0f, TURB_A * v * v + TURB_B * v + TURB_C); }
float readTDS(float v, float tempC) {
  float comp = v / (1.0f + 0.02f * (tempC - 25.0f));                           // bù nhiệt độ
  return (133.42f * comp * comp * comp - 255.86f * comp * comp + 857.39f * comp) * 0.5f;
}

void connectWifi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  for (int i = 0; i < 40 && WiFi.status() != WL_CONNECTED; i++) delay(500);
}

void applyCommands(JsonArray cmds) {
  for (JsonObject c : cmds) {
    const char* name = c["command"];
    if (!strcmp(name, "set_interval")) {
      long sec = c["params"]["seconds"] | 0;
      if (sec >= 10 && sec <= 86400) intervalMs = sec * 1000UL;               // kiểm tra biên trước khi áp dụng
    } else if (!strcmp(name, "reboot")) {
      delay(200); ESP.restart();
    }                                                                           // "ping": không làm gì, chỉ cần có phản hồi
  }
}

void sendTelemetry() {
  ds18.requestTemperatures();
  float t = ds18.getTempCByIndex(0);                                            // -127 = lỗi cảm biến; server gắn cờ
  float turbV = readAdcVolts(PIN_TURBIDITY), tdsV = readAdcVolts(PIN_TDS);

  StaticJsonDocument<512> doc;
  doc["device_id"] = DEVICE_ID;
  JsonObject v = doc.createNestedObject("values");
  v["ph"] = readPH();
  v["temperature_c"] = t;
  v["turbidity_ntu"] = readTurbidityNTU(turbV);
  v["tds_ppm"] = readTDS(tdsV, t);
  JsonObject m = doc.createNestedObject("meta");
  m["fw"] = FW_VERSION;
  m["rssi"] = WiFi.RSSI();
  // Không gửi "ts": server dùng giờ nhận (ESP32 không có RTC đáng tin). Nếu có NTP thì thêm doc["ts"] = epoch.

  String body; serializeJson(doc, body);
  HTTPClient http;
  http.begin(String(API_URL) + "/api/ingest");
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-API-Key", DEVICE_KEY);
  int code = http.POST(body);
  if (code == 200) {
    StaticJsonDocument<1024> resp;
    if (!deserializeJson(resp, http.getString())) applyCommands(resp["commands"].as<JsonArray>());
  }
  http.end();
}

void setup() { Serial.begin(115200); ds18.begin(); connectWifi(); }

void loop() {
  if (WiFi.status() != WL_CONNECTED) connectWifi();
  if (WiFi.status() == WL_CONNECTED) sendTelemetry();
  delay(intervalMs);
}
