# ESP32 water node
Cảm biến: pH (analog), độ đục (analog), TDS (analog), DS18B20 (nhiệt độ). **Không đo được DO, NH4-N, CODMn** –
đây là lý do WQI trong hệ thống được tính trên các thông số hiện có (xem docs/device_protocol.md).
1. `POST /api/devices` (header X-Admin-Key) để lấy `api_key`. 2. Sao chép `config.example.h` thành `config.h` và điền.
3. Hiệu chuẩn pH/TDS/độ đục. 4. Nạp bằng Arduino IDE hoặc PlatformIO. *Chưa kiểm thử trên phần cứng thật.*
