"""
Gửi cảnh báo qua Telegram / Email (cấu hình trong .env). Luôn ghi log, kể cả khi chưa cấu hình kênh nào.

Kết quả mỗi kênh là chuỗi trạng thái: 'sent' | 'skipped:<lý do>' | 'error:<thông báo>', được lưu cùng alert
để UI hiển thị được cảnh báo đã tới đâu.
"""
from __future__ import annotations

import logging
import smtplib
from email.mime.text import MIMEText
from typing import Dict

import requests

from config.settings import Settings

log = logging.getLogger(__name__)

SEVERITY_LABEL = {"info": "THÔNG TIN", "warning": "CẢNH BÁO", "critical": "KHẨN CẤP"}


def format_alert_text(alert: dict) -> str:
    wqi = alert.get("wqi")
    wqi_txt = f"WQI={wqi:g}. " if isinstance(wqi, (int, float)) else ""
    return (f"[{SEVERITY_LABEL.get(alert['severity'], alert['severity'].upper())}] Trạm {alert['station_id']}: "
            f"{alert['message']} {wqi_txt}(luật: {alert['rule_id']}, lúc {alert['ts']})")


class Notifier:
    def __init__(self, settings: Settings):
        self.s = settings

    def send_telegram(self, text: str) -> str:
        if not self.s.TELEGRAM_BOT_TOKEN or not self.s.TELEGRAM_CHAT_ID:
            return "skipped:chưa cấu hình Telegram"
        try:
            r = requests.post(f"https://api.telegram.org/bot{self.s.TELEGRAM_BOT_TOKEN}/sendMessage",
                              data={"chat_id": self.s.TELEGRAM_CHAT_ID, "text": text}, timeout=10)
            r.raise_for_status()
            return "sent"
        except Exception as e:                                  # noqa: BLE001
            log.warning("Lỗi gửi Telegram: %s", type(e).__name__)   # không log nội dung lỗi: URL chứa token
            return f"error:{type(e).__name__}"

    def send_email(self, subject: str, text: str) -> str:
        if not (self.s.SMTP_HOST and self.s.SMTP_USERNAME and self.s.SMTP_PASSWORD and self.s.ALERT_EMAIL_TO):
            return "skipped:chưa cấu hình SMTP"
        msg = MIMEText(text, _charset="utf-8")
        msg["Subject"], msg["From"], msg["To"] = subject, self.s.SMTP_USERNAME, self.s.ALERT_EMAIL_TO
        try:
            with smtplib.SMTP(self.s.SMTP_HOST, self.s.SMTP_PORT, timeout=15) as server:
                server.starttls()
                server.login(self.s.SMTP_USERNAME, self.s.SMTP_PASSWORD)
                server.send_message(msg)
            return "sent"
        except Exception as e:                                  # noqa: BLE001
            log.warning("Lỗi gửi email: %s", type(e).__name__)
            return f"error:{type(e).__name__}"

    def notify(self, alert: dict, channels: list[str]) -> Dict[str, str]:
        text = format_alert_text(alert)
        log.warning("ALERT %s", text)
        out: Dict[str, str] = {"log": "sent"}
        if "telegram" in channels:
            out["telegram"] = self.send_telegram(text)
        if "email" in channels:
            out["email"] = self.send_email(f"[{alert['severity'].upper()}] Cảnh báo chất lượng nước", text)
        return out
