"""
Lớp lưu trữ SQLite (thay cho store.py trong RAM của bản gốc).

Bảng: stations, readings, devices, commands, alerts, chat_log.
- Thời gian lưu dạng ISO-8601 UTC 'YYYY-MM-DDTHH:MM:SSZ' (sắp xếp được theo chuỗi).
- readings có UNIQUE(station_id, ts) nên gửi lại cùng một mẫu (thiết bị retry) là idempotent.
- Mỗi lần truy cập mở một kết nối riêng (an toàn với threadpool của FastAPI); bật WAL.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional

import pandas as pd

SCHEMA = """
CREATE TABLE IF NOT EXISTS stations(
  station_id TEXT PRIMARY KEY, name TEXT, lat REAL, lon REAL, source TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS readings(
  id INTEGER PRIMARY KEY AUTOINCREMENT, station_id TEXT NOT NULL, device_id TEXT, ts TEXT NOT NULL,
  values_json TEXT NOT NULL, flags_json TEXT NOT NULL DEFAULT '{}', wqi REAL, wqi_class TEXT, source TEXT,
  UNIQUE(station_id, ts));
CREATE INDEX IF NOT EXISTS idx_readings_station_ts ON readings(station_id, ts);
CREATE TABLE IF NOT EXISTS devices(
  device_id TEXT PRIMARY KEY, station_id TEXT NOT NULL, name TEXT, key_hash TEXT NOT NULL, protocol TEXT,
  fw_version TEXT, last_seen TEXT, last_rssi INTEGER, battery_pct REAL, created_at TEXT NOT NULL,
  meta_json TEXT NOT NULL DEFAULT '{}');
CREATE TABLE IF NOT EXISTS commands(
  id INTEGER PRIMARY KEY AUTOINCREMENT, device_id TEXT NOT NULL, command TEXT NOT NULL,
  params_json TEXT NOT NULL DEFAULT '{}', status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL, delivered_at TEXT);
CREATE TABLE IF NOT EXISTS alerts(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, station_id TEXT NOT NULL, rule_id TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'water_quality', severity TEXT NOT NULL, message TEXT NOT NULL, wqi REAL,
  status TEXT NOT NULL DEFAULT 'open', actions_json TEXT NOT NULL DEFAULT '[]',
  notify_json TEXT NOT NULL DEFAULT '{}', report_json TEXT, acked_at TEXT);
CREATE INDEX IF NOT EXISTS idx_alerts_station ON alerts(station_id, status);
CREATE TABLE IF NOT EXISTS chat_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, question TEXT NOT NULL, station_id TEXT,
  intent TEXT, router_source TEXT, answer TEXT, grounded INTEGER, fallback_used INTEGER,
  latency_ms REAL, tokens_in INTEGER, tokens_out INTEGER, detail_json TEXT);
"""


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def to_iso(value: Any) -> str:
    """Chuẩn hóa mọi dạng thời gian (datetime, ISO, epoch s/ms) về 'YYYY-MM-DDTHH:MM:SSZ' (UTC)."""
    if isinstance(value, (int, float)):
        seconds = value / 1000.0 if value > 1e11 else float(value)
        dt = datetime.fromtimestamp(seconds, tz=timezone.utc)
    elif isinstance(value, datetime):
        dt = value
    elif isinstance(value, pd.Timestamp):
        dt = value.to_pydatetime()
    else:
        text = str(value).strip().replace("Z", "+00:00")
        dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_iso(text: str) -> datetime:
    return datetime.strptime(text, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)


def hash_key(key: str) -> str:
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


def _row(r: sqlite3.Row | None) -> Optional[Dict[str, Any]]:
    return dict(r) if r is not None else None


class Storage:
    def __init__(self, db_path: str | Path):
        self.db_path = str(db_path)
        if self.db_path != ":memory:":
            Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as c:
            c.executescript(SCHEMA)

    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA busy_timeout=30000")
            yield conn
            conn.commit()
        finally:
            conn.close()

    # ------------------------------------------------------------------ stations
    def upsert_station(self, station_id: str, name: str | None = None, lat: float | None = None,
                       lon: float | None = None, source: str | None = None) -> None:
        with self._conn() as c:
            c.execute(
                """INSERT INTO stations(station_id, name, lat, lon, source, created_at) VALUES(?,?,?,?,?,?)
                   ON CONFLICT(station_id) DO UPDATE SET
                     name=COALESCE(excluded.name, name), lat=COALESCE(excluded.lat, lat),
                     lon=COALESCE(excluded.lon, lon), source=COALESCE(excluded.source, source)""",
                (station_id, name or station_id, lat, lon, source, to_iso(utcnow())),
            )

    def upsert_stations_bulk(self, rows: Iterable[tuple]) -> None:
        """rows: (station_id, name, lat, lon, source)"""
        now = to_iso(utcnow())
        with self._conn() as c:
            c.executemany(
                """INSERT INTO stations(station_id, name, lat, lon, source, created_at) VALUES(?,?,?,?,?,?)
                   ON CONFLICT(station_id) DO UPDATE SET lat=excluded.lat, lon=excluded.lon, source=excluded.source""",
                [(a, b, c_, d, e, now) for a, b, c_, d, e in rows],
            )

    def list_stations(self, source: str | None = None) -> List[Dict[str, Any]]:
        q = """SELECT s.*, (SELECT MAX(ts) FROM readings r WHERE r.station_id=s.station_id) AS last_ts,
                      (SELECT COUNT(*) FROM readings r WHERE r.station_id=s.station_id) AS n_readings
               FROM stations s"""
        args: tuple = ()
        if source:
            q += " WHERE s.source=?"
            args = (source,)
        q += " ORDER BY last_ts DESC, s.station_id"
        with self._conn() as c:
            return [dict(r) for r in c.execute(q, args)]

    def get_station(self, station_id: str) -> Optional[Dict[str, Any]]:
        with self._conn() as c:
            return _row(c.execute("SELECT * FROM stations WHERE station_id=?", (station_id,)).fetchone())

    def station_ids(self) -> List[str]:
        with self._conn() as c:
            return [r[0] for r in c.execute("SELECT station_id FROM stations")]

    # ------------------------------------------------------------------ readings
    def add_reading(self, station_id: str, ts: str, values: Dict[str, Any], flags: Dict[str, str],
                    wqi: float | None, wqi_class: str | None, device_id: str | None = None,
                    source: str | None = None) -> tuple[int, bool]:
        """Trả về (id, is_new). Cùng (station_id, ts) -> không ghi lại, is_new=False."""
        with self._conn() as c:
            cur = c.execute(
                """INSERT OR IGNORE INTO readings(station_id, device_id, ts, values_json, flags_json, wqi, wqi_class, source)
                   VALUES(?,?,?,?,?,?,?,?)""",
                (station_id, device_id, ts, json.dumps(values), json.dumps(flags), wqi, wqi_class, source),
            )
            if cur.rowcount == 1:
                return int(cur.lastrowid), True
            row = c.execute("SELECT id FROM readings WHERE station_id=? AND ts=?", (station_id, ts)).fetchone()
            return int(row[0]), False

    def add_readings_bulk(self, rows: Iterable[tuple]) -> int:
        """rows: (station_id, device_id, ts, values_json, flags_json, wqi, wqi_class, source)"""
        with self._conn() as c:
            cur = c.executemany(
                """INSERT OR IGNORE INTO readings(station_id, device_id, ts, values_json, flags_json, wqi, wqi_class, source)
                   VALUES(?,?,?,?,?,?,?,?)""", list(rows))
            return cur.rowcount

    @staticmethod
    def _decode(r: sqlite3.Row) -> Dict[str, Any]:
        d = dict(r)
        d["values"] = json.loads(d.pop("values_json"))
        d["flags"] = json.loads(d.pop("flags_json"))
        return d

    def latest_reading(self, station_id: str) -> Optional[Dict[str, Any]]:
        with self._conn() as c:
            r = c.execute("SELECT * FROM readings WHERE station_id=? ORDER BY ts DESC LIMIT 1", (station_id,)).fetchone()
        return self._decode(r) if r else None

    def get_readings(self, station_id: str, since: str | None = None, until: str | None = None,
                     limit: int | None = None, newest: bool = False) -> List[Dict[str, Any]]:
        """Trả về danh sách theo thời gian TĂNG dần. limit + newest=True -> lấy `limit` mẫu mới nhất."""
        q, args = "SELECT * FROM readings WHERE station_id=?", [station_id]
        if since:
            q += " AND ts>=?"
            args.append(since)
        if until:
            q += " AND ts<=?"
            args.append(until)
        order = "DESC" if newest else "ASC"
        q += f" ORDER BY ts {order}"
        if limit:
            q += " LIMIT ?"
            args.append(int(limit))
        with self._conn() as c:
            rows = [self._decode(r) for r in c.execute(q, args)]
        if newest:
            rows.reverse()
        return rows

    def window_since(self, station_id: str, hours: float) -> Optional[str]:
        """Mốc 'since' = mẫu mới nhất của trạm trừ `hours` (không dùng giờ hệ thống, để dữ liệu lịch sử vẫn có cửa sổ)."""
        last = self.latest_reading(station_id)
        if not last:
            return None
        return to_iso(parse_iso(last["ts"]) - timedelta(hours=hours))

    def readings_df(self, station_id: str, hours: float | None = None, limit: int | None = None) -> pd.DataFrame:
        since = self.window_since(station_id, hours) if hours else None
        rows = self.get_readings(station_id, since=since, limit=limit, newest=bool(limit and not since))
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame([{"ts": pd.Timestamp(r["ts"]), "wqi": r["wqi"], "wqi_class": r["wqi_class"], **r["values"]} for r in rows])
        return df

    def all_wqi_series(self, station_ids: Iterable[str] | None = None, source: str | None = None) -> pd.DataFrame:
        """Cột: station_id, ts, wqi (bỏ mẫu không có WQI) - dùng để huấn luyện mô hình dự báo."""
        q = "SELECT station_id, ts, wqi FROM readings WHERE wqi IS NOT NULL"
        args: list = []
        if source:
            q += " AND source=?"
            args.append(source)
        if station_ids:
            ids = list(station_ids)
            q += f" AND station_id IN ({','.join('?' * len(ids))})"
            args += ids
        q += " ORDER BY station_id, ts"
        with self._conn() as c:
            df = pd.DataFrame([dict(r) for r in c.execute(q, args)])
        if not df.empty:
            df["ts"] = pd.to_datetime(df["ts"])
        return df

    def iter_readings(self, batch: int = 5000) -> Iterator[List[Dict[str, Any]]]:
        last_id = 0
        while True:
            with self._conn() as c:
                rows = [self._decode(r) for r in c.execute(
                    "SELECT * FROM readings WHERE id>? ORDER BY id LIMIT ?", (last_id, batch))]
            if not rows:
                return
            last_id = rows[-1]["id"]
            yield rows

    def update_reading_wqi(self, updates: Iterable[tuple]) -> None:
        """updates: (wqi, wqi_class, id)"""
        with self._conn() as c:
            c.executemany("UPDATE readings SET wqi=?, wqi_class=? WHERE id=?", list(updates))

    def count_readings(self, station_id: str | None = None) -> int:
        with self._conn() as c:
            if station_id:
                return int(c.execute("SELECT COUNT(*) FROM readings WHERE station_id=?", (station_id,)).fetchone()[0])
            return int(c.execute("SELECT COUNT(*) FROM readings").fetchone()[0])

    # ------------------------------------------------------------------ devices
    def create_device(self, device_id: str, station_id: str, key: str, name: str | None = None,
                      protocol: str = "http", meta: dict | None = None) -> Dict[str, Any]:
        with self._conn() as c:
            c.execute(
                "INSERT INTO devices(device_id, station_id, name, key_hash, protocol, created_at, meta_json) VALUES(?,?,?,?,?,?,?)",
                (device_id, station_id, name or device_id, hash_key(key), protocol, to_iso(utcnow()), json.dumps(meta or {})),
            )
        self.upsert_station(station_id, source="device")
        return self.get_device(device_id)  # type: ignore[return-value]

    def get_device(self, device_id: str) -> Optional[Dict[str, Any]]:
        with self._conn() as c:
            return _row(c.execute("SELECT * FROM devices WHERE device_id=?", (device_id,)).fetchone())

    def get_device_by_key(self, key: str) -> Optional[Dict[str, Any]]:
        with self._conn() as c:
            return _row(c.execute("SELECT * FROM devices WHERE key_hash=?", (hash_key(key),)).fetchone())

    def list_devices(self) -> List[Dict[str, Any]]:
        with self._conn() as c:
            return [dict(r) for r in c.execute("SELECT * FROM devices ORDER BY device_id")]

    def delete_device(self, device_id: str) -> bool:
        with self._conn() as c:
            cur = c.execute("DELETE FROM devices WHERE device_id=?", (device_id,))
            c.execute("DELETE FROM commands WHERE device_id=?", (device_id,))
            return cur.rowcount > 0

    def touch_device(self, device_id: str, ts: str, fw: str | None = None, rssi: int | None = None,
                     battery: float | None = None) -> None:
        with self._conn() as c:
            c.execute(
                """UPDATE devices SET last_seen=?, fw_version=COALESCE(?, fw_version),
                   last_rssi=COALESCE(?, last_rssi), battery_pct=COALESCE(?, battery_pct) WHERE device_id=?""",
                (ts, fw, rssi, battery, device_id),
            )

    # ------------------------------------------------------------------ commands
    def add_command(self, device_id: str, command: str, params: dict | None = None) -> int:
        with self._conn() as c:
            cur = c.execute("INSERT INTO commands(device_id, command, params_json, created_at) VALUES(?,?,?,?)",
                            (device_id, command, json.dumps(params or {}), to_iso(utcnow())))
            return int(cur.lastrowid)

    def pop_pending_commands(self, device_id: str) -> List[Dict[str, Any]]:
        with self._conn() as c:
            rows = [dict(r) for r in c.execute(
                "SELECT * FROM commands WHERE device_id=? AND status='pending' ORDER BY id", (device_id,))]
            if rows:
                c.executemany("UPDATE commands SET status='delivered', delivered_at=? WHERE id=?",
                              [(to_iso(utcnow()), r["id"]) for r in rows])
        return [{"id": r["id"], "command": r["command"], "params": json.loads(r["params_json"])} for r in rows]

    # ------------------------------------------------------------------ alerts
    def add_alert(self, station_id: str, rule_id: str, severity: str, message: str, wqi: float | None,
                  actions: list, kind: str = "water_quality", ts: str | None = None) -> int:
        with self._conn() as c:
            cur = c.execute(
                """INSERT INTO alerts(ts, station_id, rule_id, kind, severity, message, wqi, actions_json)
                   VALUES(?,?,?,?,?,?,?,?)""",
                (ts or to_iso(utcnow()), station_id, rule_id, kind, severity, message, wqi, json.dumps(actions)))
            return int(cur.lastrowid)

    @staticmethod
    def _decode_alert(r: sqlite3.Row) -> Dict[str, Any]:
        d = dict(r)
        d["actions"] = json.loads(d.pop("actions_json") or "[]")
        d["notify"] = json.loads(d.pop("notify_json") or "{}")
        rep = d.pop("report_json")
        d["report"] = json.loads(rep) if rep else None
        return d

    def get_alert(self, alert_id: int) -> Optional[Dict[str, Any]]:
        with self._conn() as c:
            r = c.execute("SELECT * FROM alerts WHERE id=?", (alert_id,)).fetchone()
        return self._decode_alert(r) if r else None

    def list_alerts(self, station_id: str | None = None, status: str | None = None,
                    severity: str | None = None, limit: int = 100) -> List[Dict[str, Any]]:
        q, args = "SELECT * FROM alerts WHERE 1=1", []
        for col, val in (("station_id", station_id), ("status", status), ("severity", severity)):
            if val:
                q += f" AND {col}=?"
                args.append(val)
        q += " ORDER BY ts DESC, id DESC LIMIT ?"
        args.append(int(limit))
        with self._conn() as c:
            return [self._decode_alert(r) for r in c.execute(q, args)]

    def last_alert(self, station_id: str, rule_id: str) -> Optional[Dict[str, Any]]:
        with self._conn() as c:
            r = c.execute("SELECT * FROM alerts WHERE station_id=? AND rule_id=? ORDER BY ts DESC, id DESC LIMIT 1",
                          (station_id, rule_id)).fetchone()
        return self._decode_alert(r) if r else None

    def ack_alert(self, alert_id: int) -> bool:
        with self._conn() as c:
            cur = c.execute("UPDATE alerts SET status='acknowledged', acked_at=? WHERE id=? AND status='open'",
                            (to_iso(utcnow()), alert_id))
            return cur.rowcount > 0

    def resolve_cleared_alerts(self, station_id: str, active_rule_ids: Iterable[str]) -> int:
        """Alert mở/đã ack mà luật không còn khớp ở mẫu mới nhất -> 'resolved'."""
        active = list(active_rule_ids)
        q = "UPDATE alerts SET status='resolved' WHERE station_id=? AND status IN ('open','acknowledged')"
        args: list = [station_id]
        if active:
            q += f" AND rule_id NOT IN ({','.join('?' * len(active))})"
            args += active
        with self._conn() as c:
            return c.execute(q, args).rowcount

    def resolve_rules(self, station_id: str, rule_ids: Iterable[str]) -> int:
        """Đóng (resolved) các alert đang mở/đã ack thuộc các luật đã được kiểm tra và không còn khớp."""
        ids = list(rule_ids)
        if not ids:
            return 0
        q = (f"UPDATE alerts SET status='resolved' WHERE station_id=? AND status IN ('open','acknowledged') "
             f"AND rule_id IN ({','.join('?' * len(ids))})")
        with self._conn() as c:
            return c.execute(q, [station_id, *ids]).rowcount

    def set_alert_notify(self, alert_id: int, notify: dict) -> None:
        with self._conn() as c:
            c.execute("UPDATE alerts SET notify_json=? WHERE id=?", (json.dumps(notify), alert_id))

    def set_alert_report(self, alert_id: int, report: dict) -> None:
        with self._conn() as c:
            c.execute("UPDATE alerts SET report_json=? WHERE id=?", (json.dumps(report, ensure_ascii=False), alert_id))

    # ------------------------------------------------------------------ chat log
    def add_chat_log(self, question: str, station_id: str | None, intent: str | None, router_source: str | None,
                     answer: str, grounded: bool, fallback_used: bool, latency_ms: float, tokens_in: int,
                     tokens_out: int, detail: dict) -> int:
        with self._conn() as c:
            cur = c.execute(
                """INSERT INTO chat_log(ts, question, station_id, intent, router_source, answer, grounded, fallback_used,
                   latency_ms, tokens_in, tokens_out, detail_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                (to_iso(utcnow()), question, station_id, intent, router_source, answer, int(grounded),
                 int(fallback_used), latency_ms, tokens_in, tokens_out, json.dumps(detail, ensure_ascii=False, default=str)))
            return int(cur.lastrowid)

    def list_chat_log(self, limit: int = 50) -> List[Dict[str, Any]]:
        with self._conn() as c:
            return [dict(r) for r in c.execute("SELECT * FROM chat_log ORDER BY id DESC LIMIT ?", (limit,))]
