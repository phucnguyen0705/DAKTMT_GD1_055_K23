# AIoT Water Quality + LLM nhỏ (Qwen2.5 1.5B / Ollama)

Hệ thống quan trắc chất lượng nước: thiết bị/mô phỏng → API → WQI + cảnh báo → chatbot & dashboard. LLM nhỏ chỉ **định tuyến câu hỏi
và diễn đạt**; số liệu, ngưỡng, cảnh báo, biểu đồ đều do mã xác định tạo ra và được kiểm tra lại (xem `docs/architecture.md`).

## Chạy nhanh (không cần Ollama, không cần phần cứng)
```bash
pip install -r requirements-dev.txt
cp .env.example .env
python -m scripts.seed_demo          # 3 trạm demo
make api                              # http://localhost:8000  (docs: /docs, web nhẹ: /)
make ui                               # http://localhost:8501  (terminal khác)
python -m devices.simulator --station SIM1 --scenario pollution --count 60 --interval 0.2
make test
```
Không có Ollama thì router chạy theo luật và câu trả lời dùng mẫu – vẫn đầy đủ chức năng.

## Bật LLM
`ollama pull qwen2.5:1.5b` rồi để `.env` như mặc định (`ROUTER_MODE=llm_with_fallback`, `COMPOSE_MODE=llm_with_check`). `GET /api/health` cho biết LLM đã kết nối chưa.

## Dữ liệu lịch sử & dự báo
```bash
python -m scripts.import_dataset --sources CNEMC   # cần data/processed/water_quality_wide.parquet
python -m scripts.train_forecaster                 # → models/wqi_forecaster.joblib (+ metrics so với persistence)
```
## Thiết bị
`POST /api/devices` (header `X-Admin-Key` nếu đã đặt) lấy khóa → nạp `devices/firmware/esp32_water_node` hoặc chạy `devices/mqtt_bridge.py`. Xem `docs/device_protocol.md`.

## Đánh giá & huấn luyện
`python -m evaluation.run_eval --router rules` (baseline) · `--router llm_with_fallback --compose llm_with_check` (cần Ollama). Fine-tune tùy chọn: `training/README.md`.

## Cần biết trước khi dùng cho đồ án
- **WQI là chỉ số minh họa** (`config/wqi.yaml`, `illustrative-0.2`); phải chọn và dẫn nguồn công thức chính thức rồi chạy `python -m scripts.recompute_wqi`.
- **Ngưỡng QCVN/GB chưa đối chiếu văn bản gốc** (`verified: false`); KB viết tay cần chuyên gia rà soát.
- **Chưa kiểm thử với thật**: Qwen/Ollama thật, firmware ESP32 và cảm biến, broker MQTT, Chroma, huấn luyện QLoRA trên GPU. Mọi thứ khác đã có test (`make test`).
- Cảm biến ESP32 mẫu không đo DO/NH4/CODMn; dự báo huấn luyện trên CNEMC không áp dụng trực tiếp cho dữ liệu thiết bị.
- Tài liệu: `docs/` (kiến trúc, use case, API, giao thức thiết bị, đánh giá, đối chiếu đề cương, migration).
