# Rubric chấm chất lượng câu trả lời (người chấm, thang 0–2)

| Tiêu chí | 0 | 1 | 2 |
|---|---|---|---|
| **Đúng (correct)** | Có số liệu/kết luận sai hoặc bịa | Đúng phần lớn, có chi tiết sai nhỏ | Mọi số liệu và kết luận đúng so với dữ liệu hệ thống |
| **Đủ (complete)** | Bỏ sót ý chính | Trả lời một phần | Trả lời đúng điều được hỏi, kèm thông tin cần thiết (đơn vị, thời điểm, trạm) |
| **Rõ (clear)** | Khó hiểu / lan man | Hiểu được nhưng rườm | Ngắn gọn, tiếng Việt tự nhiên |
| **Hữu ích (useful)** | Không giúp người vận hành hành động | Giúp một phần | Có thể hành động ngay (khuyến nghị cụ thể, có nêu giới hạn) |

Quy ước: câu hỏi ngoài phạm vi mà hệ thống từ chối lịch sự được 2 ở mọi tiêu chí.
Chấm độc lập bởi ≥ 2 người trên cùng tệp CSV (cột `human_*`), tính độ đồng thuận (Cohen's kappa) trước khi lấy trung bình.

## Các chỉ số tự động (evaluation/metrics.py)
- **Router accuracy** theo intent / trạm / thông số / chart.
- **Grounded rate**: tỉ lệ câu trả lời mà mọi con số đều có trong FACTS. **Fallback rate**: tỉ lệ phải dùng câu mẫu.
- **Tool success rate**: tool trả `ok`. **Refusal correct**: câu ngoài phạm vi bị từ chối đúng.
- **Latency** mean/p50/p95 (ms) tách router/tool/compose trong `/api/chat`; **tokens** và **cost** (nếu đặt `LLM_PRICE_PER_1K_TOKENS`).
Kiểm tra "grounded" chỉ bảo đảm SỐ có nguồn, không bảo đảm câu chữ đúng – vì vậy vẫn cần chấm tay.
