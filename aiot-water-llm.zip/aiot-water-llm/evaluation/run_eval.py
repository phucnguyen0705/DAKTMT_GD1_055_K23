"""Chạy bộ test qua pipeline thật trên dữ liệu demo xác định, xuất JSON + CSV (để chấm tay chất lượng).

  python -m evaluation.run_eval --router rules                       # baseline không cần LLM
  python -m evaluation.run_eval --router llm_with_fallback --compose llm_with_check   # cần Ollama + model
Kết quả: evaluation/results/<tên>.json và .csv (cột 'human_*' để điền theo evaluation/rubric.md).
"""
from __future__ import annotations

import argparse
import csv
import json
import tempfile
from pathlib import Path

from backend.app.context import AppContext
from config.settings import ROOT_DIR, Settings, get_settings
from evaluation.metrics import route_match, summarize
from scripts.seed_demo import seed_demo

TESTSET = ROOT_DIR / "evaluation" / "testset" / "testset_v1.jsonl"


def load_testset(path: Path = TESTSET) -> list[dict]:
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]


def evaluate(ctx: AppContext, items: list[dict]) -> dict:
    rows = []
    for it in items:
        r = ctx.orchestrator.answer(it["question"], it.get("station_id"), log=False)
        rows.append({"id": it["id"], "question": it["question"], "expect": it["expect"], "route": r["route"],
                     "intent_final": r["intent"], "match": route_match(it["expect"], r["route"], r["intent"]),
                     "answer": r["answer"], "grounded": r["grounded"], "fallback_used": r["fallback_used"],
                     "composer": r["composer"], "facts_ok": bool(r["facts"].get("ok", True)),
                     "latency_ms": r["latency_ms"]["total"], "tokens_in": r["usage"]["tokens_in"],
                     "tokens_out": r["usage"]["tokens_out"], "cost_usd": r["usage"]["cost_usd"],
                     "bad_numbers": r["bad_numbers"], "llm_error": r["llm_error"]})
    return {"summary": summarize(rows), "rows": rows}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--router", default="rules", choices=["rules", "llm", "llm_with_fallback"])
    ap.add_argument("--compose", default="template", choices=["template", "llm_with_check"])
    ap.add_argument("--grounding", default="strict", choices=["strict", "warn", "off"])
    ap.add_argument("--name", default=None)
    a = ap.parse_args()
    base = get_settings()
    tmp = tempfile.mkdtemp(prefix="eval_")
    s = Settings(**{**base.model_dump(), "DB_PATH": f"{tmp}/eval.db", "CHARTS_DIR": f"{tmp}/charts",
                    "MODELS_DIR": f"{tmp}/models", "ROUTER_MODE": a.router, "COMPOSE_MODE": a.compose,
                    "GROUNDING_MODE": a.grounding}, _env_file=None)
    ctx = AppContext.build(s)
    seed_demo(ctx)
    out = evaluate(ctx, load_testset())
    name = a.name or f"{a.router}__{a.compose}__{s.LLM_MODEL_NAME.replace(':', '-')}"
    d = Path(base.EVAL_RESULTS_DIR); d.mkdir(parents=True, exist_ok=True)
    out["config"] = {"router": a.router, "compose": a.compose, "grounding": a.grounding, "model": s.LLM_MODEL_NAME}
    (d / f"{name}.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    with open(d / f"{name}.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "question", "expected_intent", "got_intent", "answer", "grounded", "latency_ms",
                    "human_correct(0-2)", "human_complete(0-2)", "human_clear(0-2)", "human_useful(0-2)", "note"])
        for r in out["rows"]:
            w.writerow([r["id"], r["question"], r["expect"]["intent"], r["intent_final"], r["answer"], r["grounded"],
                        r["latency_ms"], "", "", "", "", ""])
    print(json.dumps(out["summary"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
