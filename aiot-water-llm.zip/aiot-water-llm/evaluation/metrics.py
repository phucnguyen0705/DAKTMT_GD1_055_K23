"""Các chỉ số đánh giá (hàm thuần, có test)."""
from __future__ import annotations

import statistics
from typing import Iterable


def percentile(xs: list[float], p: float) -> float:
    if not xs:
        return 0.0
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(round(p * (len(xs) - 1))))]


def route_match(expect: dict, route: dict, intent_final: str) -> dict:
    """So khớp router với kỳ vọng. Chỉ tính các trường có trong `expect`."""
    res = {"intent": intent_final == expect["intent"] or route.get("intent") == expect["intent"]}
    for k in ("station_id", "parameter", "chart"):
        if k in expect:
            res[k] = route.get(k) == expect[k]
    return res


def summarize(rows: list[dict]) -> dict:
    n = len(rows)
    if not n:
        return {"n": 0}
    lat = [r["latency_ms"] for r in rows]
    fields: dict[str, list[bool]] = {}
    for r in rows:
        for k, v in r["match"].items():
            fields.setdefault(k, []).append(bool(v))
    by_intent: dict[str, list[bool]] = {}
    for r in rows:
        by_intent.setdefault(r["expect"]["intent"], []).append(r["match"]["intent"])
    answerable = [r for r in rows if r["expect"]["intent"] != "out_of_scope" and r["facts_ok"]]
    return {
        "n": n,
        "router_accuracy": {k: round(sum(v) / len(v), 3) for k, v in fields.items()},
        "intent_accuracy_by_intent": {k: round(sum(v) / len(v), 3) for k, v in sorted(by_intent.items())},
        "grounded_rate": round(sum(r["grounded"] for r in rows) / n, 3),
        "fallback_rate": round(sum(r["fallback_used"] for r in rows) / n, 3),
        "tool_success_rate": round(sum(r["facts_ok"] for r in rows if r["expect"]["intent"] != "out_of_scope")
                                   / max(1, sum(1 for r in rows if r["expect"]["intent"] != "out_of_scope")), 3),
        "refusal_correct": round(sum(r["match"]["intent"] for r in rows if r["expect"]["intent"] == "out_of_scope")
                                 / max(1, sum(1 for r in rows if r["expect"]["intent"] == "out_of_scope")), 3),
        "latency_ms": {"mean": round(statistics.fmean(lat), 1), "p50": round(percentile(lat, .5), 1),
                       "p95": round(percentile(lat, .95), 1)},
        "tokens_in": sum(r["tokens_in"] for r in rows), "tokens_out": sum(r["tokens_out"] for r in rows),
        "cost_usd": round(sum(r["cost_usd"] for r in rows), 6),
        "n_answerable": len(answerable),
    }
