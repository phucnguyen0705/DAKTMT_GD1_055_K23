# Knowledge base

- `knowledge_base/docs/*.md`, front matter: `id, title, type (parameter|guide|standard|system), params, source, verified`. Chia đoạn theo `##`, id `docid#slug`.
- **Sinh tự động** từ cấu hình (không sửa tay): `std_qcvn08_2023.md`, `std_gb3838_2002.md`, `sys_wqi.md`, `sys_rules.md` (`python -m scripts.build_kb`; `--check` báo lệch – có trong test).
- **Viết tay**: `param_*.md` (ý nghĩa / nguyên nhân / khuyến nghị), `guide_actions.md`, `sys_faq.md`. Mọi tài liệu viết tay đang `verified: false` – cần chuyên gia rà soát trước khi bảo vệ.
- Truy xuất: BM25 trên đơn gram + song gram bỏ dấu (không cần tải mô hình; chạy tốt với tiếng Việt có/không dấu); thông số phát hiện trong câu hỏi được tăng điểm. Tùy chọn `RETRIEVER=chroma` (lai BM25 + e5) – chưa kiểm thử.
- Ngưỡng QCVN 08:2023/BTNMT dùng mức **A, B, C, D** (bản gốc framework ghi nhầm A1…). Cả hai tiêu chuẩn đang `verified: false` trong `standards.yaml`: cần đối chiếu văn bản gốc rồi đặt `verified: true`.
