# Giao diện prompt / tool

## Router (LLM, đầu ra ràng buộc schema – `orchestrator/schemas.py:router_json_schema`)
```json
{"intent": "status|trend|compare|forecast|explain|standard|alerts|knowledge|out_of_scope",
 "station_id": "string|null", "parameter": "khóa thông số|null", "hours": "int|null", "chart": "bool"}
```
Sau khi LLM trả lời, **luật** ghi đè trạm/thông số/thời gian nếu phát hiện được trong câu hỏi, và trạm không có trong DB bị loại.
Từ khóa "do": chỉ coi là DO khi viết hoa «DO» đứng riêng hoặc có «oxy» (tránh nhầm "biểu đồ", "do mưa").

## Tools (`orchestrator/tools.py`) – trả FACTS thuần dữ liệu
| intent | tool | FACTS chính |
|---|---|---|
| status | `get_status(station)` | wqi, wqi_class, driver, parameters[{value, flag, qcvn_class}], severity, matched_rules |
| trend | `get_trend(station, parameter, hours, chart)` | first/last/min/max/mean/change/direction, chart |
| compare | `compare(parameter, chart)` | best, worst, ranking |
| forecast | `forecast(station, steps, chart)` | forecast[{step, wqi, low, high}], method, step_hours |
| explain | `explain(station)` | status + knowledge[{id, text}] |
| standard | `standard_info(parameter)` | limits theo lớp, verified, warning |
| alerts | `alerts(station)` | alerts đang mở |
| knowledge | `knowledge(query, parameter)` | các đoạn KB |

## Compose
Prompt: `llm_engine/prompts/compose.py`. Quy tắc: chỉ dùng số trong FACTS, 2–5 câu, nói rõ khi thiếu dữ liệu.
`standard`, `alerts`, `out_of_scope` và mọi trường hợp tool lỗi **luôn dùng câu mẫu** (chính xác tuyệt đối).
Kiểm tra neo: mọi số trong câu trả lời phải khớp (sai khác làm tròn) một số trong FACTS hoặc đoạn KB; sai → câu mẫu (`GROUNDING_MODE=strict`).

## Chế độ vận hành
| Biến | Giá trị | Ý nghĩa |
|---|---|---|
| ROUTER_MODE | rules / llm / llm_with_fallback | baseline luật / chỉ LLM / LLM rồi luật |
| COMPOSE_MODE | template / llm_with_check | luôn mẫu / LLM có kiểm tra |
| GROUNDING_MODE | strict / warn / off | sai thì thay mẫu / chỉ ghi nhận / tắt |
