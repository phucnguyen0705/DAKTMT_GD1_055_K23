# Đối chiếu nhiệm vụ đồ án ↔ mã nguồn

| # | Nhiệm vụ | Nơi thực hiện | Trạng thái |
|---|---|---|---|
| 1 | Khảo sát LLM, RAG, tool calling, Agentic AI | viết trong luận văn; thiết kế router→tools→compose là minh họa «tool calling có ràng buộc» | cần viết |
| 2 | Mô hình dự báo WQI làm backend | `data_processing/wqi_calculator`, `forecasting/`, `scripts/train_forecaster` | có (WQI minh họa) |
| 3 | Knowledge base chất lượng nước | `knowledge_base/docs`, `config/standards.yaml`, `scripts/build_kb` | có, chờ rà soát |
| 4 | RAG pipeline | `llm_engine/rag/` | có (BM25; Chroma chưa test) |
| 5 | Tích hợp LLM với prediction API | `orchestrator/` + `backend/app/routers` | có |
| 6 | Thiết kế prompt, tool/API interface | `llm_engine/prompts`, `docs/tool_interface.md`, `docs/api_spec.md` | có |
| 7 | Cơ chế phân tích kết quả WQI | `WQIResult.driver/sub_indices`, `Tools.explain` | có |
| 8 | Cảnh báo & khuyến nghị tự động | `policy/`, `alerts/`, `llm_engine/report.py` | có |
| 9 | Đánh giá factuality/quality/latency/cost | `evaluation/`, `docs/evaluation_protocol.md` | công cụ có; **số liệu LLM thật chưa đo** |
| 10 | Giao diện chatbot/dashboard | `ui/`, `frontend/static` | có |
| — | Kết nối thiết bị | `devices/`, `backend/app/routers/devices.py`, `ingest.py` | HTTP/MQTT/Serial; firmware chưa thử phần cứng |

Đề cương → thư mục: use case (`docs/usecases.md`), kiến trúc LLM (`docs/architecture.md`), prompt/tool (`docs/tool_interface.md`), evaluation protocol (`docs/evaluation_protocol.md`).
