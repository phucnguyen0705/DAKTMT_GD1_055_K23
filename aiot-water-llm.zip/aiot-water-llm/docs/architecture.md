# Kiến trúc hệ thống

## 1. Sơ đồ chạy (runtime)
Mũi tên liền = gọi/đẩy dữ liệu theo chiều mũi tên. Mũi tên đứt = kết quả/phản hồi hoặc phụ thuộc cấu hình. Mọi thành phần phía trên API (UI, đánh giá, bridge) **chỉ nói chuyện với API**.

```mermaid
flowchart LR
  subgraph Edge[Thiết bị]
    ESP[ESP32 + cảm biến] -->|HTTP POST /api/ingest + X-API-Key| API
    ESP -. MQTT telemetry .-> MQ[(Mosquitto)]
    MQ --> BR[mqtt_bridge] -->|HTTP POST /api/ingest + service key| API
    SIM[simulator] -->|HTTP POST| API
    API -. commands trong phản hồi ingest .-> ESP
  end
  subgraph Clients[Giao diện / người dùng]
    ST[Streamlit UI] -->|REST| API
    WEB[Web nhẹ frontend/static] -->|REST| API
    EV[evaluation.run_eval] -->|cùng pipeline| ORCH
  end
  subgraph Backend[FastAPI]
    API[API gateway<br/>auth, validate] --> ING[IngestService]
    API --> ORCH[Orchestrator]
    ING --> DB[(SQLite)]
    ING --> POL[PolicyEngine rules.yaml]
    POL --> ALR[(alerts)]
    ALR -->|BackgroundTasks| DSP[Dispatcher] --> NOTI[Telegram / Email]
    DSP --> REP[Reporter] --> ORCH
    ORCH --> RT[Router: Qwen 1.5B + JSON schema<br/>fallback: luật]
    ORCH --> TOOLS[Tools: status, trend, compare,<br/>forecast, explain, standards, alerts, KB]
    TOOLS --> DB
    TOOLS --> RAG[BM25 / Chroma] --> KB[(knowledge_base/docs)]
    TOOLS --> FC[Forecaster] --> DB
    TOOLS --> CH[Chart renderer matplotlib]
    ORCH --> CMP[Compose: Qwen hoặc mẫu]
    CMP --> GR{Grounding check<br/>số có trong FACTS?}
    GR -. không khớp .-> TPL[Câu mẫu xác định]
  end
  RT --- OLL[Ollama]
  CMP --- OLL
```

## 2. Chuỗi chuẩn bị (offline)
`config/standards.yaml` → `scripts/build_kb.py` → `knowledge_base/docs/std_*.md, sys_*.md` (+ tài liệu viết tay) → chỉ mục RAG.
`scripts/import_dataset.py` → SQLite → `scripts/train_forecaster.py` → `models/wqi_forecaster.joblib`.
`training/make_dataset.py` → `training/train_qlora.py` → GGUF → Ollama (tùy chọn).

## 3. Quyết định thiết kế (và lý do)
| Quyết định | Lý do |
|---|---|
| LLM **không viết mã vẽ**; chỉ chọn intent/thông số, mã vẽ cố định | Mô hình 1.5B viết mã sai/không an toàn; chart_spec thì kiểm tra được |
| Router xuất JSON theo schema (Ollama `format`) + luật làm baseline/fallback | Đầu ra hợp lệ theo cấu trúc; hệ thống không chết khi LLM lỗi; có mốc so sánh cho đánh giá |
| Thực thể (trạm, thông số, thời gian) luôn do luật kiểm tra | Mô hình nhỏ hay bịa trạm; luật xác định được |
| **Grounding check** số trong câu trả lời ⊂ FACTS, sai thì dùng mẫu | Chặn bịa số – rủi ro lớn nhất khi dùng LLM nhỏ cho dữ liệu môi trường |
| Policy engine tách khỏi LLM, điều kiện qua AST whitelist (không `eval`) | Cảnh báo phải xác định và kiểm toán được |
| Một nguồn chân lý cho ngưỡng (`standards.yaml`) → sinh KB | RAG không thể nói khác với code; `build_kb --check` bắt lệch |
| WQI tính trên các thông số hiện có, trọng số chuẩn hóa lại | Cảm biến ESP32 không đo DO/NH4/CODMn, còn bộ dữ liệu lịch sử không có độ đục/TDS |
| Cờ chất lượng từng giá trị (ok/suspect/invalid/missing) | Cảm biến lỗi không được làm WQI sai hay sinh cảnh báo ô nhiễm giả |
| Cooldown theo thời gian mẫu đo + tự đóng cảnh báo | Tránh spam; mô phỏng/nạp lại lịch sử vẫn nhất quán |
| Thiết bị có key riêng, khoá vào đúng trạm | Thiết bị bị chiếm không giả mạo được trạm khác |

## 4. Cấu trúc thư mục
```
config/        settings, registry (thông số/tiêu chuẩn), parameters.yaml, standards.yaml, wqi.yaml
storage/       SQLite (stations, readings, devices, commands, alerts, chat_log)
data_processing/  WQI, làm sạch, đọc dataset
policy/        rules.yaml, expr (AST), policy_engine, action_dispatcher
alerts/        notifier (Telegram/Email)
llm_engine/    ollama_client, prompts/, rag/ (retriever BM25, vector_store Chroma), report
orchestrator/  schemas, rules_router, router, tools, compose, grounding, pipeline
forecasting/   holt, features, train, predict
charts/        renderer
backend/app/   main, context, deps, schemas, routers/, services/ingest
devices/       simulator, mqtt_bridge, serial_bridge, firmware/esp32_water_node, mosquitto/
ui/            Streamlit đa trang (chỉ gọi API)   frontend/static  web nhẹ
evaluation/    testset, metrics, run_eval, rubric, results/
training/      make_dataset, train_qlora, README
knowledge_base/docs  tài liệu RAG     scripts/  import, recompute, train, seed, build_kb
tests/         73 test
```
