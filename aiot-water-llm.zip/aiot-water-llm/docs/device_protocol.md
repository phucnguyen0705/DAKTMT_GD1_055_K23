# Giao thức thiết bị

## HTTP (mặc định)
`POST /api/ingest` – header `X-API-Key: <khóa thiết bị>`
```json
{"device_id":"esp32-01","ts":"2025-06-01T08:00:00Z","values":{"ph":7.2,"tds_ppm":310,"turbidity_ntu":9,"temperature_c":27.4},
 "meta":{"fw":"0.1.0","rssi":-61,"battery":87}}
```
- Có thể bỏ `ts` (dùng giờ máy chủ) hoặc dùng epoch giây/ms. `station_id` được lấy từ thiết bị; ghi khác bị bỏ qua.
- Tên trường được chuẩn hóa qua aliases (`pH`, `DO`, `temp`…); trường lạ nằm trong `ignored_fields`.
- Trùng (station, ts) → `is_new=false`, không ghi lại, không cảnh báo lại.
- Phản hồi: `wqi, wqi_class, severity, matched_rules, new_alert_ids, flags, commands[]`.
- Mã lỗi: 401 thiếu/sai key, 403 `device_id` không khớp key, 422 dữ liệu sai.

## Lệnh xuống thiết bị
Quản trị `POST /api/devices/{id}/commands` (`ping`, `reboot`, `set_interval` với `seconds` 10..86400). Lệnh đi kèm **phản hồi ingest kế tiếp**
(thiết bị tự kéo, không cần mở cổng vào thiết bị). Qua MQTT, bridge publish lên `.../cmd`.

## MQTT
Topic `aiot/water/{station}/{device}/telemetry`, payload `{"ts":..., "values":{...}, "meta":{...}}`.
`devices/mqtt_bridge.py` kiểm tra topic (chỉ `[A-Za-z0-9_][A-Za-z0-9_.-]*`) rồi POST bằng `INGEST_SERVICE_KEY`. Bridge không chứa logic nghiệp vụ.
Production: Mosquitto bật xác thực + TLS + ACL theo thiết bị (`devices/mosquitto/README.md`).

## Khoá & bảo mật
Khóa thiết bị tạo bằng `POST /api/devices` (admin), hiển thị một lần, DB chỉ lưu SHA-256. `REQUIRE_INGEST_AUTH=true` khi triển khai thật; đặt `ADMIN_API_KEY`.

## Cờ chất lượng dữ liệu
`ok` dùng bình thường · `suspect` ngoài khoảng hợp lý (lưu, không dùng, sinh alert lỗi cảm biến) · `invalid` ngoài khoảng vật lý (bỏ) · `missing`.
Ví dụ DS18B20 trả −127 → `invalid`; 85 → `suspect` nếu vượt khoảng hợp lý.

## Lệch thông số cảm biến ↔ dữ liệu lịch sử
ESP32 trong firmware mẫu đo **pH, độ đục, TDS, nhiệt độ**; bộ CNEMC có **DO, pH, NH4-N, CODMn** (không có độ đục/TDS). WQI vì thế tính trên
thông số hiện có (≥ 2) với trọng số chuẩn hóa; mô hình dự báo huấn luyện trên WQI của CNEMC **không đại diện** cho WQI sinh từ cảm biến ESP32 –
cần huấn luyện lại trên dữ liệu thiết bị thật khi đủ dài, hoặc bổ sung cảm biến DO/NH4.
