# API (tự sinh từ OpenAPI; chi tiết đầy đủ ở docs/openapi.json hoặc /docs khi chạy)

| Method | Path | Mô tả |
|---|---|---|
| GET | `/api/health` | Health |
| GET | `/api/metrics` | Metrics |
| GET | `/api/parameters` | Parameters |
| GET | `/api/standards` | Standards |
| GET | `/api/stations` | Stations |
| GET | `/api/stations/{station_id}/status` | Status |
| GET | `/api/stations/{station_id}/readings` | Readings |
| GET | `/api/stations/{station_id}/trend` | Trend |
| GET | `/api/stations/{station_id}/forecast` | Forecast |
| GET | `/api/stations/{station_id}/explain` | Explain |
| GET | `/api/compare` | Compare |
| GET | `/api/kb/search` | Kb Search |
| POST | `/api/ingest` | Ingest |
| POST | `/api/ingest/batch` | Ingest Batch |
| GET | `/api/devices` | List Devices |
| POST | `/api/devices` | Create Device |
| DELETE | `/api/devices/{device_id}` | Delete Device |
| POST | `/api/devices/{device_id}/commands` | Send Command |
| GET | `/api/alerts` | List Alerts |
| GET | `/api/alerts/{alert_id}` | Get Alert |
| POST | `/api/alerts/{alert_id}/ack` | Ack |
| POST | `/api/chat` | Chat |
| GET | `/api/chat/log` | Chat Log |
| GET | `/api/charts/{name}` | Chart File |

Xác thực: `X-API-Key` (thiết bị/service) cho `/api/ingest*`; `X-Admin-Key` cho `/api/devices*`, `/api/chat/log`. Bỏ trống khóa = chế độ dev.
