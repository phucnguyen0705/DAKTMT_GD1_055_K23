# Use case

Tác nhân: **Người vận hành** (OP), **Quản trị** (AD), **Thiết bị** (DV), **Hệ thống** (SY).

| ID | Use case | Tác nhân | Luồng chính | Cách kiểm chứng |
|---|---|---|---|---|
| UC1 | Gửi số liệu cảm biến | DV | POST /api/ingest → kiểm tra cờ → WQI → lưu → luật | tests/test_api, test_devices |
| UC2 | Xem tình trạng trạm | OP | Dashboard / chat «Tình trạng trạm X» → tool `get_status` | test_orchestrator |
| UC3 | Xem diễn biến & vẽ biểu đồ | OP | «Vẽ biểu đồ DO 7 ngày» → router (trend, chart) → renderer → PNG | test_api |
| UC4 | So sánh các trạm | OP | «Trạm nào có DO thấp nhất?» → `compare` | evaluation |
| UC5 | Dự báo WQI | OP | «Dự báo WQI» → Forecaster (GBR hoặc Holt) + khoảng bất định | test_scripts |
| UC6 | Hỏi nguyên nhân & khuyến nghị | OP | «Vì sao WQI thấp?» → `explain` (trạng thái + RAG theo thông số kéo xuống) → compose + grounding | test_scripts |
| UC7 | Tra ngưỡng tiêu chuẩn | OP | «Ngưỡng DO theo QCVN» → `standard_info` (từ YAML, không qua LLM) | test_orchestrator |
| UC8 | Nhận cảnh báo tự động | SY→OP | Luật khớp → alert (cooldown) → Dispatcher nền → Telegram/Email + báo cáo khuyến nghị | test_core, test_api |
| UC9 | Xác nhận / theo dõi cảnh báo | OP | UI «Đã xem» → ack; điều kiện hết → tự đóng | test_core |
| UC10 | Quản lý thiết bị | AD | Tạo thiết bị (key hiện một lần), xem online/offline, gửi lệnh `set_interval/reboot/ping` | test_api, test_devices |
| UC11 | Phát hiện lỗi cảm biến | SY | Giá trị ngoài khoảng hợp lý → cờ `suspect`, loại khỏi WQI, alert `sensor_fault` | test_devices |
| UC12 | Đánh giá hệ thống | AD | `run_eval` → router accuracy, grounded, latency, token + CSV chấm tay | test_eval |

## Mô phỏng
```
python -m scripts.seed_demo                      # 3 trạm demo: bình thường / ô nhiễm / lỗi cảm biến
make api  &  make ui
python -m devices.simulator --station SIM1 --scenario pollution --count 60 --interval 0.2
```
Kịch bản `pollution` làm DO giảm, NH4/CODMn/độ đục tăng ở giữa chuỗi rồi hồi phục: quan sát WQI tụt, cảnh báo xuất hiện một lần
(không lặp trong cooldown), tự đóng khi hồi phục, và báo cáo khuyến nghị đính kèm. `sensor_fault` đẩy pH = 15.2 định kỳ để thấy cờ `suspect`.
