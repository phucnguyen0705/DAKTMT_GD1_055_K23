# Từ framework gốc sang bản này

| Gốc | Mới | Thay đổi / lý do |
|---|---|---|
| `backend/app/models/store.py` (bộ nhớ, dữ liệu ngẫu nhiên) | `storage/db.py` (SQLite) | dữ liệu bền, idempotent, có thiết bị/lệnh/chat_log |
| `routers/{sensors,analysis,policy}.py` | `routers/{ingest,data,devices,alerts,chat,system}.py` | tách trách nhiệm; thêm auth thiết bị |
| `policy_engine.py` (`eval`, «khớp đầu tiên») | `policy/expr.py` + `policy_engine.py` | không `eval`; gộp mọi luật khớp; kiểm tra luật khi nạp |
| gửi Telegram khi mở trang | `Dispatcher` chạy nền sau khi tạo alert, cooldown | hết spam |
| `llm_engine/qwen_client.py` | `llm_engine/ollama_client.py` + `orchestrator/` | JSON schema, fallback, kiểm tra neo số liệu |
| `rag/vector_store.py` (embedding tiếng Anh) | `rag/retriever.py` BM25 (+ Chroma tùy chọn) | chạy offline, đúng tiếng Việt |
| `dashboard/app.py` (gọi thẳng module) | `ui/` Streamlit chỉ gọi REST | UI và API không lệch nhau |
| `data_ingestion/mqtt_subscriber.py` | `devices/mqtt_bridge.py` | bridge mỏng → API |
| `wqi_calculator.py` (cố định 7 tham số) | + `compute_wqi` theo thông số hiện có, `config/wqi.yaml` | thiết bị và dataset đo khác nhau |
| QCVN «A1» | QCVN 08:2023 mức A–D | sửa nhầm |
| `evaluation/eval_metrics.py` | `evaluation/` (testset, metrics, run_eval, rubric) | chạy được qua pipeline thật |
Hàm cũ `WaterSample/calculate_wqi/classify_wqi` vẫn còn để tương thích.
