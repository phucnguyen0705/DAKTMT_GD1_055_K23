# Giao thức đánh giá

Bộ test `evaluation/testset/testset_v1.jsonl` (37 câu, đủ 9 intent, có biến thể không dấu và câu ngoài phạm vi) chạy trên dữ liệu demo xác định.

| Mục tiêu | Chỉ số | Công cụ |
|---|---|---|
| Factuality | grounded rate (số ⊂ FACTS), fallback rate, tool success | `run_eval` (tự động) |
| Factuality (ý) | chấm tay «correct» 0–2 | CSV + `rubric.md` |
| Chất lượng | complete/clear/useful 0–2, ≥2 người chấm, Cohen's kappa | CSV + `rubric.md` |
| Router | accuracy intent/trạm/thông số/chart; so `rules` với `llm` | `run_eval --router` |
| Latency | mean/p50/p95 tổng và tách router/tool/compose | `run_eval`, `/api/metrics` |
| Chi phí | token vào/ra, cost nếu đặt `LLM_PRICE_PER_1K_TOKENS` (cloud so sánh) | `run_eval` |
| Dự báo | MAE so với persistence, chia theo thời gian | `scripts/train_forecaster` → `models/*_metrics.json` |

Lưu ý khi báo cáo: (1) bộ test do nhóm tự viết và baseline luật được tinh chỉnh cùng lúc → con số baseline lạc quan; nên thêm câu hỏi
do người ngoài viết. (2) «grounded» chỉ bảo đảm con số có nguồn, không bảo đảm lập luận. (3) Latency phải đo trên máy mục tiêu (RTX 3050 4GB / i5-12500H) với Ollama thật.

Các cấu hình nên so sánh: `rules/template` (baseline) · `llm/template` · `llm_with_fallback/llm_with_check` · cùng cấu hình với bản fine-tune · (tùy chọn) mô hình cloud.
