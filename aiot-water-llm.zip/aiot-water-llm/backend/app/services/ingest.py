"""
Dịch vụ ingest: nhận một mẫu đo (từ thiết bị, bridge MQTT, simulator hay script import) và xử lý:

    chuẩn hóa -> kiểm tra chất lượng từng giá trị -> tính WQI -> lưu -> đánh giá luật -> tạo alert (có cooldown)
                -> đóng alert đã hết điều kiện -> cập nhật thiết bị -> trả lệnh đang chờ cho thiết bị

Giá trị:
  ok       : dùng để tính WQI và đánh giá luật
  suspect  : ngoài khoảng hợp lý (parameters.yaml) -> lưu, gắn cờ, KHÔNG dùng; sinh alert 'sensor_fault'
  invalid  : ngoài khoảng vật lý / không phải số -> bỏ (lưu None), gắn cờ
Thời gian dùng để so cooldown là thời gian của MẪU ĐO (không phải giờ hệ thống), nên chạy lại dữ liệu lịch sử
hay mô phỏng tăng tốc vẫn cho kết quả nhất quán.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import timedelta
from typing import Any, Dict, List, Optional

from config.registry import ParameterRegistry
from config.settings import Settings
from data_processing.wqi_calculator import WQIConfig, compute_wqi
from policy.policy_engine import PolicyEngine
from storage.db import Storage, parse_iso, to_iso, utcnow

log = logging.getLogger(__name__)


@dataclass
class IngestResult:
    reading_id: int
    is_new: bool
    station_id: str
    device_id: Optional[str]
    ts: str
    values: Dict[str, Optional[float]]
    flags: Dict[str, str]
    wqi: Optional[float]
    wqi_class: Optional[str]
    severity: str
    matched_rules: List[str]
    new_alert_ids: List[int] = field(default_factory=list)
    suppressed_rules: List[str] = field(default_factory=list)
    ignored_fields: List[str] = field(default_factory=list)
    commands: List[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return dict(self.__dict__)


class IngestService:
    def __init__(self, storage: Storage, registry: ParameterRegistry, wqi_cfg: WQIConfig,
                 policy: PolicyEngine, settings: Settings):
        self.storage, self.registry, self.wqi_cfg, self.policy, self.settings = storage, registry, wqi_cfg, policy, settings

    # ------------------------------------------------------------------ chuẩn hóa
    def normalize_values(self, raw: Dict[str, Any]) -> tuple[Dict[str, Optional[float]], Dict[str, str], List[str]]:
        values: Dict[str, Optional[float]] = {}
        flags: Dict[str, str] = {}
        ignored: List[str] = []
        for name, val in raw.items():
            key = self.registry.canonical(name)
            if key is None:
                ignored.append(name)
                continue
            status = self.registry.check(key, val)
            if status == "ok":
                values[key] = float(val)
            elif status == "suspect":
                values[key] = float(val)
                flags[key] = "suspect"
            elif status == "invalid":
                values[key] = None
                flags[key] = "invalid"
            else:                                   # missing
                values[key] = None
                flags[key] = "missing"
        return values, flags, ignored

    # ------------------------------------------------------------------ xử lý chính
    def process(self, station_id: str, raw_values: Dict[str, Any], ts: Any = None, device_id: str | None = None,
                meta: Optional[dict] = None, source: str | None = None) -> IngestResult:
        meta = meta or {}
        reading_ts = to_iso(ts) if ts is not None else to_iso(utcnow())
        values, flags, ignored = self.normalize_values(raw_values)
        usable = {k: v for k, v in values.items() if v is not None and flags.get(k) is None}   # chỉ 'ok'

        wqi = compute_wqi(usable, self.wqi_cfg)
        ctx = {**usable, "wqi": wqi.wqi}
        policy = self.policy.evaluate(ctx)

        self.storage.upsert_station(station_id, source=source or ("device" if device_id else None))
        reading_id, is_new = self.storage.add_reading(
            station_id, reading_ts, values, flags, wqi.wqi, wqi.label, device_id=device_id, source=source or ("device" if device_id else None))

        new_alerts: List[int] = []
        suppressed: List[str] = []
        if is_new:
            new_alerts, suppressed = self._raise_alerts(station_id, reading_ts, ctx, values, flags, policy, wqi.wqi)

        commands: List[dict] = []
        if device_id and self.storage.get_device(device_id):
            self.storage.touch_device(device_id, to_iso(utcnow()), fw=meta.get("fw"),
                                      rssi=_int_or_none(meta.get("rssi")), battery=_float_or_none(meta.get("battery")))
            commands = self.storage.pop_pending_commands(device_id)

        return IngestResult(
            reading_id=reading_id, is_new=is_new, station_id=station_id, device_id=device_id, ts=reading_ts,
            values=values, flags=flags, wqi=wqi.wqi, wqi_class=wqi.label, severity=policy.severity,
            matched_rules=policy.matched_rules, new_alert_ids=new_alerts, suppressed_rules=suppressed,
            ignored_fields=ignored, commands=commands)

    # ------------------------------------------------------------------ cảnh báo
    def _in_cooldown(self, station_id: str, rule_id: str, reading_ts: str) -> bool:
        last = self.storage.last_alert(station_id, rule_id)
        if not last:
            return False
        delta = parse_iso(reading_ts) - parse_iso(last["ts"])
        return delta < timedelta(minutes=self.settings.ALERT_COOLDOWN_MIN)

    def _describe(self, rule_id: str, description: str, ctx: dict) -> str:
        parts = []
        for name in self.policy.rule_names(rule_id):
            v = ctx.get(name)
            if v is None:
                continue
            parts.append(f"WQI={v:g}" if name == "wqi" else f"{self.registry.label(name)}={self.registry.format(name, v)}")
        return f"{description}. Giá trị: {', '.join(parts)}" if parts else description

    def _raise_alerts(self, station_id: str, reading_ts: str, ctx: dict, values: dict, flags: dict,
                      policy, wqi: Optional[float]) -> tuple[List[int], List[str]]:
        created: List[int] = []
        suppressed: List[str] = []
        matched_ids = set()
        for m in policy.matched:
            if m.severity == "info":
                continue
            matched_ids.add(m.id)
            if self._in_cooldown(station_id, m.id, reading_ts):
                suppressed.append(m.id)
                continue
            created.append(self.storage.add_alert(
                station_id, m.id, m.severity, self._describe(m.id, m.description, ctx), wqi, m.actions, ts=reading_ts))

        # cảm biến nghi lỗi: giá trị ngoài khoảng hợp lý / không hợp lệ
        faulty = {k for k, f in flags.items() if f in ("suspect", "invalid")}
        for key in sorted(faulty):
            rule_id = f"sensor_fault:{key}"
            matched_ids.add(rule_id)
            if self._in_cooldown(station_id, rule_id, reading_ts):
                suppressed.append(rule_id)
                continue
            spec = self.registry.specs[key]
            raw = values.get(key)
            shown = "không hợp lệ" if raw is None else self.registry.format(key, raw)
            msg = (f"{spec.label} = {shown} nằm ngoài khoảng hợp lý {spec.plausible[0]:g}-{spec.plausible[1]:g}"
                   f"{(' ' + spec.unit) if spec.unit else ''}; nghi cảm biến lỗi hoặc cần hiệu chuẩn. "
                   f"Giá trị này không được dùng để tính WQI.")
            created.append(self.storage.add_alert(station_id, rule_id, "warning", msg, wqi, ["notify_telegram"],
                                                  kind="sensor_fault", ts=reading_ts))

        # đóng alert của luật đã được kiểm tra và không còn khớp
        checked = set(self.policy.evaluable_ids(ctx))
        to_close = [rid for rid in checked if rid not in matched_ids]
        to_close += [f"sensor_fault:{k}" for k, v in values.items() if v is not None and k not in faulty]
        self.storage.resolve_rules(station_id, to_close)
        return created, suppressed


def _int_or_none(v):
    try:
        return int(v) if v is not None else None
    except (TypeError, ValueError):
        return None


def _float_or_none(v):
    try:
        return float(v) if v is not None else None
    except (TypeError, ValueError):
        return None
