from __future__ import annotations

import secrets
from typing import Optional

from fastapi import Depends, Header, HTTPException, Request

from backend.app.context import AppContext


def get_ctx(request: Request) -> AppContext:
    return request.app.state.ctx


def require_admin(x_admin_key: Optional[str] = Header(default=None), ctx: AppContext = Depends(get_ctx)) -> None:
    expected = ctx.settings.ADMIN_API_KEY
    if not expected:
        return                                           # dev: để trống = mở
    if not x_admin_key or not secrets.compare_digest(x_admin_key, expected):
        raise HTTPException(401, "Thiếu hoặc sai X-Admin-Key")


def ingest_auth(x_api_key: Optional[str] = Header(default=None), ctx: AppContext = Depends(get_ctx)) -> dict:
    """Trả về {'kind': 'device'|'service'|'open', 'device': {...}|None}."""
    svc = ctx.settings.INGEST_SERVICE_KEY
    if x_api_key:
        if svc and secrets.compare_digest(x_api_key, svc):
            return {"kind": "service", "device": None}
        dev = ctx.storage.get_device_by_key(x_api_key)
        if dev:
            return {"kind": "device", "device": dev}
        raise HTTPException(401, "API key không hợp lệ")
    if ctx.settings.REQUIRE_INGEST_AUTH:
        raise HTTPException(401, "Cần header X-API-Key")
    return {"kind": "open", "device": None}
