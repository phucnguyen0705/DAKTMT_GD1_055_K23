from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field


class IngestIn(BaseModel):
    station_id: Optional[str] = Field(None, description="Bắt buộc với bridge/service key; thiết bị có key riêng thì bỏ qua")
    device_id: Optional[str] = None
    ts: Optional[Union[str, int, float]] = Field(None, description="ISO-8601 hoặc epoch giây/ms; bỏ trống = giờ máy chủ")
    values: Dict[str, Any]
    meta: Dict[str, Any] = Field(default_factory=dict, description="fw, rssi, battery")


class IngestBatchIn(BaseModel):
    items: List[IngestIn] = Field(..., max_length=1000)


class DeviceCreate(BaseModel):
    device_id: str = Field(..., min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_.-]+$")
    station_id: str = Field(..., min_length=1, max_length=64)
    name: Optional[str] = None
    protocol: str = "http"


class CommandIn(BaseModel):
    command: str
    params: Dict[str, Any] = Field(default_factory=dict)


class ChatIn(BaseModel):
    question: str = Field(..., min_length=1, max_length=1000)
    station_id: Optional[str] = None
