from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from backend.app.context import AppContext
from backend.app.routers import alerts, chat, data, devices, ingest, system
from config.settings import ROOT_DIR, Settings, get_settings


def create_app(settings: Settings | None = None, llm="default") -> FastAPI:
    settings = settings or get_settings()
    app = FastAPI(title="AIoT Water Quality + LLM", version="1.0")
    app.state.ctx = AppContext.build(settings, llm=llm)
    origins = [o.strip() for o in settings.CORS_ORIGINS.split(",") if o.strip()]
    app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["*"], allow_headers=["*"],
                       allow_credentials=False)
    for r in (system.router, data.router, ingest.router, devices.router, alerts.router, chat.router):
        app.include_router(r)
    static = ROOT_DIR / "frontend" / "static"
    if (static / "index.html").exists():
        app.mount("/", StaticFiles(directory=static, html=True), name="web")
    return app


def app_factory() -> FastAPI:                      # uvicorn backend.app.main:app_factory --factory
    return create_app()
