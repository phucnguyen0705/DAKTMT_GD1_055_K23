from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from backend.app.context import AppContext
from backend.app.deps import get_ctx

router = APIRouter(prefix="/api", tags=["data"])


@router.get("/parameters")
def parameters(ctx: AppContext = Depends(get_ctx)):
    return [{"key": k, "label": s.label, "unit": s.unit, "decimals": s.decimals, "plausible": s.plausible}
            for k, s in ctx.registry.specs.items()]


@router.get("/standards")
def standards(parameter: Optional[str] = None, ctx: AppContext = Depends(get_ctx)):
    return ctx.tools.standard_info(parameter)


@router.get("/stations")
def stations(ctx: AppContext = Depends(get_ctx)):
    out = []
    for s in ctx.storage.list_stations():
        r = ctx.storage.latest_reading(s["station_id"])
        out.append({**s, "last_ts": r["ts"] if r else None, "wqi": r["wqi"] if r else None,
                    "wqi_class": r["wqi_class"] if r else None})
    return out


def _need(ctx: AppContext, station_id: str) -> None:
    if not ctx.storage.get_station(station_id):
        raise HTTPException(404, f"Không có trạm {station_id}")


@router.get("/stations/{station_id}/status")
def status(station_id: str, ctx: AppContext = Depends(get_ctx)):
    _need(ctx, station_id)
    return ctx.tools.get_status(station_id)


@router.get("/stations/{station_id}/readings")
def readings(station_id: str, hours: Optional[float] = Query(None, gt=0), limit: int = Query(500, ge=1, le=5000),
             ctx: AppContext = Depends(get_ctx)):
    _need(ctx, station_id)
    since = ctx.storage.window_since(station_id, hours) if hours else None
    rows = ctx.storage.get_readings(station_id, since=since, limit=limit, newest=True)
    return [{"ts": r["ts"], "wqi": r["wqi"], "wqi_class": r["wqi_class"], "values": r["values"], "flags": r["flags"]}
            for r in rows]


@router.get("/stations/{station_id}/trend")
def trend(station_id: str, parameter: Optional[str] = None, hours: Optional[int] = Query(None, gt=0),
          chart: bool = False, ctx: AppContext = Depends(get_ctx)):
    _need(ctx, station_id)
    if parameter and parameter not in ctx.registry.keys:
        raise HTTPException(422, "parameter không hợp lệ")
    return ctx.tools.get_trend(station_id, parameter, hours, chart)


@router.get("/stations/{station_id}/forecast")
def forecast(station_id: str, steps: int = Query(3, ge=1, le=12), chart: bool = False,
             ctx: AppContext = Depends(get_ctx)):
    _need(ctx, station_id)
    return ctx.tools.forecast(station_id, steps, chart)


@router.get("/stations/{station_id}/explain")
def explain(station_id: str, ctx: AppContext = Depends(get_ctx)):
    _need(ctx, station_id)
    f = ctx.tools.explain(station_id)
    return {"facts": f, "answer": ctx.orchestrator.composer.compose("giải thích", "explain", f)["answer"]}


@router.get("/compare")
def compare(parameter: Optional[str] = None, ctx: AppContext = Depends(get_ctx)):
    return ctx.tools.compare(parameter)


@router.get("/kb/search")
def kb_search(q: str = Query(..., min_length=2), k: int = Query(4, ge=1, le=10), ctx: AppContext = Depends(get_ctx)):
    return ctx.retriever.search(q, k)
