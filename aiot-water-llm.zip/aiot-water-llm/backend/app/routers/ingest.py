from __future__ import annotations

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException

from backend.app.context import AppContext
from backend.app.deps import get_ctx, ingest_auth
from backend.app.schemas import IngestBatchIn, IngestIn

router = APIRouter(prefix="/api", tags=["ingest"])


def _resolve(item: IngestIn, auth: dict) -> tuple[str, str | None]:
    """Thiết bị có key riêng bị khoá vào đúng trạm/thiết bị của nó (không giả mạo được trạm khác)."""
    dev = auth["device"]
    if dev:
        if item.device_id and item.device_id != dev["device_id"]:
            raise HTTPException(403, "device_id không khớp với API key")
        return dev["station_id"], dev["device_id"]
    if not item.station_id:
        raise HTTPException(422, "Thiếu station_id")
    return item.station_id, item.device_id


def _run(ctx: AppContext, bg: BackgroundTasks, item: IngestIn, auth: dict) -> dict:
    station, device = _resolve(item, auth)
    try:
        res = ctx.ingest.process(station, item.values, ts=item.ts, device_id=device, meta=item.meta)
    except (ValueError, OverflowError) as e:
        raise HTTPException(422, f"Dữ liệu không hợp lệ: {e}") from e
    for aid in res.new_alert_ids:
        bg.add_task(ctx.dispatcher.dispatch, aid)
    return res.to_dict()


@router.post("/ingest")
def ingest(item: IngestIn, bg: BackgroundTasks, ctx: AppContext = Depends(get_ctx), auth: dict = Depends(ingest_auth)):
    return _run(ctx, bg, item, auth)


@router.post("/ingest/batch")
def ingest_batch(body: IngestBatchIn, bg: BackgroundTasks, ctx: AppContext = Depends(get_ctx),
                 auth: dict = Depends(ingest_auth)):
    results, errors = [], []
    for i, it in enumerate(body.items):
        try:
            results.append(_run(ctx, bg, it, auth))
        except HTTPException as e:
            errors.append({"index": i, "detail": e.detail})
    return {"accepted": len(results), "rejected": len(errors), "errors": errors}
