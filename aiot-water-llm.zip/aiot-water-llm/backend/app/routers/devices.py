from __future__ import annotations

import secrets
import sqlite3
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException

from backend.app.context import AppContext
from backend.app.deps import get_ctx, require_admin
from backend.app.schemas import CommandIn, DeviceCreate
from storage.db import parse_iso, to_iso, utcnow

router = APIRouter(prefix="/api/devices", tags=["devices"], dependencies=[Depends(require_admin)])
ALLOWED_COMMANDS = {"ping", "reboot", "set_interval"}


def _public(ctx: AppContext, d: dict) -> dict:
    online = False
    if d.get("last_seen"):
        online = utcnow() - parse_iso(d["last_seen"]) < timedelta(seconds=ctx.settings.DEVICE_OFFLINE_AFTER_SEC)
    return {k: v for k, v in d.items() if k != "key_hash"} | {"online": online}


@router.get("")
def list_devices(ctx: AppContext = Depends(get_ctx)):
    return [_public(ctx, d) for d in ctx.storage.list_devices()]


@router.post("", status_code=201)
def create_device(body: DeviceCreate, ctx: AppContext = Depends(get_ctx)):
    key = "dk_" + secrets.token_urlsafe(24)
    try:
        d = ctx.storage.create_device(body.device_id, body.station_id, key, body.name, body.protocol)
    except sqlite3.IntegrityError:
        raise HTTPException(409, "device_id đã tồn tại")
    return _public(ctx, d) | {"api_key": key, "note": "Khóa chỉ hiển thị một lần; hệ thống chỉ lưu băm."}


@router.delete("/{device_id}")
def delete_device(device_id: str, ctx: AppContext = Depends(get_ctx)):
    if not ctx.storage.delete_device(device_id):
        raise HTTPException(404, "Không có thiết bị")
    return {"deleted": device_id}


@router.post("/{device_id}/commands", status_code=201)
def send_command(device_id: str, body: CommandIn, ctx: AppContext = Depends(get_ctx)):
    if not ctx.storage.get_device(device_id):
        raise HTTPException(404, "Không có thiết bị")
    if body.command not in ALLOWED_COMMANDS:
        raise HTTPException(422, f"Lệnh phải thuộc {sorted(ALLOWED_COMMANDS)}")
    if body.command == "set_interval":
        sec = body.params.get("seconds")
        if not isinstance(sec, int) or not (10 <= sec <= 86400):
            raise HTTPException(422, "set_interval cần params.seconds là số nguyên 10..86400")
    return {"command_id": ctx.storage.add_command(device_id, body.command, body.params),
            "note": "Thiết bị nhận lệnh trong phản hồi của lần gửi dữ liệu kế tiếp."}
