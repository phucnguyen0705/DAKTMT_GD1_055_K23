from __future__ import annotations

import re
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse

from backend.app.context import AppContext
from backend.app.deps import get_ctx, require_admin
from backend.app.schemas import ChatIn

router = APIRouter(prefix="/api", tags=["chat"])


@router.post("/chat")
def chat(body: ChatIn, ctx: AppContext = Depends(get_ctx)):
    if body.station_id and not ctx.storage.get_station(body.station_id):
        raise HTTPException(404, f"Không có trạm {body.station_id}")
    r = ctx.orchestrator.answer(body.question, body.station_id)
    if r["chart"]:
        r["chart_url"] = f"/api/charts/{r['chart']}"
    return r


@router.get("/chat/log", dependencies=[Depends(require_admin)])
def chat_log(limit: int = 50, ctx: AppContext = Depends(get_ctx)):
    return ctx.storage.list_chat_log(min(max(limit, 1), 500))


@router.get("/charts/{name}")
def chart_file(name: str, ctx: AppContext = Depends(get_ctx)):
    if not re.fullmatch(r"[A-Za-z0-9_.-]+\.png", name):
        raise HTTPException(400, "Tên tệp không hợp lệ")
    p = Path(ctx.settings.CHARTS_DIR) / name
    if not p.is_file():
        raise HTTPException(404, "Không có biểu đồ")
    return FileResponse(p, media_type="image/png")
