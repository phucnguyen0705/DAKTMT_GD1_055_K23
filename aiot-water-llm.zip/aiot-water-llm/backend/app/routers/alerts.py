from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from backend.app.context import AppContext
from backend.app.deps import get_ctx

router = APIRouter(prefix="/api/alerts", tags=["alerts"])


@router.get("")
def list_alerts(station_id: Optional[str] = None, status: Optional[str] = Query(None, pattern="^(open|acked|resolved)$"),
                severity: Optional[str] = Query(None, pattern="^(info|warning|critical)$"),
                limit: int = Query(100, ge=1, le=500), ctx: AppContext = Depends(get_ctx)):
    return ctx.storage.list_alerts(station_id, status, severity, limit)


@router.get("/{alert_id}")
def get_alert(alert_id: int, ctx: AppContext = Depends(get_ctx)):
    a = ctx.storage.get_alert(alert_id)
    if not a:
        raise HTTPException(404, "Không có cảnh báo")
    return a


@router.post("/{alert_id}/ack")
def ack(alert_id: int, ctx: AppContext = Depends(get_ctx)):
    if not ctx.storage.ack_alert(alert_id):
        raise HTTPException(404, "Không có cảnh báo đang mở với id này")
    return {"acked": alert_id}
