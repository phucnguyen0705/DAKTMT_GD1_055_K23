from __future__ import annotations

import statistics

from fastapi import APIRouter, Depends

from backend.app.context import AppContext
from backend.app.deps import get_ctx

router = APIRouter(prefix="/api", tags=["system"])


@router.get("/health")
def health(ctx: AppContext = Depends(get_ctx)):
    llm_ok = bool(ctx.llm and ctx.llm.is_available())
    return {"status": "ok", "llm_available": llm_ok,
            "llm_model": ctx.settings.LLM_MODEL_NAME, "llm_model_installed": bool(llm_ok and ctx.llm.model_installed())
            if hasattr(ctx.llm, "model_installed") else None,
            "router_mode": ctx.settings.ROUTER_MODE, "compose_mode": ctx.settings.COMPOSE_MODE,
            "grounding_mode": ctx.settings.GROUNDING_MODE, "kb_chunks": len(ctx.retriever.chunks),
            "forecaster_model": ctx.forecaster.path.exists(), "n_stations": len(ctx.storage.station_ids()),
            "n_readings": ctx.storage.count_readings(), "wqi_version": ctx.wqi_cfg.version,
            "ingest_auth_required": ctx.settings.REQUIRE_INGEST_AUTH}


@router.get("/metrics")
def metrics(ctx: AppContext = Depends(get_ctx)):
    rows = ctx.storage.list_chat_log(500)
    if not rows:
        return {"n": 0}
    lat = sorted(r["latency_ms"] for r in rows)
    return {"n": len(rows), "latency_ms_p50": round(statistics.median(lat), 1),
            "latency_ms_p95": round(lat[int(0.95 * (len(lat) - 1))], 1),
            "grounded_rate": round(sum(r["grounded"] or 0 for r in rows) / len(rows), 3),
            "fallback_rate": round(sum(r["fallback_used"] or 0 for r in rows) / len(rows), 3),
            "tokens_in": sum(r["tokens_in"] or 0 for r in rows), "tokens_out": sum(r["tokens_out"] or 0 for r in rows)}
