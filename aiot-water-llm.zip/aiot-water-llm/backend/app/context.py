"""AppContext: dựng toàn bộ đối tượng dùng chung từ Settings (API, script, test đều dùng một chỗ này)."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from alerts.notifier import Notifier
from backend.app.services.ingest import IngestService
from charts.renderer import ChartRenderer
from config.registry import ParameterRegistry, Standards
from config.settings import Settings
from data_processing.wqi_calculator import WQIConfig
from forecasting.predict import Forecaster
from llm_engine.ollama_client import OllamaClient
from llm_engine.rag.retriever import BM25Retriever
from llm_engine.rag.vector_store import build_retriever
from orchestrator.compose import Composer
from orchestrator.pipeline import Orchestrator
from orchestrator.router import Router
from orchestrator.tools import Tools
from policy.action_dispatcher import Dispatcher
from llm_engine.report import make_reporter
from policy.policy_engine import PolicyEngine
from storage.db import Storage


@dataclass
class AppContext:
    settings: Settings
    storage: Storage
    registry: ParameterRegistry
    standards: Standards
    wqi_cfg: WQIConfig
    policy: PolicyEngine
    ingest: IngestService
    llm: Any
    retriever: BM25Retriever
    forecaster: Forecaster
    charts: ChartRenderer
    tools: Tools
    orchestrator: Orchestrator
    notifier: Notifier
    dispatcher: Dispatcher

    @classmethod
    def build(cls, settings: Settings, llm: Any = "default") -> "AppContext":
        """llm: 'default' -> OllamaClient theo settings; None -> không dùng LLM; hoặc đối tượng giả lập (test)."""
        storage = Storage(settings.DB_PATH)
        registry = ParameterRegistry.load(settings.PARAMETERS_PATH)
        standards = Standards.load(settings.STANDARDS_PATH)
        wqi_cfg = WQIConfig.load(settings.WQI_CONFIG_PATH)
        policy = PolicyEngine(settings.RULES_PATH, allowed_names=registry.keys)
        ingest = IngestService(storage, registry, wqi_cfg, policy, settings)
        if llm == "default":
            llm = OllamaClient(settings)
        retriever = build_retriever(settings, registry)
        forecaster = Forecaster(storage, settings.MODELS_DIR)
        charts = ChartRenderer(settings.CHARTS_DIR)
        tools = Tools(settings, storage, registry, standards, wqi_cfg, policy, retriever, forecaster, charts)
        orch = Orchestrator(settings, storage, Router(settings, registry, llm), tools, Composer(settings, registry, llm))
        notifier = Notifier(settings)
        ctx = cls(settings, storage, registry, standards, wqi_cfg, policy, ingest, llm, retriever, forecaster,
                  charts, tools, orch, notifier, Dispatcher(storage, notifier))
        ctx.dispatcher.reporter = make_reporter(ctx)
        return ctx
