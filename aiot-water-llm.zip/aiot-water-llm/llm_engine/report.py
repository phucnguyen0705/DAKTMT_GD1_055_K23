"""Sinh báo cáo/khuyến nghị cho một alert (dùng cùng pipeline như chatbot, nên cũng có kiểm tra neo dữ liệu)."""
from __future__ import annotations

from typing import Callable


def make_reporter(ctx) -> Callable[[int], None]:
    def reporter(alert_id: int) -> None:
        a = ctx.storage.get_alert(alert_id)
        if not a:
            return
        facts = ctx.tools.explain(a["station_id"])
        res = ctx.orchestrator.composer.compose(f"Giải thích cảnh báo và khuyến nghị cho trạm {a['station_id']}",
                                                "explain", facts)
        ctx.storage.set_alert_report(alert_id, {
            "text": res["answer"], "grounded": res["grounded"], "composer": res["composer"],
            "sources": [k["id"] for k in facts.get("knowledge", [])]})
    return reporter
