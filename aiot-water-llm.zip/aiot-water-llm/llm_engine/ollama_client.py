"""Client HTTP mỏng cho Ollama (/api/chat) với đầu ra ràng buộc bằng JSON schema.

Không phụ thuộc thư viện ollama; dùng httpx. Mọi lỗi mạng -> LLMUnavailable để orchestrator
chuyển sang fallback (router theo luật / câu trả lời mẫu).
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, Optional

import httpx

from config.settings import Settings


class LLMUnavailable(RuntimeError):
    pass


@dataclass
class LLMResponse:
    text: str
    tokens_in: int = 0
    tokens_out: int = 0
    latency_ms: float = 0.0
    parsed: Optional[Any] = None
    raw: dict = field(default_factory=dict)


class OllamaClient:
    def __init__(self, settings: Settings, transport: httpx.BaseTransport | None = None):
        self.s = settings
        self._client = httpx.Client(base_url=settings.LLM_BASE_URL.rstrip("/"), timeout=settings.LLM_TIMEOUT_SEC,
                                    transport=transport)

    def _options(self, temperature: float | None, max_tokens: int | None) -> dict:
        o: dict = {"temperature": self.s.LLM_TEMPERATURE if temperature is None else temperature,
                   "num_ctx": self.s.LLM_NUM_CTX}
        if self.s.LLM_NUM_THREAD:
            o["num_thread"] = self.s.LLM_NUM_THREAD
        if self.s.LLM_NUM_GPU >= 0:
            o["num_gpu"] = self.s.LLM_NUM_GPU
        if max_tokens:
            o["num_predict"] = max_tokens
        return o

    def chat(self, messages: list[dict], json_schema: dict | None = None, temperature: float | None = None,
             max_tokens: int | None = 512) -> LLMResponse:
        body = {"model": self.s.LLM_MODEL_NAME, "messages": messages, "stream": False,
                "keep_alive": self.s.LLM_KEEP_ALIVE, "options": self._options(temperature, max_tokens)}
        if json_schema:
            body["format"] = json_schema          # Ollama: constrained decoding theo schema
        t0 = time.perf_counter()
        try:
            r = self._client.post("/api/chat", json=body)
            r.raise_for_status()
            data = r.json()
        except (httpx.HTTPError, ValueError) as e:
            raise LLMUnavailable(f"{type(e).__name__}: {e}") from e
        text = (data.get("message") or {}).get("content", "")
        resp = LLMResponse(text=text, tokens_in=int(data.get("prompt_eval_count") or 0),
                           tokens_out=int(data.get("eval_count") or 0),
                           latency_ms=(time.perf_counter() - t0) * 1000, raw=data)
        if json_schema:
            try:
                resp.parsed = json.loads(text)
            except ValueError:
                resp.parsed = None
        return resp

    def is_available(self) -> bool:
        try:
            return self._client.get("/api/tags", timeout=2).status_code == 200
        except httpx.HTTPError:
            return False

    def model_installed(self) -> bool:
        try:
            tags = self._client.get("/api/tags", timeout=2).json().get("models", [])
        except (httpx.HTTPError, ValueError):
            return False
        return any(m.get("name", "").startswith(self.s.LLM_MODEL_NAME) for m in tags)

    def close(self) -> None:
        self._client.close()
