from __future__ import annotations

import json

COMPOSE_SYSTEM = """Bạn là trợ lý quan trắc chất lượng nước. Trả lời tiếng Việt, 2-5 câu, ngắn gọn.
QUY TẮC BẮT BUỘC:
- Chỉ dùng các con số có trong FACTS. Không tự tính, không làm tròn khác, không thêm số mới.
- Không bịa nguyên nhân hay ngưỡng ngoài FACTS/KIẾN THỨC.
- Nếu FACTS thiếu thông tin để trả lời, nói rõ là chưa đủ dữ liệu.
- Với khuyến nghị, nêu đây là hướng dẫn tham khảo, không thay thế chuyên gia."""


def build_compose_messages(question: str, facts: dict, snippets: list[dict]):
    kn = "\n".join(f"- [{s['id']}] {s['text']}" for s in snippets) or "(không có)"
    user = f"CÂU HỎI: {question}\nFACTS: {json.dumps(facts, ensure_ascii=False)}\nKIẾN THỨC:\n{kn}"
    return [{"role": "system", "content": COMPOSE_SYSTEM}, {"role": "user", "content": user}]
