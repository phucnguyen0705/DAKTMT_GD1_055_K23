from __future__ import annotations

ROUTER_SYSTEM = """Bạn là bộ định tuyến cho hệ thống quan trắc chất lượng nước. Chỉ trả về JSON.
intent:
- status: tình trạng/giá trị hiện tại của một trạm
- trend: diễn biến theo thời gian (kể cả yêu cầu vẽ biểu đồ)
- compare: so sánh nhiều trạm
- forecast: dự báo WQI
- explain: giải thích vì sao WQI thấp, nguyên nhân, khuyến nghị xử lý cho một trạm
- standard: ngưỡng/quy chuẩn (QCVN, GB 3838)
- alerts: danh sách cảnh báo
- knowledge: kiến thức chung về một thông số
- out_of_scope: không liên quan chất lượng nước
chart=true nếu người dùng muốn biểu đồ. parameter là khóa thông số hoặc null (null = WQI). station_id lấy từ danh sách trạm hoặc null."""


def build_router_messages(question: str, stations: list[dict], param_keys: list[str], ctx_station: str | None):
    ids = ", ".join(s["station_id"] for s in stations[:40]) or "(chưa có)"
    sys = f"{ROUTER_SYSTEM}\nThông số: {', '.join(param_keys)}\nTrạm: {ids}"
    if ctx_station:
        sys += f"\nTrạm đang chọn trên giao diện: {ctx_station}"
    return [{"role": "system", "content": sys}, {"role": "user", "content": question}]
