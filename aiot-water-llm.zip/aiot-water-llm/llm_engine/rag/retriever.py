"""KB loader + BM25 retriever (no model download needed).

Documents are markdown files with YAML front matter. Each `## section` is a
chunk with id `docid#slug`. Text is accent-stripped, tokenised into unigrams
and bigrams so Vietnamese queries match with or without diacritics.
"""
from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from config.registry import norm_text

_FM = re.compile(r"\A---\s*\n(.*?)\n---\s*\n", re.S)


@dataclass
class Chunk:
    id: str
    doc_id: str
    title: str
    section: str
    text: str
    type: str = ""
    params: list[str] = field(default_factory=list)
    source: str = ""
    verified: bool = False

    def to_dict(self) -> dict:
        return {"id": self.id, "doc_id": self.doc_id, "title": self.title,
                "section": self.section, "text": self.text, "type": self.type,
                "params": self.params, "source": self.source, "verified": self.verified}


def _slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", norm_text(s)).strip("-") or "section"


def tokenize(text: str) -> list[str]:
    words = re.findall(r"[a-z0-9]+", norm_text(text))
    return words + [f"{a}_{b}" for a, b in zip(words, words[1:])]


def load_kb(kb_dir: str | Path) -> list[Chunk]:
    chunks: list[Chunk] = []
    kb_dir = Path(kb_dir)
    if (kb_dir / "docs").is_dir():          # KB_DIR trỏ tới knowledge_base/
        kb_dir = kb_dir / "docs"
    for p in sorted(kb_dir.glob("*.md")):
        raw = p.read_text(encoding="utf-8")
        meta: dict = {}
        m = _FM.match(raw)
        if m:
            meta = yaml.safe_load(m.group(1)) or {}
            raw = raw[m.end():]
        doc_id = str(meta.get("id", p.stem))
        title = str(meta.get("title", p.stem))
        parts = re.split(r"^##\s+(.+)$", raw, flags=re.M)
        # parts[0] is preamble (h1 + intro); then (heading, body) pairs
        pre = re.sub(r"^#\s+.*$", "", parts[0], flags=re.M).strip()
        sections = [("Tổng quan", pre)] if pre else []
        sections += [(parts[i].strip(), parts[i + 1].strip()) for i in range(1, len(parts) - 1, 2)]
        seen: set[str] = set()
        for head, body in sections:
            if not body:
                continue
            sid = f"{doc_id}#{_slug(head)}"
            while sid in seen:
                sid += "x"
            seen.add(sid)
            chunks.append(Chunk(sid, doc_id, title, head, body, str(meta.get("type", "")),
                                list(meta.get("params") or []), str(meta.get("source", "")),
                                bool(meta.get("verified", False))))
    return chunks


class BM25Retriever:
    def __init__(self, chunks: list[Chunk], k1: float = 1.5, b: float = 0.75, registry=None):
        self.chunks = chunks
        self.registry = registry
        self.k1, self.b = k1, b
        # title and heading repeated so they weigh slightly more
        self._tf = [Counter(tokenize(f"{c.title} {c.section} {c.section} {c.text}")) for c in chunks]
        self._len = [sum(t.values()) for t in self._tf]
        self._avg = (sum(self._len) / len(self._len)) if self._len else 1.0
        df: Counter = Counter()
        for t in self._tf:
            df.update(t.keys())
        n = len(chunks)
        self._idf = {w: math.log(1 + (n - d + 0.5) / (d + 0.5)) for w, d in df.items()}

    @classmethod
    def from_dir(cls, kb_dir, registry=None) -> "BM25Retriever":
        if registry is None:
            from config.registry import ParameterRegistry
            from config.settings import get_settings
            try:
                registry = ParameterRegistry.load(get_settings().PARAMETERS_PATH)
            except Exception:
                registry = None
        return cls(load_kb(kb_dir), registry=registry)

    def search(self, query: str, k: int = 4, doc_types: list[str] | None = None,
               params: list[str] | None = None) -> list[dict]:
        q = tokenize(query)
        if self.registry is not None and not params:
            # "do" is also a common Vietnamese word, so detect the parameter explicitly
            from orchestrator.rules_router import detect_parameter
            key = detect_parameter(query, norm_text(query), self.registry)
            params = [key] if key else None
        if not q:
            return []
        out = []
        for i, c in enumerate(self.chunks):
            if doc_types and c.type not in doc_types:
                continue
            tf, dl = self._tf[i], self._len[i]
            score = 0.0
            for w in q:
                f = tf.get(w)
                if not f:
                    continue
                score += self._idf.get(w, 0) * f * (self.k1 + 1) / (
                    f + self.k1 * (1 - self.b + self.b * dl / self._avg))
            if params and set(params) & set(c.params):
                score *= 2.5
            if score > 0:
                out.append((score, c))
        out.sort(key=lambda x: -x[0])
        return [{**c.to_dict(), "score": round(s, 3)} for s, c in out[:k]]

    def get_sections(self, doc_id: str, sections: list[str] | None = None) -> list[dict]:
        """Structured lookup (no ranking), e.g. get_sections('param_do', ['Khuyến nghị'])."""
        want = {norm_text(s) for s in sections} if sections else None
        return [c.to_dict() for c in self.chunks
                if c.doc_id == doc_id and (want is None or norm_text(c.section) in want)]
