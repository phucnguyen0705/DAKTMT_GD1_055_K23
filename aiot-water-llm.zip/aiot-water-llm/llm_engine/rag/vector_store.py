"""Retriever vector tùy chọn (Chroma + multilingual-e5-small). CHƯA ĐƯỢC KIỂM THỬ trong môi trường phát triển
(không cài chromadb/sentence-transformers). Cùng giao diện với BM25Retriever; lỗi import -> rơi về BM25."""
from __future__ import annotations

from llm_engine.rag.retriever import BM25Retriever, load_kb


class ChromaRetriever(BM25Retriever):
    def __init__(self, chunks, registry, path: str, collection: str, model_name: str):
        super().__init__(chunks, registry=registry)
        import chromadb
        from sentence_transformers import SentenceTransformer
        self._model = SentenceTransformer(model_name)
        self._col = chromadb.PersistentClient(path=path).get_or_create_collection(collection)
        by_id = {c.id: c for c in chunks}
        if self._col.count() != len(chunks):                     # lập chỉ mục lại khi KB đổi
            self._col.delete(ids=self._col.get()["ids"]) if self._col.count() else None
            texts = [f"passage: {c.title}. {c.section}. {c.text}" for c in chunks]
            self._col.add(ids=[c.id for c in chunks], documents=texts,
                          embeddings=self._model.encode(texts, normalize_embeddings=True).tolist())
        self._by_id = by_id

    def search(self, query, k=4, doc_types=None, params=None):
        bm = super().search(query, k=k * 2, doc_types=doc_types, params=params)      # kết hợp lai: BM25 + vector
        emb = self._model.encode([f"query: {query}"], normalize_embeddings=True).tolist()
        res = self._col.query(query_embeddings=emb, n_results=k * 2)
        score: dict[str, float] = {}
        for rank, h in enumerate(bm):
            score[h["id"]] = score.get(h["id"], 0) + 1 / (60 + rank)                 # reciprocal rank fusion
        for rank, cid in enumerate(res["ids"][0]):
            c = self._by_id[cid]
            if doc_types and c.type not in doc_types:
                continue
            score[cid] = score.get(cid, 0) + 1 / (60 + rank)
        top = sorted(score, key=score.get, reverse=True)[:k]
        return [{**self._by_id[i].to_dict(), "score": round(score[i], 4)} for i in top]


def build_retriever(settings, registry) -> BM25Retriever:
    if settings.RETRIEVER == "chroma":
        try:
            return ChromaRetriever(load_kb(settings.KB_DIR), registry, settings.VECTOR_DB_PATH,
                                   settings.VECTOR_DB_COLLECTION, settings.EMBEDDING_MODEL_NAME)
        except Exception:                                          # noqa: BLE001
            import logging
            logging.getLogger(__name__).warning("Chroma không dùng được, dùng BM25")
    return BM25Retriever.from_dir(settings.KB_DIR, registry)
